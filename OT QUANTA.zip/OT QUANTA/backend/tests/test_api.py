import pytest
import uuid
from fastapi.testclient import TestClient
from app.main import app
from app.core.database import SessionLocal
from app.models.user import User
from app.models.clinical import PatientRecord, DonorRecord
from app.models.organ import OrganCatalog, OrganInventory
from app.models.enums import UserRole, OrganType

client = TestClient(app)

@pytest.fixture(scope="module")
def admin_token():
    # Login as seeded demo admin
    resp = client.post("/api/v1/auth/login", json={
        "email": "admin@quantaorgan.demo",
        "password": "AdminPass123!"
    })
    assert resp.status_code == 200, f"Admin login failed: {resp.text}"
    return resp.json()["access_token"]

@pytest.fixture(scope="module")
def patient_token():
    # Login as seeded demo patient
    resp = client.post("/api/v1/auth/login", json={
        "email": "patient@quantaorgan.demo",
        "password": "PatientPass123!"
    })
    assert resp.status_code == 200, f"Patient login failed: {resp.text}"
    return resp.json()["access_token"]

@pytest.fixture(scope="module")
def clinician_token():
    # Login as seeded demo clinician
    resp = client.post("/api/v1/auth/login", json={
        "email": "clinician@quantaorgan.demo",
        "password": "DoctorPass123!"
    })
    assert resp.status_code == 200, f"Clinician login failed: {resp.text}"
    return resp.json()["access_token"]

def test_health_check():
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "healthy"
    assert data["service"] == "QuantaOrgan"

def test_auth_invalid_credentials():
    resp = client.post("/api/v1/auth/login", json={
        "email": "admin@transplantcare.demo",
        "password": "WrongPassword!"
    })
    assert resp.status_code == 401

def test_user_registration_and_login():
    test_email = f"test_{uuid.uuid4().hex[:6]}@example.com"
    reg_resp = client.post("/api/v1/auth/register", json={
        "email": test_email,
        "password": "StrongPassword123!",
        "full_name": "Test Registered User",
        "role": "PATIENT"
    })
    assert reg_resp.status_code == 201
    
    login_resp = client.post("/api/v1/auth/login", json={
        "email": test_email,
        "password": "StrongPassword123!"
    })
    assert login_resp.status_code == 200
    assert "access_token" in login_resp.json()

def test_dashboard_aggregates(admin_token):
    resp = client.get(
        "/api/v1/analytics/dashboard",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "summary" in data
    assert "organ_demand_table" in data
    assert "quantum_metrics" in data
    assert data["summary"]["total_registered_patients"] >= 6
    assert data["summary"]["total_registered_donors"] >= 3
    assert len(data["organ_demand_table"]) >= 8

def test_patient_privacy_isolation(admin_token, patient_token):
    # Retrieve patients list as admin
    admin_list = client.get(
        "/api/v1/patients",
        headers={"Authorization": f"Bearer {admin_token}"}
    ).json()
    assert admin_list["total"] >= 6

    # Retrieve patients list as patient - should strictly return 1 record (their own)
    pat_list = client.get(
        "/api/v1/patients",
        headers={"Authorization": f"Bearer {patient_token}"}
    ).json()
    assert pat_list["total"] == 1
    assert pat_list["items"][0]["full_name"] == "Marcus Vance"

def test_crossmatch_evaluation_pipeline(clinician_token):
    db = SessionLocal()
    patient = db.query(PatientRecord).filter(PatientRecord.patient_code == "PT-MTI-1001").first()
    donor = db.query(DonorRecord).filter(DonorRecord.donor_code == "DN-MTI-1001").first()
    db.close()

    resp = client.post(
        "/api/v1/crossmatch/assess",
        headers={"Authorization": f"Bearer {clinician_token}"},
        json={
            "patient_id": str(patient.id),
            "donor_id": str(donor.id),
            "organ_type": "KIDNEY"
        }
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["blood_group_compatible"] is True
    assert data["crossmatch_result"] in ["COMPATIBLE", "CONDITIONALLY_ACCEPTABLE", "INSUFFICIENT_DATA"]
    assert "tests_completed" in data
    assert data["algorithm_version"] == "TCQ-RULE-ENGINE-v1.0"

def test_quantum_benchmark_endpoint(admin_token):
    resp = client.post(
        "/api/v1/quantum/benchmark",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "num_candidates": 6,
            "num_organs": 3,
            "penalty_weight": 120.0
        }
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "experiment" in data
    assert "classical_allocations" in data
    assert "quantum_allocations" in data
    assert data["feasibility_check_passed"] is True
    assert data["experiment"]["problem_size"] == 18

def test_pdf_report_generation(clinician_token):
    # Get existing crossmatch report
    reports = client.get(
        "/api/v1/crossmatch/reports",
        headers={"Authorization": f"Bearer {clinician_token}"}
    ).json()
    assert len(reports) > 0
    assessment_id = reports[0]["id"]

    resp = client.post(
        f"/api/v1/consent/reports/{assessment_id}/generate-pdf",
        headers={"Authorization": f"Bearer {clinician_token}"}
    )
    assert resp.status_code == 201
    data = resp.json()
    assert "report_id" in data
    assert data["file_name"].endswith(".pdf")
    assert data["file_size_bytes"] > 0
    assert len(data["checksum"]) == 64

def test_notifications_endpoint(admin_token):
    resp = client.get(
        "/api/v1/notifications",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert resp.status_code == 200
    notifs = resp.json()
    assert isinstance(notifs, list)
