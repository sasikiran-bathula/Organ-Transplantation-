import pytest
import uuid
from fastapi.testclient import TestClient
from app.main import app
from app.core.database import SessionLocal
from app.models.user import User, Hospital
from app.models.clinical import PatientRecord, DonorRecord
from app.models.organ import OrganInventory, OrganCatalog
from app.models.enums import UserRole, OrganType, OrganInventoryStatus

client = TestClient(app)

@pytest.fixture(scope="module")
def admin_token():
    resp = client.post("/api/v1/auth/login", json={
        "email": "admin@quantaorgan.demo",
        "password": "AdminPass123!"
    })
    return resp.json()["access_token"]

@pytest.fixture(scope="module")
def clinician_token():
    resp = client.post("/api/v1/auth/login", json={
        "email": "clinician@quantaorgan.demo",
        "password": "DoctorPass123!"
    })
    return resp.json()["access_token"]

def test_donor_pathways_and_validation(admin_token):
    db = SessionLocal()
    hosp = db.query(Hospital).first()
    db.close()

    # Living donor creation
    living_resp = client.post(
        "/api/v1/donors",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "full_name": "Living Donor Candidate",
            "date_of_birth": "1990-01-01",
            "gender": "FEMALE",
            "blood_group": "A+",
            "hospital_id": str(hosp.id),
            "donor_pathway": "LIVING",
            "organs_offered": ["KIDNEY"],
            "legal_authorization_status": "INFORMED_CONSENT_SIGNED"
        }
    )
    assert living_resp.status_code == 201
    assert living_resp.json()["donor_pathway"] == "LIVING"

    # Deceased donor creation
    deceased_resp = client.post(
        "/api/v1/donors",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "full_name": "Deceased Donor Candidate",
            "date_of_birth": "1970-05-15",
            "gender": "MALE",
            "blood_group": "O-",
            "hospital_id": str(hosp.id),
            "donor_pathway": "DECEASED",
            "organs_offered": ["HEART", "LUNGS", "LIVER", "KIDNEY"],
            "legal_authorization_status": "NEXT_OF_KIN_AUTHORIZED"
        }
    )
    assert deceased_resp.status_code == 201
    assert deceased_resp.json()["donor_pathway"] == "DECEASED"

def test_document_extraction_and_verification(clinician_token):
    db = SessionLocal()
    patient = db.query(PatientRecord).first()
    db.close()

    # Upload test document
    dummy_content = b"HOSPITAL LABORATORY REPORT\nPatient Blood Group: O+\nRh: Positive\nHLA Typing: A*02:01, B*07:02, DRB1*04:01\nHIV: Negative\nHepB: Negative"
    files = {"file": ("lab_report_O_pos.txt", dummy_content, "text/plain")}
    data = {
        "record_type": "PATIENT",
        "record_id": str(patient.id),
        "classification": "LAB_REPORT"
    }

    upload_resp = client.post(
        "/api/v1/documents/upload",
        headers={"Authorization": f"Bearer {clinician_token}"},
        files=files,
        data=data
    )
    assert upload_resp.status_code == 201
    doc_id = upload_resp.json()["id"]

    # Extract
    extract_resp = client.post(
        f"/api/v1/documents/{doc_id}/extract",
        headers={"Authorization": f"Bearer {clinician_token}"}
    )
    assert extract_resp.status_code == 200
    extract_data = extract_resp.json()
    assert extract_data["processing_status"] == "EXTRACTED"
    assert extract_data["extracted_data"]["blood_group_detected"] == "O+"

    # Verify
    verify_resp = client.post(
        f"/api/v1/documents/{doc_id}/verify",
        headers={"Authorization": f"Bearer {clinician_token}"},
        json={
            "verified_data": extract_data["extracted_data"],
            "verification_notes": "Reviewed and confirmed laboratory serology by Dr. Rostova",
            "apply_to_record": True
        }
    )
    assert verify_resp.status_code == 200
    assert verify_resp.json()["processing_status"] == "VERIFIED"

def test_audit_logs_rbac_restriction(admin_token):
    # Registered patient trying to view audit logs should be 403 Forbidden
    patient_resp = client.post("/api/v1/auth/login", json={
        "email": "patient@quantaorgan.demo",
        "password": "PatientPass123!"
    })
    pat_token = patient_resp.json()["access_token"]

    forbidden_resp = client.get(
        "/api/v1/audit/logs",
        headers={"Authorization": f"Bearer {pat_token}"}
    )
    assert forbidden_resp.status_code == 403

    # Admin can view
    admin_resp = client.get(
        "/api/v1/audit/logs",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert admin_resp.status_code == 200
    assert admin_resp.json()["total"] > 0
