from fastapi import APIRouter
from app.api.v1.endpoints import (
    auth, users, patients, donors, organs, crossmatch, documents, consent, quantum, analytics, notifications, audit
)

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Authentication & Profile"])
api_router.include_router(users.router, prefix="/users", tags=["Users & Hospital Administration"])
api_router.include_router(patients.router, prefix="/patients", tags=["Patient Registry"])
api_router.include_router(donors.router, prefix="/donors", tags=["Donor Registry"])
api_router.include_router(organs.router, prefix="/organs", tags=["Organ Inventory & Requests"])
api_router.include_router(crossmatch.router, prefix="/crossmatch", tags=["Crossmatch Assessment & Review"])
api_router.include_router(documents.router, prefix="/documents", tags=["Medical Documents & Extraction"])
api_router.include_router(consent.router, prefix="/consent", tags=["Consent & Reports"])
api_router.include_router(quantum.router, prefix="/quantum", tags=["Quantum Optimization & Benchmarking"])
api_router.include_router(analytics.router, prefix="/analytics", tags=["Dashboard Analytics"])
api_router.include_router(notifications.router, prefix="/notifications", tags=["Notifications"])
api_router.include_router(audit.router, prefix="/audit", tags=["Clinical Audit Logs"])
