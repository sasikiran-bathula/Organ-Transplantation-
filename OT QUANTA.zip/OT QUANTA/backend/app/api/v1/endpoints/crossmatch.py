import uuid
from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import get_current_user, require_roles
from app.models.crossmatch import MatchAssessment, CandidatePair
from app.models.clinical import PatientRecord, DonorRecord
from app.models.user import User
from app.models.enums import UserRole, ApprovalStatus, NotificationEventType
from app.schemas.crossmatch import (
    CrossmatchAssessmentRequest, CrossmatchReportOut, MatchReviewAction, CandidatePairOut
)
from app.services.crossmatch_service import evaluate_crossmatch
from app.services.audit_service import record_audit_event
from app.services.notification_service import create_notification

router = APIRouter()

@router.post("/assess", response_model=CrossmatchReportOut, status_code=status.HTTP_201_CREATED)
def trigger_crossmatch_assessment(
    payload: CrossmatchAssessmentRequest,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.CLINICIAN,
        UserRole.LAB_REVIEWER, UserRole.TRANSPLANT_COORDINATOR
    )),
    db: Session = Depends(get_db)
):
    patient = db.query(PatientRecord).filter(PatientRecord.id == payload.patient_id, PatientRecord.is_archived == False).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient record not found.")

    donor = db.query(DonorRecord).filter(DonorRecord.id == payload.donor_id, DonorRecord.is_archived == False).first()
    if not donor:
        raise HTTPException(status_code=404, detail="Donor record not found.")

    # Evaluate deterministic compatibility
    organ_str = payload.organ_type.value if hasattr(payload.organ_type, "value") else str(payload.organ_type)
    eval_result = evaluate_crossmatch(patient=patient, donor=donor, organ_type=organ_str)

    count = db.query(MatchAssessment).count()
    assessment_code = f"XMATCH-{1000 + count + 1}"

    assessment = MatchAssessment(
        assessment_code=assessment_code,
        patient_id=patient.id,
        donor_id=donor.id,
        organ_type=organ_str,
        blood_group_compatible=eval_result["blood_group_compatible"],
        hla_compatibility_score=eval_result["hla_compatibility_score"],
        crossmatch_result=eval_result["crossmatch_result"],
        tests_completed=eval_result["tests_completed"],
        tests_pending=eval_result["tests_pending"],
        clinical_warnings=eval_result["clinical_warnings"],
        evidence_references=eval_result["evidence_references"],
        explanation=eval_result["explanation"],
        review_status=ApprovalStatus.PENDING.value,
        algorithm_version="TCQ-RULE-ENGINE-v1.0"
    )
    db.add(assessment)
    db.flush()

    # Candidate pair tracking
    candidate_pair = CandidatePair(
        match_assessment_id=assessment.id,
        patient_id=patient.id,
        donor_id=donor.id,
        organ_type=organ_str,
        eligibility_satisfied=eval_result["blood_group_compatible"] and len(eval_result["tests_pending"]) == 0,
        exclusion_reasons=eval_result["clinical_warnings"],
        priority_score=10.0 if eval_result["blood_group_compatible"] else 0.0
    )
    db.add(candidate_pair)
    db.commit()
    db.refresh(assessment)

    record_audit_event(
        db=db,
        action="EXECUTE_CROSSMATCH_ASSESSMENT",
        resource_type="MATCH_ASSESSMENT",
        resource_id=str(assessment.id),
        user=current_user,
        changes={"result": assessment.crossmatch_result, "organ": organ_str}
    )

    out = CrossmatchReportOut.from_orm(assessment)
    out.patient_code = patient.patient_code
    out.patient_name = patient.full_name
    out.patient_blood_group = patient.blood_group
    out.donor_code = donor.donor_code
    out.donor_name = donor.full_name
    out.donor_blood_group = donor.blood_group
    return out

@router.get("/reports", response_model=List[CrossmatchReportOut])
def list_crossmatch_reports(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(MatchAssessment)
    if current_user.role == UserRole.PATIENT.value:
        query = query.join(PatientRecord).filter(PatientRecord.user_id == current_user.id)
    elif current_user.role == UserRole.DONOR.value:
        query = query.join(DonorRecord).filter(DonorRecord.user_id == current_user.id)

    assessments = query.order_by(MatchAssessment.created_at.desc()).all()
    results = []
    for a in assessments:
        out = CrossmatchReportOut.from_orm(a)
        if a.patient:
            out.patient_code = a.patient.patient_code
            out.patient_name = a.patient.full_name
            out.patient_blood_group = a.patient.blood_group
        if a.donor:
            out.donor_code = a.donor.donor_code
            out.donor_name = a.donor.full_name
            out.donor_blood_group = a.donor.blood_group
        if a.reviewer and a.reviewer.profile:
            out.reviewer_name = a.reviewer.profile.full_name
        results.append(out)
    return results

@router.get("/reports/{assessment_id}", response_model=CrossmatchReportOut)
def get_crossmatch_report(
    assessment_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    assessment = db.query(MatchAssessment).filter(MatchAssessment.id == assessment_id).first()
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found.")

    out = CrossmatchReportOut.from_orm(assessment)
    if assessment.patient:
        out.patient_code = assessment.patient.patient_code
        out.patient_name = assessment.patient.full_name
        out.patient_blood_group = assessment.patient.blood_group
    if assessment.donor:
        out.donor_code = assessment.donor.donor_code
        out.donor_name = assessment.donor.full_name
        out.donor_blood_group = assessment.donor.blood_group
    if assessment.reviewer and assessment.reviewer.profile:
        out.reviewer_name = assessment.reviewer.profile.full_name
    return out

@router.post("/reports/{assessment_id}/review", response_model=CrossmatchReportOut)
def review_crossmatch_decision(
    assessment_id: uuid.UUID,
    payload: MatchReviewAction,
    current_user: User = Depends(require_roles(UserRole.CLINICIAN, UserRole.SYSTEM_ADMIN)),
    db: Session = Depends(get_db)
):
    assessment = db.query(MatchAssessment).filter(MatchAssessment.id == assessment_id).first()
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found.")

    decision_str = payload.decision.value if hasattr(payload.decision, "value") else str(payload.decision)
    assessment.review_status = decision_str
    assessment.review_notes = payload.review_notes
    assessment.reviewer_id = current_user.id
    assessment.reviewed_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(assessment)

    record_audit_event(
        db=db,
        action="REVIEW_CROSSMATCH_DECISION",
        resource_type="MATCH_ASSESSMENT",
        resource_id=str(assessment.id),
        user=current_user,
        changes={"decision": decision_str, "notes": payload.review_notes}
    )

    # Notify coordinator
    if assessment.patient and assessment.patient.assigned_coordinator_id:
        create_notification(
            db=db,
            recipient_user_id=assessment.patient.assigned_coordinator_id,
            event_type=NotificationEventType.CLINICAL_APPROVAL_REJECTION,
            title=f"Crossmatch Decision: {decision_str}",
            message=f"Assessment {assessment.assessment_code} has been marked {decision_str} by Dr. {current_user.profile.full_name if current_user.profile else 'Clinician'}.",
            related_record_id=assessment.id,
            related_record_type="MATCH_ASSESSMENT"
        )

    out = CrossmatchReportOut.from_orm(assessment)
    if assessment.patient:
        out.patient_code = assessment.patient.patient_code
        out.patient_name = assessment.patient.full_name
        out.patient_blood_group = assessment.patient.blood_group
    if assessment.donor:
        out.donor_code = assessment.donor.donor_code
        out.donor_name = assessment.donor.full_name
        out.donor_blood_group = assessment.donor.blood_group
    out.reviewer_name = current_user.profile.full_name if current_user.profile else "Clinician"
    return out
