from datetime import datetime, timezone
from typing import List, Dict
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.models.clinical import PatientRecord, DonorRecord, LaboratoryTest
from app.models.organ import OrganCatalog, OrganInventory, OrganRequest
from app.models.crossmatch import MatchAssessment, TransplantRecord
from app.models.notification_audit import Notification
from app.models.quantum import QuantumExperiment
from app.models.enums import OrganInventoryStatus, OrganRequestStatus, ApprovalStatus, UrgencyLevel
from app.schemas.analytics import (
    DashboardAnalyticsOut, SummaryCardsOut, OrganInventoryDemandItem, QuantumPerformanceCardsOut
)

router = APIRouter()

@router.get("/dashboard", response_model=DashboardAnalyticsOut)
def get_dashboard_analytics(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Real-time PostgreSQL aggregates for summary metrics, organ demand, and quantum research stats."""
    
    # 1. Summary Cards Aggregates
    total_members = db.query(func.count(User.id)).scalar() or 0
    total_patients = db.query(func.count(PatientRecord.id)).filter(PatientRecord.is_archived == False).scalar() or 0
    total_donors = db.query(func.count(DonorRecord.id)).filter(DonorRecord.is_archived == False).scalar() or 0
    
    # Available organs must satisfy inventory eligibility: PROCURED or PRESERVED
    total_organs_avail = db.query(func.count(OrganInventory.id)).filter(
        OrganInventory.status.in_([OrganInventoryStatus.PROCURED.value, OrganInventoryStatus.PRESERVED.value])
    ).scalar() or 0

    total_open_requests = db.query(func.count(OrganRequest.id)).filter(
        OrganRequest.status == OrganRequestStatus.OPEN.value
    ).scalar() or 0

    total_completed_transplants = db.query(func.count(TransplantRecord.id)).scalar() or 0

    matches_awaiting_review = db.query(func.count(MatchAssessment.id)).filter(
        MatchAssessment.review_status == ApprovalStatus.PENDING.value
    ).scalar() or 0

    approved_matches = db.query(func.count(MatchAssessment.id)).filter(
        MatchAssessment.review_status == ApprovalStatus.APPROVED.value
    ).scalar() or 0

    pending_evals = db.query(func.count(PatientRecord.id)).filter(
        PatientRecord.evaluation_status == "PENDING",
        PatientRecord.is_archived == False
    ).scalar() or 0

    # Tests summary
    tests_passed = db.query(func.count(LaboratoryTest.id)).filter(LaboratoryTest.status == "COMPLETED").scalar() or 0
    tests_failed = db.query(func.count(LaboratoryTest.id)).filter(LaboratoryTest.status == "FAILED").scalar() or 0
    tests_pending = db.query(func.count(LaboratoryTest.id)).filter(LaboratoryTest.status == "PENDING").scalar() or 0
    tests_inconclusive = db.query(func.count(LaboratoryTest.id)).filter(LaboratoryTest.status == "INCONCLUSIVE").scalar() or 0

    # Priority breakdown (approved classification policy)
    high_priority = db.query(func.count(PatientRecord.id)).filter(
        PatientRecord.urgency_category == UrgencyLevel.HIGH.value,
        PatientRecord.is_archived == False
    ).scalar() or 0

    med_priority = db.query(func.count(PatientRecord.id)).filter(
        PatientRecord.urgency_category == UrgencyLevel.MEDIUM.value,
        PatientRecord.is_archived == False
    ).scalar() or 0

    low_priority = db.query(func.count(PatientRecord.id)).filter(
        PatientRecord.urgency_category == UrgencyLevel.LOW.value,
        PatientRecord.is_archived == False
    ).scalar() or 0

    unclassified_priority = db.query(func.count(PatientRecord.id)).filter(
        PatientRecord.urgency_category == UrgencyLevel.UNCLASSIFIED.value,
        PatientRecord.is_archived == False
    ).scalar() or 0

    notifications_awaiting = db.query(func.count(Notification.id)).filter(
        Notification.recipient_user_id == current_user.id,
        Notification.is_read == False
    ).scalar() or 0

    summary_cards = SummaryCardsOut(
        total_registered_members=total_members,
        total_registered_patients=total_patients,
        total_registered_donors=total_donors,
        total_organs_available=total_organs_avail,
        total_open_organ_requests=total_open_requests,
        total_completed_transplants=total_completed_transplants,
        total_potential_matches_awaiting_review=matches_awaiting_review,
        total_approved_matches=approved_matches,
        total_pending_medical_evaluations=pending_evals,
        tests_summary={
            "passed": tests_passed,
            "failed": tests_failed,
            "pending": tests_pending,
            "inconclusive": tests_inconclusive
        },
        priority_summary={
            "high": high_priority,
            "medium": med_priority,
            "low": low_priority,
            "unclassified": unclassified_priority
        },
        total_notifications_awaiting=notifications_awaiting
    )

    # 2. Organ Inventory and Demand Table
    catalogs = db.query(OrganCatalog).all()
    demand_table = []
    now = datetime.now(timezone.utc)

    for cat in catalogs:
        # Available in inventory
        avail = db.query(func.count(OrganInventory.id)).filter(
            OrganInventory.organ_catalog_id == cat.id,
            OrganInventory.status.in_([OrganInventoryStatus.PROCURED.value, OrganInventoryStatus.PRESERVED.value])
        ).scalar() or 0

        # Open requests
        reqs = db.query(func.count(OrganRequest.id)).filter(
            OrganRequest.required_organ == cat.organ_type,
            OrganRequest.status == OrganRequestStatus.OPEN.value
        ).scalar() or 0

        # Potentially compatible candidates
        candidates = db.query(func.count(PatientRecord.id)).filter(
            PatientRecord.required_organ == cat.organ_type,
            PatientRecord.waiting_list_status == "ACTIVE",
            PatientRecord.is_archived == False
        ).scalar() or 0

        # Allocations in progress
        in_progress = db.query(func.count(OrganInventory.id)).filter(
            OrganInventory.organ_catalog_id == cat.id,
            OrganInventory.status.in_([OrganInventoryStatus.ALLOCATING.value, OrganInventoryStatus.TRANSPLANTING.value])
        ).scalar() or 0

        # Completed transplants for this organ
        completed = db.query(func.count(TransplantRecord.id)).join(OrganInventory).filter(
            OrganInventory.organ_catalog_id == cat.id
        ).scalar() or 0

        # Pending evaluations
        pending_e = db.query(func.count(PatientRecord.id)).filter(
            PatientRecord.required_organ == cat.organ_type,
            PatientRecord.evaluation_status == "PENDING"
        ).scalar() or 0

        demand_table.append(OrganInventoryDemandItem(
            organ_type=cat.organ_type,
            display_name=cat.display_name,
            available_inventory=avail,
            open_requests=reqs,
            potentially_compatible_candidates=candidates,
            allocations_in_progress=in_progress,
            completed_transplants=completed,
            pending_evaluations=pending_e,
            last_updated=now
        ))

    # 3. Quantum Performance Cards
    latest_exp = db.query(QuantumExperiment).order_by(QuantumExperiment.created_at.desc()).first()
    if latest_exp:
        total_benchmarks = db.query(func.count(QuantumExperiment.id)).scalar() or 1
        quantum_metrics = QuantumPerformanceCardsOut(
            is_benchmarked=True,
            status_label="Benchmarked",
            benchmark_instances=total_benchmarks,
            classical_solver_runtime_ms=latest_exp.classical_runtime_ms,
            quantum_solver_runtime_ms=latest_exp.quantum_runtime_ms,
            objective_score=latest_exp.objective_score,
            feasibility_rate=latest_exp.feasibility_rate,
            valid_allocations_found=latest_exp.num_organs,
            measured_speedup_ratio=latest_exp.measured_speedup,
            hardware_or_simulator=latest_exp.backend_name,
            benchmark_date=latest_exp.created_at
        )
    else:
        quantum_metrics = QuantumPerformanceCardsOut(
            is_benchmarked=False,
            status_label="Not yet benchmarked",
            benchmark_instances=0,
            hardware_or_simulator="qiskit_aer_simulator"
        )

    return DashboardAnalyticsOut(
        summary=summary_cards,
        organ_demand_table=demand_table,
        quantum_metrics=quantum_metrics
    )
