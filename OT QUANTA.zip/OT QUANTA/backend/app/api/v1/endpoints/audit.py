import math
from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import require_roles
from app.models.notification_audit import AuditEvent
from app.models.user import User
from app.models.enums import UserRole
from app.schemas.audit import AuditEventListResponse, AuditEventOut

router = APIRouter()

@router.get("/logs", response_model=AuditEventListResponse)
def list_audit_logs(
    page: int = Query(default=1, ge=1),
    size: int = Query(default=20, ge=1, le=100),
    action: Optional[str] = None,
    resource_type: Optional[str] = None,
    current_user: User = Depends(require_roles(UserRole.SYSTEM_ADMIN, UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    query = db.query(AuditEvent)
    if action:
        query = query.filter(AuditEvent.action == action.upper())
    if resource_type:
        query = query.filter(AuditEvent.resource_type == resource_type.upper())

    total = query.count()
    offset = (page - 1) * size
    events = query.order_by(AuditEvent.timestamp.desc()).offset(offset).limit(size).all()

    return AuditEventListResponse(
        items=[AuditEventOut.from_orm(e) for e in events],
        total=total,
        page=page,
        size=size
    )
