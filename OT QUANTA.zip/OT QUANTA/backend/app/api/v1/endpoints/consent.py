import os
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import get_current_user, require_roles
from app.models.document_consent import ConsentRecord, GeneratedReport
from app.models.crossmatch import MatchAssessment
from app.models.user import User
from app.models.enums import UserRole, NotificationEventType
from app.schemas.document import ConsentRecordCreate, ConsentRecordOut
from app.services.audit_service import record_audit_event
from app.services.pdf_service import generate_crossmatch_pdf
from app.services.notification_service import create_notification

router = APIRouter()

@router.post("", response_model=ConsentRecordOut, status_code=status.HTTP_201_CREATED)
def record_consent(
    payload: ConsentRecordCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    consent = ConsentRecord(
        record_type=payload.record_type,
        subject_id=payload.subject_id,
        legal_document_type=payload.legal_document_type,
        authorized_by_name=payload.authorized_by_name,
        relationship_to_subject=payload.relationship_to_subject,
        signature_digest=payload.signature_digest,
        witness_name=payload.witness_name,
        audit_reference=f"SIG-{uuid.uuid4().hex[:12].upper()}"
    )
    db.add(consent)
    db.commit()
    db.refresh(consent)

    record_audit_event(
        db=db,
        action="RECORD_LEGAL_CONSENT",
        resource_type="CONSENT_RECORD",
        resource_id=str(consent.id),
        user=current_user,
        changes={"type": payload.legal_document_type, "signee": payload.authorized_by_name}
    )
    return consent

@router.get("/{subject_id}", response_model=List[ConsentRecordOut])
def get_subject_consents(
    subject_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return db.query(ConsentRecord).filter(
        ConsentRecord.subject_id == subject_id,
        ConsentRecord.is_revoked == False
    ).all()

@router.post("/reports/{assessment_id}/generate-pdf", status_code=status.HTTP_201_CREATED)
def create_crossmatch_report_pdf(
    assessment_id: uuid.UUID,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.CLINICIAN, UserRole.TRANSPLANT_COORDINATOR, UserRole.LAB_REVIEWER
    )),
    db: Session = Depends(get_db)
):
    assessment = db.query(MatchAssessment).filter(MatchAssessment.id == assessment_id).first()
    if not assessment:
        raise HTTPException(status_code=404, detail="Crossmatch assessment not found.")

    output_filename = f"Crossmatch_Report_{assessment.assessment_code}_{uuid.uuid4().hex[:6]}.pdf"

    pdf_path, file_size, checksum = generate_crossmatch_pdf(
        assessment_id=str(assessment.id),
        assessment_code=assessment.assessment_code,
        patient_name=assessment.patient.full_name if assessment.patient else "Unknown",
        patient_code=assessment.patient.patient_code if assessment.patient else "PT-N/A",
        patient_bg=assessment.patient.blood_group if assessment.patient else "N/A",
        donor_name=assessment.donor.full_name if assessment.donor else "Unknown",
        donor_code=assessment.donor.donor_code if assessment.donor else "DN-N/A",
        donor_bg=assessment.donor.blood_group if assessment.donor else "N/A",
        organ_type=assessment.organ_type,
        compatibility_result=assessment.crossmatch_result,
        algorithm_version=assessment.algorithm_version,
        tests_completed=assessment.tests_completed or [],
        tests_pending=assessment.tests_pending or [],
        clinical_warnings=assessment.clinical_warnings or [],
        reviewer_name=assessment.reviewer.profile.full_name if assessment.reviewer and assessment.reviewer.profile else "Clinician Review Pending",
        review_status=assessment.review_status,
        output_filename=output_filename
    )

    report = GeneratedReport(
        report_type="CROSSMATCH_REPORT",
        reference_id=assessment.id,
        file_name=output_filename,
        file_path=pdf_path,
        file_size_bytes=file_size,
        generated_by_user_id=current_user.id,
        checksum=checksum
    )
    db.add(report)
    db.commit()
    db.refresh(report)

    record_audit_event(
        db=db,
        action="GENERATE_CROSSMATCH_PDF",
        resource_type="GENERATED_REPORT",
        resource_id=str(report.id),
        user=current_user,
        changes={"filename": output_filename, "checksum": checksum}
    )

    create_notification(
        db=db,
        recipient_user_id=current_user.id,
        event_type=NotificationEventType.PDF_REPORT_GENERATED,
        title="Crossmatch PDF Report Generated",
        message=f"Official PDF for assessment {assessment.assessment_code} has been created and securely archived.",
        related_record_id=report.id,
        related_record_type="GENERATED_REPORT"
    )

    return {
        "report_id": report.id,
        "file_name": output_filename,
        "file_size_bytes": file_size,
        "checksum": checksum,
        "download_url": f"/api/v1/consent/reports/{report.id}/download"
    }

@router.get("/reports/{report_id}/download")
def download_generated_report(
    report_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    report = db.query(GeneratedReport).filter(GeneratedReport.id == report_id).first()
    if not report or not os.path.exists(report.file_path):
        raise HTTPException(status_code=404, detail="Generated report PDF not found.")

    report.download_count += 1
    db.commit()

    record_audit_event(
        db=db,
        action="DOWNLOAD_PDF_REPORT",
        resource_type="GENERATED_REPORT",
        resource_id=str(report.id),
        user=current_user
    )

    return FileResponse(
        path=report.file_path,
        media_type="application/pdf",
        filename=report.file_name
    )
