import uuid
from typing import List
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import get_current_user, require_roles
from app.models.quantum import QuantumExperiment, QuantumBenchmarkResult
from app.models.user import User
from app.models.enums import UserRole
from app.schemas.quantum import (
    QuantumBenchmarkRunRequest, QuantumExperimentOut, QuantumComparisonResponse
)
from app.services.audit_service import record_audit_event
from quantum_optimizer.benchmark import run_allocation_benchmark

router = APIRouter()

@router.post("/benchmark", response_model=QuantumComparisonResponse)
def execute_quantum_benchmark(
    payload: QuantumBenchmarkRunRequest,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.CLINICIAN, UserRole.TRANSPLANT_COORDINATOR, UserRole.AUDITOR
    )),
    db: Session = Depends(get_db)
):
    """Run real classical vs. Qiskit quantum optimization benchmark on de-identified synthetic candidate instances."""
    res = run_allocation_benchmark(
        num_organs=payload.num_organs,
        num_candidates=payload.num_candidates,
        num_trials=3,
        penalty_weight=payload.penalty_weight,
        backend_name=payload.backend_type
    )

    count = db.query(QuantumExperiment).count()
    code = f"QEXP-{1000 + count + 1}"

    experiment = QuantumExperiment(
        experiment_code=code,
        title=res["title"],
        problem_size=res["problem_size"],
        num_candidates=res["num_candidates"],
        num_organs=res["num_organs"],
        classical_algorithm=res["classical_algorithm"],
        quantum_algorithm=res["quantum_algorithm"],
        backend_name=res["backend_name"],
        classical_runtime_ms=res["classical_runtime_ms"],
        quantum_runtime_ms=res["quantum_runtime_ms"],
        measured_speedup=res["measured_speedup"],
        objective_score=res["objective_score"],
        feasibility_rate=res["feasibility_rate"],
        constraint_violations=res["constraint_violations"],
        status="COMPLETED",
        limitations_notes=res["limitations_notes"]
    )
    db.add(experiment)
    db.flush()

    for trial in res["trials"]:
        br = QuantumBenchmarkResult(
            experiment_id=experiment.id,
            trial_index=trial["trial_index"],
            classical_time_ms=trial["classical_time_ms"],
            quantum_time_ms=trial["quantum_time_ms"],
            cost_value=trial["cost_value"],
            valid_solution=trial["valid_solution"]
        )
        db.add(br)

    db.commit()
    db.refresh(experiment)

    record_audit_event(
        db=db,
        action="RUN_QUANTUM_BENCHMARK",
        resource_type="QUANTUM_EXPERIMENT",
        resource_id=str(experiment.id),
        user=current_user,
        changes={"speedup": res["measured_speedup"], "classical_ms": res["classical_runtime_ms"], "quantum_ms": res["quantum_runtime_ms"]}
    )

    exp_out = QuantumExperimentOut.model_validate(experiment)
    return QuantumComparisonResponse(
        experiment=exp_out,
        classical_allocations=res["classical_allocations"],
        quantum_allocations=res["quantum_allocations"],
        speedup_ratio=res["measured_speedup"],
        feasibility_check_passed=(res["feasibility_rate"] == 1.0),
        summary=(
            f"Evaluated {res['num_organs']} organs against {res['num_candidates']} candidates. "
            f"Classical baseline: {res['classical_runtime_ms']} ms; Qiskit QUBO simulator: {res['quantum_runtime_ms']} ms. "
            f"Feasibility rate: {res['feasibility_rate'] * 100}%."
        ),
        disclaimer=res["limitations_notes"]
    )

@router.get("/experiments", response_model=List[QuantumExperimentOut])
def list_quantum_experiments(
    limit: int = 20,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    experiments = db.query(QuantumExperiment).order_by(QuantumExperiment.created_at.desc()).limit(limit).all()
    return experiments

@router.get("/experiments/{experiment_id}", response_model=QuantumExperimentOut)
def get_quantum_experiment(
    experiment_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    exp = db.query(QuantumExperiment).filter(QuantumExperiment.id == experiment_id).first()
    if not exp:
        raise HTTPException(status_code=404, detail="Quantum experiment not found.")
    return exp
