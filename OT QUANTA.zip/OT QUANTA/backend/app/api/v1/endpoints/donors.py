import uuid
import math
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import or_

from app.core.database import get_db
from app.core.deps import get_current_user, require_roles, verify_record_access
from app.models.clinical import DonorRecord
from app.models.user import User, Hospital
from app.models.enums import UserRole, DonorPathway, DonorEligibilityStatus
from app.schemas.donor import (
    DonorCreate, DonorUpdate, DonorOut, DonorListResponse
)
from app.services.audit_service import record_audit_event

router = APIRouter()

@router.get("", response_model=DonorListResponse)
def list_donors(
    page: int = Query(default=1, ge=1),
    size: int = Query(default=10, ge=1, le=100),
    search: Optional[str] = None,
    pathway: Optional[str] = None,
    eligibility: Optional[str] = None,
    hospital_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(DonorRecord).filter(DonorRecord.is_archived == False)

    # Record-level authorization
    if current_user.role == UserRole.DONOR.value:
        query = query.filter(DonorRecord.user_id == current_user.id)
    elif current_user.role in [UserRole.HOSPITAL_ADMIN.value, UserRole.CLINICIAN.value, UserRole.TRANSPLANT_COORDINATOR.value]:
        if current_user.hospital_id:
            query = query.filter(DonorRecord.hospital_id == current_user.hospital_id)

    if hospital_id and current_user.role in [UserRole.SYSTEM_ADMIN.value, UserRole.AUDITOR.value]:
        query = query.filter(DonorRecord.hospital_id == hospital_id)

    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            or_(
                DonorRecord.full_name.ilike(search_pattern),
                DonorRecord.donor_code.ilike(search_pattern)
            )
        )

    if pathway:
        query = query.filter(DonorRecord.donor_pathway == pathway.upper())

    if eligibility:
        query = query.filter(DonorRecord.eligibility_status == eligibility.upper())

    total = query.count()
    offset = (page - 1) * size
    donors = query.order_by(DonorRecord.created_at.desc()).offset(offset).limit(size).all()

    items = []
    for d in donors:
        d_dict = DonorOut.from_orm(d)
        if d.hospital:
            d_dict.hospital_name = d.hospital.name
        if d.reviewer and d.reviewer.profile:
            d_dict.reviewer_name = d.reviewer.profile.full_name
        items.append(d_dict)

    return DonorListResponse(
        items=items,
        total=total,
        page=page,
        size=size,
        pages=math.ceil(total / size) if size > 0 else 0
    )

@router.post("", response_model=DonorOut, status_code=status.HTTP_201_CREATED)
def create_donor(
    payload: DonorCreate,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN,
        UserRole.TRANSPLANT_COORDINATOR, UserRole.CLINICIAN
    )),
    db: Session = Depends(get_db)
):
    hospital = db.query(Hospital).filter(Hospital.id == payload.hospital_id).first()
    if not hospital:
        raise HTTPException(status_code=400, detail="Hospital not found.")

    count = db.query(DonorRecord).count()
    donor_code = f"DN-{hospital.code}-{1000 + count + 1}"

    donor_data = payload.dict()
    donor_data["donor_code"] = donor_code
    donor_data["blood_group"] = payload.blood_group.value if hasattr(payload.blood_group, "value") else str(payload.blood_group)
    donor_data["donor_pathway"] = payload.donor_pathway.value if hasattr(payload.donor_pathway, "value") else str(payload.donor_pathway)
    donor_data["eligibility_status"] = payload.eligibility_status.value if hasattr(payload.eligibility_status, "value") else str(payload.eligibility_status)
    donor_data["organs_offered"] = [o.value if hasattr(o, "value") else str(o) for o in payload.organs_offered]
    donor_data["assigned_reviewer_id"] = current_user.id

    donor = DonorRecord(**donor_data)
    db.add(donor)
    db.commit()
    db.refresh(donor)

    record_audit_event(
        db=db,
        action="CREATE_DONOR_RECORD",
        resource_type="DONOR_RECORD",
        resource_id=str(donor.id),
        user=current_user,
        changes={"donor_code": donor_code, "pathway": donor.donor_pathway}
    )

    out = DonorOut.from_orm(donor)
    out.hospital_name = hospital.name
    return out

@router.get("/{donor_id}", response_model=DonorOut)
def get_donor(
    donor_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    donor = db.query(DonorRecord).filter(
        DonorRecord.id == donor_id,
        DonorRecord.is_archived == False
    ).first()
    if not donor:
        raise HTTPException(status_code=404, detail="Donor record not found.")

    verify_record_access(
        current_user=current_user,
        record_user_id=donor.user_id,
        record_hospital_id=donor.hospital_id
    )

    out = DonorOut.from_orm(donor)
    if donor.hospital:
        out.hospital_name = donor.hospital.name
    if donor.reviewer and donor.reviewer.profile:
        out.reviewer_name = donor.reviewer.profile.full_name
    return out

@router.put("/{donor_id}", response_model=DonorOut)
def update_donor(
    donor_id: uuid.UUID,
    payload: DonorUpdate,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN,
        UserRole.TRANSPLANT_COORDINATOR, UserRole.CLINICIAN, UserRole.LAB_REVIEWER
    )),
    db: Session = Depends(get_db)
):
    donor = db.query(DonorRecord).filter(
        DonorRecord.id == donor_id,
        DonorRecord.is_archived == False
    ).first()
    if not donor:
        raise HTTPException(status_code=404, detail="Donor record not found.")

    verify_record_access(
        current_user=current_user,
        record_user_id=donor.user_id,
        record_hospital_id=donor.hospital_id
    )

    update_dict = payload.dict(exclude_unset=True)
    for field, val in update_dict.items():
        if val is not None:
            if field == "organs_offered":
                setattr(donor, field, [o.value if hasattr(o, "value") else str(o) for o in val])
            elif hasattr(val, "value"):
                setattr(donor, field, val.value)
            else:
                setattr(donor, field, val)

    db.commit()
    db.refresh(donor)

    record_audit_event(
        db=db,
        action="UPDATE_DONOR_RECORD",
        resource_type="DONOR_RECORD",
        resource_id=str(donor.id),
        user=current_user,
        changes=update_dict
    )

    out = DonorOut.from_orm(donor)
    if donor.hospital:
        out.hospital_name = donor.hospital.name
    return out

@router.delete("/{donor_id}", status_code=status.HTTP_200_OK)
def archive_donor(
    donor_id: uuid.UUID,
    current_user: User = Depends(require_roles(UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN)),
    db: Session = Depends(get_db)
):
    donor = db.query(DonorRecord).filter(
        DonorRecord.id == donor_id,
        DonorRecord.is_archived == False
    ).first()
    if not donor:
        raise HTTPException(status_code=404, detail="Donor record not found.")

    donor.is_archived = True
    db.commit()

    record_audit_event(
        db=db,
        action="ARCHIVE_DONOR_RECORD",
        resource_type="DONOR_RECORD",
        resource_id=str(donor.id),
        user=current_user
    )
    return {"message": "Donor record archived successfully. Audit trail preserved."}
