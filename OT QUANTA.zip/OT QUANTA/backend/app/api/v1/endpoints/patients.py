import uuid
import math
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import or_

from app.core.database import get_db
from app.core.deps import get_current_user, require_roles, verify_record_access
from app.models.clinical import PatientRecord
from app.models.organ import WaitingListEntry
from app.models.user import User, Hospital
from app.models.enums import UserRole, OrganType, UrgencyLevel
from app.schemas.patient import (
    PatientCreate, PatientUpdate, PatientOut, PatientListResponse
)
from app.services.audit_service import record_audit_event
from app.services.allocation_service import calculate_candidate_priority

router = APIRouter()

@router.get("", response_model=PatientListResponse)
def list_patients(
    page: int = Query(default=1, ge=1),
    size: int = Query(default=10, ge=1, le=100),
    search: Optional[str] = None,
    organ_type: Optional[str] = None,
    urgency: Optional[str] = None,
    hospital_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(PatientRecord).filter(PatientRecord.is_archived == False)

    # Record-level authorization
    if current_user.role == UserRole.PATIENT.value:
        query = query.filter(PatientRecord.user_id == current_user.id)
    elif current_user.role in [UserRole.HOSPITAL_ADMIN.value, UserRole.CLINICIAN.value, UserRole.TRANSPLANT_COORDINATOR.value]:
        if current_user.hospital_id:
            query = query.filter(PatientRecord.hospital_id == current_user.hospital_id)

    if hospital_id and current_user.role in [UserRole.SYSTEM_ADMIN.value, UserRole.AUDITOR.value]:
        query = query.filter(PatientRecord.hospital_id == hospital_id)

    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            or_(
                PatientRecord.full_name.ilike(search_pattern),
                PatientRecord.patient_code.ilike(search_pattern)
            )
        )

    if organ_type:
        query = query.filter(PatientRecord.required_organ == organ_type.upper())

    if urgency:
        query = query.filter(PatientRecord.urgency_category == urgency.upper())

    total = query.count()
    offset = (page - 1) * size
    patients = query.order_by(PatientRecord.created_at.desc()).offset(offset).limit(size).all()

    # Enrich hospital names and coordinator names
    items = []
    for p in patients:
        p_dict = PatientOut.from_orm(p)
        if p.hospital:
            p_dict.hospital_name = p.hospital.name
        if p.coordinator and p.coordinator.profile:
            p_dict.coordinator_name = p.coordinator.profile.full_name
        items.append(p_dict)

    return PatientListResponse(
        items=items,
        total=total,
        page=page,
        size=size,
        pages=math.ceil(total / size) if size > 0 else 0
    )

@router.post("", response_model=PatientOut, status_code=status.HTTP_201_CREATED)
def create_patient(
    payload: PatientCreate,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN,
        UserRole.TRANSPLANT_COORDINATOR, UserRole.CLINICIAN
    )),
    db: Session = Depends(get_db)
):
    # Verify hospital exists
    hospital = db.query(Hospital).filter(Hospital.id == payload.hospital_id).first()
    if not hospital:
        raise HTTPException(status_code=400, detail="Specified hospital does not exist.")

    # Duplicate check: check DOB and Name within the hospital
    existing = db.query(PatientRecord).filter(
        PatientRecord.full_name.ilike(payload.full_name),
        PatientRecord.date_of_birth == payload.date_of_birth,
        PatientRecord.hospital_id == payload.hospital_id,
        PatientRecord.is_archived == False
    ).first()
    if existing:
        raise HTTPException(status_code=409, detail="A patient with the same name and date of birth is already registered.")

    # Generate patient code
    count = db.query(PatientRecord).count()
    patient_code = f"PT-{hospital.code}-{1000 + count + 1}"

    patient_data = payload.dict()
    patient_data["patient_code"] = patient_code
    patient_data["blood_group"] = payload.blood_group.value if hasattr(payload.blood_group, "value") else str(payload.blood_group)
    patient_data["required_organ"] = payload.required_organ.value if hasattr(payload.required_organ, "value") else str(payload.required_organ)
    patient_data["urgency_category"] = payload.urgency_category.value if hasattr(payload.urgency_category, "value") else str(payload.urgency_category)
    patient_data["evaluation_status"] = "APPROVED"
    patient_data["waiting_list_status"] = "ACTIVE"
    patient_data["assigned_coordinator_id"] = current_user.id

    patient = PatientRecord(**patient_data)
    db.add(patient)
    db.flush()

    # Automatically add to active waiting list
    priority_score = calculate_candidate_priority(patient)
    waiting_entry = WaitingListEntry(
        patient_id=patient.id,
        organ_type=patient.required_organ,
        urgency_category=patient.urgency_category,
        calculated_priority=priority_score,
        status="ACTIVE"
    )
    db.add(waiting_entry)
    db.commit()
    db.refresh(patient)

    record_audit_event(
        db=db,
        action="CREATE_PATIENT_RECORD",
        resource_type="PATIENT_RECORD",
        resource_id=str(patient.id),
        user=current_user,
        changes={"patient_code": patient_code, "required_organ": patient.required_organ}
    )

    out = PatientOut.from_orm(patient)
    out.hospital_name = hospital.name
    return out

@router.get("/{patient_id}", response_model=PatientOut)
def get_patient(
    patient_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    patient = db.query(PatientRecord).filter(
        PatientRecord.id == patient_id,
        PatientRecord.is_archived == False
    ).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient record not found.")

    verify_record_access(
        current_user=current_user,
        record_user_id=patient.user_id,
        record_hospital_id=patient.hospital_id
    )

    out = PatientOut.from_orm(patient)
    if patient.hospital:
        out.hospital_name = patient.hospital.name
    if patient.coordinator and patient.coordinator.profile:
        out.coordinator_name = patient.coordinator.profile.full_name
    return out

@router.put("/{patient_id}", response_model=PatientOut)
def update_patient(
    patient_id: uuid.UUID,
    payload: PatientUpdate,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN,
        UserRole.TRANSPLANT_COORDINATOR, UserRole.CLINICIAN
    )),
    db: Session = Depends(get_db)
):
    patient = db.query(PatientRecord).filter(
        PatientRecord.id == patient_id,
        PatientRecord.is_archived == False
    ).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient record not found.")

    verify_record_access(
        current_user=current_user,
        record_user_id=patient.user_id,
        record_hospital_id=patient.hospital_id
    )

    update_dict = payload.dict(exclude_unset=True)
    for field, val in update_dict.items():
        if val is not None:
            if hasattr(val, "value"):
                setattr(patient, field, val.value)
            else:
                setattr(patient, field, val)

    # Recalculate priority if urgency scores changed
    waiting_entry = db.query(WaitingListEntry).filter(WaitingListEntry.patient_id == patient.id).first()
    if waiting_entry:
        waiting_entry.calculated_priority = calculate_candidate_priority(patient)
        waiting_entry.urgency_category = patient.urgency_category

    db.commit()
    db.refresh(patient)

    record_audit_event(
        db=db,
        action="UPDATE_PATIENT_RECORD",
        resource_type="PATIENT_RECORD",
        resource_id=str(patient.id),
        user=current_user,
        changes=update_dict
    )

    out = PatientOut.from_orm(patient)
    if patient.hospital:
        out.hospital_name = patient.hospital.name
    return out

@router.delete("/{patient_id}", status_code=status.HTTP_200_OK)
def archive_patient(
    patient_id: uuid.UUID,
    current_user: User = Depends(require_roles(UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN)),
    db: Session = Depends(get_db)
):
    """Safely archive patient record preserving legally required clinical history."""
    patient = db.query(PatientRecord).filter(
        PatientRecord.id == patient_id,
        PatientRecord.is_archived == False
    ).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient record not found.")

    patient.is_archived = True
    patient.waiting_list_status = "REMOVED"
    
    # Remove from active waiting list
    db.query(WaitingListEntry).filter(WaitingListEntry.patient_id == patient.id).update({"status": "REMOVED"})
    db.commit()

    record_audit_event(
        db=db,
        action="ARCHIVE_PATIENT_RECORD",
        resource_type="PATIENT_RECORD",
        resource_id=str(patient.id),
        user=current_user
    )
    return {"message": "Patient record archived successfully. Audit trail preserved."}
