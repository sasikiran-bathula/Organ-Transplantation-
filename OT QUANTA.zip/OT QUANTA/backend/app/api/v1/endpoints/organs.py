import uuid
from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import get_current_user, require_roles
from app.models.organ import OrganCatalog, OrganInventory, OrganRequest, WaitingListEntry
from app.models.clinical import PatientRecord, DonorRecord
from app.models.user import User, Hospital
from app.models.enums import UserRole, OrganType, UrgencyLevel, OrganInventoryStatus, OrganRequestStatus, NotificationEventType
from app.schemas.organ import (
    OrganCatalogOut, OrganInventoryCreate, OrganInventoryUpdate, OrganInventoryOut,
    OrganRequestCreate, OrganRequestUpdate, OrganRequestOut, WaitingListEntryOut
)
from app.services.audit_service import record_audit_event
from app.services.notification_service import create_notification, notify_hospital_coordinators

router = APIRouter()

# 1. Organ Catalog
@router.get("/catalog", response_model=List[OrganCatalogOut])
def get_organ_catalog(db: Session = Depends(get_db)):
    catalog = db.query(OrganCatalog).all()
    if not catalog:
        # Pre-seed standard catalog if empty
        standards = [
            {"organ_type": OrganType.HEART.value, "display_name": "Heart", "max_ischemia_hours": 4.0, "requires_hla_match": True, "requires_size_match": True, "description": "Cardiac graft requiring rapid static cold storage or ex-vivo perfusion."},
            {"organ_type": OrganType.LUNGS.value, "display_name": "Lungs", "max_ischemia_hours": 6.0, "requires_hla_match": True, "requires_size_match": True, "description": "Pulmonary graft with strict thoracic sizing compatibility."},
            {"organ_type": OrganType.KIDNEY.value, "display_name": "Kidney", "max_ischemia_hours": 24.0, "requires_hla_match": True, "requires_size_match": False, "description": "Renal graft with extended cold ischemia resistance and HLA matching priority."},
            {"organ_type": OrganType.LIVER.value, "display_name": "Liver", "max_ischemia_hours": 12.0, "requires_hla_match": False, "requires_size_match": True, "description": "Hepatic graft allocated primarily via MELD severity index."},
            {"organ_type": OrganType.PANCREAS.value, "display_name": "Pancreas", "max_ischemia_hours": 12.0, "requires_hla_match": True, "requires_size_match": False, "description": "Pancreatic vascularized graft for insulin-dependent metabolic stabilization."},
            {"organ_type": OrganType.CORNEAS.value, "display_name": "Corneas / Eyes", "max_ischemia_hours": 168.0, "requires_hla_match": False, "requires_size_match": False, "description": "Immune-privileged ocular tissue suitable for refrigerated media preservation."},
            {"organ_type": OrganType.BONE_MARROW.value, "display_name": "Bone Marrow", "max_ischemia_hours": 48.0, "requires_hla_match": True, "requires_size_match": False, "description": "Hematopoietic stem cell graft requiring strict high-resolution HLA allele matching."},
            {"organ_type": OrganType.UTERUS.value, "display_name": "Uterus", "max_ischemia_hours": 6.0, "requires_hla_match": True, "requires_size_match": True, "description": "Vascularized composite allograft for reproductive restoration."},
            {"organ_type": OrganType.OTHER.value, "display_name": "Other Tissues", "max_ischemia_hours": 24.0, "requires_hla_match": False, "requires_size_match": False, "description": "Configurable musculoskeletal or vascular tissue grafts."}
        ]
        for s in standards:
            db.add(OrganCatalog(**s))
        db.commit()
        catalog = db.query(OrganCatalog).all()
    return catalog

# 2. Organ Inventory
@router.get("/inventory", response_model=List[OrganInventoryOut])
def list_organ_inventory(
    status_filter: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(OrganInventory)
    if status_filter:
        query = query.filter(OrganInventory.status == status_filter.upper())
    
    items = query.order_by(OrganInventory.procurement_timestamp.desc()).all()
    results = []
    now = datetime.now(timezone.utc)

    for item in items:
        out = OrganInventoryOut.from_orm(item)
        if item.catalog_item:
            out.organ_type = item.catalog_item.display_name
            out.max_ischemia_hours = item.catalog_item.max_ischemia_hours
        if item.donor:
            out.donor_code = item.donor.donor_code
            out.donor_blood_group = item.donor.blood_group
        if item.hospital:
            out.hospital_name = item.hospital.name
        
        # Calculate cold ischemia elapsed hours
        if item.cold_ischemia_start:
            elapsed = (now - item.cold_ischemia_start.replace(tzinfo=timezone.utc)).total_seconds() / 3600.0
            out.ischemia_elapsed_hours = round(max(0.0, elapsed), 2)
            
        results.append(out)
    return results

@router.post("/inventory", response_model=OrganInventoryOut, status_code=status.HTTP_201_CREATED)
def create_organ_inventory(
    payload: OrganInventoryCreate,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN,
        UserRole.TRANSPLANT_COORDINATOR, UserRole.CLINICIAN
    )),
    db: Session = Depends(get_db)
):
    # Verify donor and catalog item exist
    donor = db.query(DonorRecord).filter(DonorRecord.id == payload.donor_id).first()
    if not donor:
        raise HTTPException(status_code=400, detail="Donor record not found.")

    catalog_item = db.query(OrganCatalog).filter(OrganCatalog.id == payload.organ_catalog_id).first()
    if not catalog_item:
        raise HTTPException(status_code=400, detail="Organ catalog item not found.")

    now = datetime.now(timezone.utc)
    item = OrganInventory(
        organ_catalog_id=payload.organ_catalog_id,
        donor_id=payload.donor_id,
        hospital_id=payload.hospital_id,
        procurement_timestamp=payload.procurement_timestamp or now,
        preservation_method=payload.preservation_method,
        cold_ischemia_start=payload.cold_ischemia_start or now,
        status=OrganInventoryStatus.PROCURED.value,
        storage_location=payload.storage_location,
        notes=payload.notes
    )
    db.add(item)
    db.commit()
    db.refresh(item)

    record_audit_event(
        db=db,
        action="PROCURE_ORGAN_INVENTORY",
        resource_type="ORGAN_INVENTORY",
        resource_id=str(item.id),
        user=current_user,
        changes={"organ": catalog_item.organ_type, "donor": donor.donor_code}
    )

    # Broadcast notification to hospital coordinators
    notify_hospital_coordinators(
        db=db,
        hospital_id=payload.hospital_id,
        event_type=NotificationEventType.NEW_POTENTIAL_MATCH,
        title=f"New {catalog_item.display_name} Procured",
        message=f"{catalog_item.display_name} from donor {donor.donor_code} is now available in inventory. Review matching candidates.",
        related_record_id=item.id,
        related_record_type="ORGAN_INVENTORY"
    )

    out = OrganInventoryOut.from_orm(item)
    out.organ_type = catalog_item.display_name
    out.donor_code = donor.donor_code
    out.donor_blood_group = donor.blood_group
    out.max_ischemia_hours = catalog_item.max_ischemia_hours
    out.ischemia_elapsed_hours = 0.0
    return out

# 3. Organ Requests
@router.get("/requests", response_model=List[OrganRequestOut])
def list_organ_requests(
    status_filter: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(OrganRequest)
    if status_filter:
        query = query.filter(OrganRequest.status == status_filter.upper())
    
    # If patient, only view their own requests
    if current_user.role == UserRole.PATIENT.value:
        query = query.join(PatientRecord).filter(PatientRecord.user_id == current_user.id)
    elif current_user.role in [UserRole.HOSPITAL_ADMIN.value, UserRole.CLINICIAN.value, UserRole.TRANSPLANT_COORDINATOR.value]:
        if current_user.hospital_id:
            query = query.filter(OrganRequest.hospital_id == current_user.hospital_id)

    requests = query.order_by(OrganRequest.created_at.desc()).all()
    results = []
    for r in requests:
        out = OrganRequestOut.from_orm(r)
        if r.patient:
            out.patient_code = r.patient.patient_code
            out.patient_name = r.patient.full_name
            out.blood_group = r.patient.blood_group
        if r.hospital:
            out.hospital_name = r.hospital.name
        results.append(out)
    return results

@router.post("/requests", response_model=OrganRequestOut, status_code=status.HTTP_201_CREATED)
def submit_organ_request(
    payload: OrganRequestCreate,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN,
        UserRole.TRANSPLANT_COORDINATOR, UserRole.CLINICIAN
    )),
    db: Session = Depends(get_db)
):
    patient = db.query(PatientRecord).filter(PatientRecord.id == payload.patient_id).first()
    if not patient:
        raise HTTPException(status_code=400, detail="Patient record not found.")

    hospital = db.query(Hospital).filter(Hospital.id == payload.hospital_id).first()
    if not hospital:
        raise HTTPException(status_code=400, detail="Hospital not found.")

    count = db.query(OrganRequest).count()
    request_code = f"REQ-{hospital.code}-{1000 + count + 1}"

    req = OrganRequest(
        request_code=request_code,
        patient_id=payload.patient_id,
        hospital_id=payload.hospital_id,
        required_organ=payload.required_organ.value if hasattr(payload.required_organ, "value") else str(payload.required_organ),
        urgency_level=payload.urgency_level.value if hasattr(payload.urgency_level, "value") else str(payload.urgency_level),
        status=OrganRequestStatus.OPEN.value,
        living_or_deceased_preference=payload.living_or_deceased_preference,
        clinical_summary=payload.clinical_summary
    )
    db.add(req)
    db.commit()
    db.refresh(req)

    record_audit_event(
        db=db,
        action="SUBMIT_ORGAN_REQUEST",
        resource_type="ORGAN_REQUEST",
        resource_id=str(req.id),
        user=current_user,
        changes={"request_code": request_code, "organ": req.required_organ}
    )

    # Persistent notification to coordinators
    notify_hospital_coordinators(
        db=db,
        hospital_id=payload.hospital_id,
        event_type=NotificationEventType.NEW_ORGAN_REQUEST,
        title=f"New Organ Request: {req.required_organ}",
        message=f"Request {request_code} logged for patient {patient.full_name} ({patient.patient_code}). Urgency: {req.urgency_level}.",
        related_record_id=req.id,
        related_record_type="ORGAN_REQUEST"
    )

    out = OrganRequestOut.from_orm(req)
    out.patient_code = patient.patient_code
    out.patient_name = patient.full_name
    out.blood_group = patient.blood_group
    out.hospital_name = hospital.name
    return out

# 4. Waiting List
@router.get("/waiting-list", response_model=List[WaitingListEntryOut])
def get_waiting_list(
    organ_type: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(WaitingListEntry).filter(WaitingListEntry.status == "ACTIVE")
    if organ_type:
        query = query.filter(WaitingListEntry.organ_type == organ_type.upper())

    entries = query.order_by(WaitingListEntry.calculated_priority.desc()).all()
    results = []
    for e in entries:
        out = WaitingListEntryOut.from_orm(e)
        if e.patient:
            out.patient_code = e.patient.patient_code
            out.patient_name = e.patient.full_name
        results.append(out)
    return results
