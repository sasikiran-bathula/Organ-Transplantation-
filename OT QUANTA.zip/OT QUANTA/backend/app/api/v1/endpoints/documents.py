import os
import uuid
from datetime import datetime, timezone
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.config import settings
from app.core.deps import get_current_user, require_roles, verify_record_access
from app.models.clinical import MedicalDocument, PatientRecord, DonorRecord
from app.models.user import User
from app.models.enums import UserRole, NotificationEventType
from app.schemas.document import DocumentOut, DocumentExtractionVerify, GeminiMedicalExtraction
from app.services.audit_service import record_audit_event
from app.services.gemini_service import extract_medical_document_data
from app.services.notification_service import create_notification

router = APIRouter()

ALLOWED_MIME_TYPES = ["application/pdf", "image/png", "image/jpeg", "text/plain"]
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB

@router.post("/upload", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_medical_document(
    record_type: str = Form(..., description="'PATIENT' or 'DONOR'"),
    record_id: uuid.UUID = Form(...),
    classification: str = Form(default="LAB_REPORT"),
    file: UploadFile = File(...),
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN,
        UserRole.TRANSPLANT_COORDINATOR, UserRole.CLINICIAN, UserRole.LAB_REVIEWER
    )),
    db: Session = Depends(get_db)
):
    record_type_norm = record_type.upper()
    if record_type_norm not in ["PATIENT", "DONOR"]:
        raise HTTPException(status_code=400, detail="record_type must be PATIENT or DONOR")

    # Verify subject record exists
    if record_type_norm == "PATIENT":
        record = db.query(PatientRecord).filter(PatientRecord.id == record_id).first()
    else:
        record = db.query(DonorRecord).filter(DonorRecord.id == record_id).first()

    if not record:
        raise HTTPException(status_code=404, detail=f"Target {record_type} record not found.")

    verify_record_access(current_user=current_user, record_hospital_id=record.hospital_id)

    # Validate file type and read contents
    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="File exceeds maximum allowed size of 10MB.")

    # Storage destination
    doc_dir = os.path.join(settings.STORAGE_DIR, "documents")
    os.makedirs(doc_dir, exist_ok=True)
    file_id = uuid.uuid4()
    safe_filename = f"{file_id}_{file.filename.replace(' ', '_')}"
    full_path = os.path.join(doc_dir, safe_filename)

    with open(full_path, "wb") as f:
        f.write(content)

    doc = MedicalDocument(
        id=file_id,
        record_type=record_type_norm,
        record_id=record_id,
        file_name=file.filename,
        file_path=full_path,
        file_size_bytes=len(content),
        mime_type=file.content_type or "application/octet-stream",
        classification=classification,
        processing_status="UPLOADED"
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    record_audit_event(
        db=db,
        action="UPLOAD_MEDICAL_DOCUMENT",
        resource_type="MEDICAL_DOCUMENT",
        resource_id=str(doc.id),
        user=current_user,
        changes={"filename": file.filename, "size": len(content)}
    )

    return doc

@router.get("/{document_id}/download")
def download_medical_document(
    document_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    doc = db.query(MedicalDocument).filter(MedicalDocument.id == document_id).first()
    if not doc or not os.path.exists(doc.file_path):
        raise HTTPException(status_code=404, detail="Medical document not found.")

    # Verify access to target subject
    if doc.record_type == "PATIENT":
        pat = db.query(PatientRecord).filter(PatientRecord.id == doc.record_id).first()
        if pat:
            verify_record_access(current_user, pat.user_id, pat.hospital_id)
    elif doc.record_type == "DONOR":
        dnr = db.query(DonorRecord).filter(DonorRecord.id == doc.record_id).first()
        if dnr:
            verify_record_access(current_user, dnr.user_id, dnr.hospital_id)

    record_audit_event(
        db=db,
        action="DOWNLOAD_MEDICAL_DOCUMENT",
        resource_type="MEDICAL_DOCUMENT",
        resource_id=str(doc.id),
        user=current_user
    )

    return FileResponse(
        path=doc.file_path,
        media_type=doc.mime_type,
        filename=doc.file_name
    )

@router.post("/{document_id}/extract", response_model=DocumentOut)
def trigger_gemini_extraction(
    document_id: uuid.UUID,
    current_user: User = Depends(require_roles(
        UserRole.SYSTEM_ADMIN, UserRole.CLINICIAN,
        UserRole.LAB_REVIEWER, UserRole.TRANSPLANT_COORDINATOR
    )),
    db: Session = Depends(get_db)
):
    """Run AI-assisted document extraction using Gemini or clinical rule parser."""
    doc = db.query(MedicalDocument).filter(MedicalDocument.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Medical document not found.")

    doc.processing_status = "EXTRACTING"
    db.commit()

    try:
        extraction: GeminiMedicalExtraction = extract_medical_document_data(
            file_path=doc.file_path,
            file_name=doc.file_name,
            classification=doc.classification
        )
        doc.extracted_data = extraction.dict()
        doc.processing_status = "EXTRACTED"
    except Exception as e:
        doc.processing_status = "FAILED"
        db.commit()
        raise HTTPException(status_code=500, detail=f"Document extraction failed: {str(e)}")

    db.commit()
    db.refresh(doc)

    record_audit_event(
        db=db,
        action="GEMINI_DOCUMENT_EXTRACTION",
        resource_type="MEDICAL_DOCUMENT",
        resource_id=str(doc.id),
        user=current_user,
        changes={"status": doc.processing_status}
    )
    return doc

@router.post("/{document_id}/verify", response_model=DocumentOut)
def verify_document_extraction(
    document_id: uuid.UUID,
    payload: DocumentExtractionVerify,
    current_user: User = Depends(require_roles(
        UserRole.CLINICIAN, UserRole.LAB_REVIEWER, UserRole.SYSTEM_ADMIN
    )),
    db: Session = Depends(get_db)
):
    """Mandatory clinician review barrier before applying extracted fields into clinical record."""
    doc = db.query(MedicalDocument).filter(MedicalDocument.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Medical document not found.")

    doc.processing_status = "VERIFIED"
    doc.human_verified_by = current_user.id
    doc.human_verified_at = datetime.now(timezone.utc)
    doc.verification_notes = payload.verification_notes
    doc.extracted_data = payload.verified_data

    # Optionally update target record if clinician chose apply_to_record
    if payload.apply_to_record:
        if doc.record_type == "PATIENT":
            pat = db.query(PatientRecord).filter(PatientRecord.id == doc.record_id).first()
            if pat and "blood_group_detected" in payload.verified_data:
                pat.blood_group = payload.verified_data["blood_group_detected"]
        elif doc.record_type == "DONOR":
            dnr = db.query(DonorRecord).filter(DonorRecord.id == doc.record_id).first()
            if dnr:
                if "blood_group_detected" in payload.verified_data:
                    dnr.blood_group = payload.verified_data["blood_group_detected"]
                if "hla_loci_detected" in payload.verified_data:
                    dnr.hla_typing = payload.verified_data["hla_loci_detected"]

    db.commit()
    db.refresh(doc)

    record_audit_event(
        db=db,
        action="VERIFY_DOCUMENT_EXTRACTION",
        resource_type="MEDICAL_DOCUMENT",
        resource_id=str(doc.id),
        user=current_user,
        changes={"verified_by": str(current_user.id), "notes": payload.verification_notes}
    )
    return doc

@router.get("/by-record/{record_type}/{record_id}", response_model=List[DocumentOut])
def list_record_documents(
    record_type: str,
    record_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    docs = db.query(MedicalDocument).filter(
        MedicalDocument.record_type == record_type.upper(),
        MedicalDocument.record_id == record_id,
        MedicalDocument.is_archived == False
    ).all()
    return docs
