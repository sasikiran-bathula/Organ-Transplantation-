import uuid
from datetime import datetime, timezone, timedelta
from typing import Any
from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import hash_password, verify_password, create_access_token
from app.core.config import settings
from app.core.deps import get_current_user
from app.models.user import User, UserProfile, SessionModel, Hospital
from app.models.enums import UserRole, NotificationEventType
from app.schemas.auth import (
    Token, UserRegister, UserLogin, UserOut, UserProfileOut,
    OAuthLoginRequest, PasswordResetRequest, PasswordResetConfirm
)
from app.services.audit_service import record_audit_event
from app.services.notification_service import create_notification

router = APIRouter()

@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register_user(
    payload: UserRegister,
    request: Request,
    db: Session = Depends(get_db)
):
    # Check duplicate email
    existing_user = db.query(User).filter(User.email == payload.email.lower()).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="An account with this email already exists.")

    # Restrict unprivileged users from registering as SYSTEM_ADMIN or AUDITOR directly
    assigned_role = payload.role.value if hasattr(payload.role, "value") else str(payload.role)
    if assigned_role in [UserRole.SYSTEM_ADMIN.value, UserRole.AUDITOR.value]:
        # Fallback to PATIENT or COORDINATOR unless configured
        assigned_role = UserRole.PATIENT.value

    user = User(
        email=payload.email.lower(),
        hashed_password=hash_password(payload.password),
        role=assigned_role,
        hospital_id=payload.hospital_id,
        is_active=True,
        is_verified=True  # In dev/demo, auto-verify
    )
    db.add(user)
    db.flush()

    profile = UserProfile(
        user_id=user.id,
        full_name=payload.full_name,
        phone_number=payload.phone_number,
        preferences={"email_alerts": True, "push_alerts": True}
    )
    db.add(profile)
    db.commit()
    db.refresh(user)

    # Log audit event
    record_audit_event(
        db=db,
        action="USER_REGISTRATION",
        resource_type="USER",
        resource_id=str(user.id),
        user=user,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent")
    )

    # Welcome notification
    create_notification(
        db=db,
        recipient_user_id=user.id,
        event_type=NotificationEventType.SECURITY_ALERT,
        title="Welcome to QuantaOrgan",
        message="Your healthcare profile has been created and verified. Complete your clinical profile to proceed."
    )

    return user

@router.post("/login", response_model=Token)
def login_user(
    payload: UserLogin,
    request: Request,
    db: Session = Depends(get_db)
):
    search_email = payload.email.lower()
    user = db.query(User).filter(User.email == search_email).first()
    if not user:
        if search_email.endswith("@quantaorgan.demo"):
            alt_email = search_email.replace("@quantaorgan.demo", "@transplantcare.demo")
            user = db.query(User).filter(User.email == alt_email).first()
        elif search_email.endswith("@transplantcare.demo"):
            alt_email = search_email.replace("@transplantcare.demo", "@quantaorgan.demo")
            user = db.query(User).filter(User.email == alt_email).first()

    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account is deactivated.")

    # Create session
    token = create_access_token(subject=str(user.id))
    session = SessionModel(
        user_id=user.id,
        token=token,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    db.add(session)
    db.commit()

    record_audit_event(
        db=db,
        action="USER_LOGIN",
        resource_type="SESSION",
        resource_id=str(session.id),
        user=user,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent")
    )

    return Token(
        access_token=token,
        token_type="bearer",
        user_id=user.id,
        email=user.email,
        role=user.role,
        full_name=user.profile.full_name if user.profile else user.email,
        hospital_id=user.hospital_id
    )

@router.post("/token", response_model=Token)
def login_oauth2_form(
    form_data: OAuth2PasswordRequestForm = Depends(),
    request: Request = None,
    db: Session = Depends(get_db)
):
    """OAuth2 compatible token endpoint."""
    user = db.query(User).filter(User.email == form_data.username.lower()).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect email or password")
    
    token = create_access_token(subject=str(user.id))
    return Token(
        access_token=token,
        token_type="bearer",
        user_id=user.id,
        email=user.email,
        role=user.role,
        full_name=user.profile.full_name if user.profile else user.email,
        hospital_id=user.hospital_id
    )

@router.post("/oauth", response_model=Token)
def oauth_login(
    payload: OAuthLoginRequest,
    request: Request,
    db: Session = Depends(get_db)
):
    """Google and Facebook OAuth federated login."""
    if not payload.email:
        raise HTTPException(status_code=400, detail="OAuth provider did not return an email.")

    user = db.query(User).filter(User.email == payload.email.lower()).first()
    if not user:
        # Register new federated user
        user = User(
            email=payload.email.lower(),
            hashed_password=hash_password(uuid.uuid4().hex),
            role=UserRole.PATIENT.value,
            is_active=True,
            is_verified=True
        )
        db.add(user)
        db.flush()

        profile = UserProfile(
            user_id=user.id,
            full_name=payload.full_name or payload.email.split("@")[0],
            preferences={"oauth_provider": payload.provider}
        )
        db.add(profile)
        db.commit()
        db.refresh(user)

    token = create_access_token(subject=str(user.id))
    return Token(
        access_token=token,
        token_type="bearer",
        user_id=user.id,
        email=user.email,
        role=user.role,
        full_name=user.profile.full_name if user.profile else user.email,
        hospital_id=user.hospital_id
    )

@router.post("/logout", status_code=status.HTTP_200_OK)
def logout_user(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Revoke active sessions
    db.query(SessionModel).filter(
        SessionModel.user_id == current_user.id,
        SessionModel.is_revoked == False
    ).update({"is_revoked": True})
    db.commit()

    record_audit_event(
        db=db,
        action="USER_LOGOUT",
        resource_type="SESSION",
        user=current_user
    )
    return {"message": "Successfully logged out and revoked active sessions."}

@router.get("/me", response_model=UserOut)
def get_current_user_profile(
    current_user: User = Depends(get_current_user)
):
    return current_user

@router.post("/forgot-password")
def request_password_reset(payload: PasswordResetRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email.lower()).first()
    # Always return 200 to prevent user enumeration
    if user:
        reset_token = create_access_token(subject=str(user.id), expires_delta=timedelta(hours=1))
        # Simulated email dispatch
        create_notification(
            db=db,
            recipient_user_id=user.id,
            event_type=NotificationEventType.SECURITY_ALERT,
            title="Password Reset Requested",
            message=f"Use token {reset_token[:12]}... to reset your password."
        )
    return {"message": "If this email is registered, recovery instructions have been dispatched."}
