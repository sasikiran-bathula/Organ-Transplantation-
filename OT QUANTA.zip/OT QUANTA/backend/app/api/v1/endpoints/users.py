import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr

from app.core.database import get_db
from app.core.deps import get_current_user, require_roles
from app.models.user import User, UserProfile, Hospital
from app.models.enums import UserRole
from app.schemas.auth import UserOut, UserProfileOut
from app.services.audit_service import record_audit_event

router = APIRouter()

class HospitalCreate(BaseModel):
    name: str
    code: str
    city: str
    state: str
    country: str = "United States"
    contact_email: EmailStr
    contact_phone: str

class HospitalOut(BaseModel):
    id: uuid.UUID
    name: str
    code: str
    city: str
    state: str
    country: str
    contact_email: str
    contact_phone: str
    is_active: bool

    class Config:
        from_attributes = True

class ProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    phone_number: Optional[str] = None
    address: Optional[str] = None
    emergency_contact: Optional[str] = None
    preferences: Optional[dict] = None

@router.get("/hospitals", response_model=List[HospitalOut])
def list_hospitals(db: Session = Depends(get_db)):
    return db.query(Hospital).filter(Hospital.is_active == True).all()

@router.post("/hospitals", response_model=HospitalOut, status_code=status.HTTP_201_CREATED)
def create_hospital(
    payload: HospitalCreate,
    current_user: User = Depends(require_roles(UserRole.SYSTEM_ADMIN)),
    db: Session = Depends(get_db)
):
    existing = db.query(Hospital).filter((Hospital.name == payload.name) | (Hospital.code == payload.code)).first()
    if existing:
        raise HTTPException(status_code=400, detail="Hospital with this name or code already exists.")
    hospital = Hospital(**payload.dict())
    db.add(hospital)
    db.commit()
    db.refresh(hospital)

    record_audit_event(
        db=db,
        action="CREATE_HOSPITAL",
        resource_type="HOSPITAL",
        resource_id=str(hospital.id),
        user=current_user,
        changes=payload.dict()
    )
    return hospital

@router.get("", response_model=List[UserOut])
def list_users(
    skip: int = 0,
    limit: int = 50,
    current_user: User = Depends(require_roles(UserRole.SYSTEM_ADMIN, UserRole.HOSPITAL_ADMIN, UserRole.AUDITOR)),
    db: Session = Depends(get_db)
):
    query = db.query(User)
    if current_user.role == UserRole.HOSPITAL_ADMIN.value and current_user.hospital_id:
        query = query.filter(User.hospital_id == current_user.hospital_id)
    return query.offset(skip).limit(limit).all()

@router.put("/profile", response_model=UserProfileOut)
def update_profile(
    payload: ProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    profile = current_user.profile
    if not profile:
        profile = UserProfile(user_id=current_user.id, full_name=current_user.email)
        db.add(profile)

    update_dict = payload.dict(exclude_unset=True)
    for field, val in update_dict.items():
        setattr(profile, field, val)

    db.commit()
    db.refresh(profile)

    record_audit_event(
        db=db,
        action="UPDATE_PROFILE",
        resource_type="USER_PROFILE",
        resource_id=str(profile.id),
        user=current_user,
        changes=update_dict
    )
    return profile
