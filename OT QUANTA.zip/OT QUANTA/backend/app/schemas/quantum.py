import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, ConfigDict

class QuantumBenchmarkRunRequest(BaseModel):
    num_candidates: int = Field(default=8, ge=2, le=50, description="Synthetic candidate benchmark count")
    num_organs: int = Field(default=4, ge=1, le=20, description="Available organ count")
    penalty_weight: float = Field(default=10.0, description="QUBO constraint penalty multiplier")
    backend_type: str = Field(default="aer_simulator_statevector", description="Qiskit simulator or statevector")
    shots: int = Field(default=1024, ge=100, le=10000)

class QuantumTrialResultOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    trial_index: int
    classical_time_ms: float
    quantum_time_ms: float
    cost_value: float
    valid_solution: bool

class QuantumExperimentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    experiment_code: str
    title: str
    problem_size: int
    num_candidates: int
    num_organs: int
    classical_algorithm: str
    quantum_algorithm: str
    backend_name: str
    classical_runtime_ms: Optional[float] = None
    quantum_runtime_ms: Optional[float] = None
    measured_speedup: Optional[float] = None
    objective_score: Optional[float] = None
    feasibility_rate: float
    constraint_violations: int
    status: str
    limitations_notes: Optional[str] = None
    created_at: datetime
    benchmark_trials: List[QuantumTrialResultOut] = []

class QuantumComparisonResponse(BaseModel):
    experiment: QuantumExperimentOut
    classical_allocations: List[Dict[str, Any]]
    quantum_allocations: List[Dict[str, Any]]
    speedup_ratio: Optional[float]
    feasibility_check_passed: bool
    summary: str
    disclaimer: str
