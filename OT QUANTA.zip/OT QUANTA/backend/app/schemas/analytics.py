from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel

class SummaryCardsOut(BaseModel):
    total_registered_members: int
    total_registered_patients: int
    total_registered_donors: int
    total_organs_available: int
    total_open_organ_requests: int
    total_completed_transplants: int
    total_potential_matches_awaiting_review: int
    total_approved_matches: int
    total_pending_medical_evaluations: int
    tests_summary: Dict[str, int]  # passed, failed, pending, inconclusive
    priority_summary: Dict[str, int]  # high, medium, low, unclassified
    total_notifications_awaiting: int

class OrganInventoryDemandItem(BaseModel):
    organ_type: str
    display_name: str
    available_inventory: int
    open_requests: int
    potentially_compatible_candidates: int
    allocations_in_progress: int
    completed_transplants: int
    pending_evaluations: int
    last_updated: datetime

class QuantumPerformanceCardsOut(BaseModel):
    is_benchmarked: bool
    status_label: str  # "Benchmarked" or "Not yet benchmarked"
    benchmark_instances: int
    classical_solver_runtime_ms: Optional[float] = None
    quantum_solver_runtime_ms: Optional[float] = None
    objective_score: Optional[float] = None
    feasibility_rate: Optional[float] = None
    valid_allocations_found: Optional[int] = None
    measured_speedup_ratio: Optional[float] = None
    hardware_or_simulator: str
    benchmark_date: Optional[datetime] = None

class DashboardAnalyticsOut(BaseModel):
    summary: SummaryCardsOut
    organ_demand_table: List[OrganInventoryDemandItem]
    quantum_metrics: QuantumPerformanceCardsOut
