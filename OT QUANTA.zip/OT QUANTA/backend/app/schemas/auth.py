import uuid
from datetime import datetime
from typing import Optional, List, Any
from pydantic import BaseModel, EmailStr, Field, ConfigDict
from app.models.enums import UserRole

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: uuid.UUID
    email: str
    role: str
    full_name: str
    hospital_id: Optional[uuid.UUID] = None

class TokenData(BaseModel):
    user_id: Optional[str] = None
    role: Optional[str] = None

class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, description="Password must be at least 8 characters")
    full_name: str = Field(min_length=2)
    role: UserRole = Field(default=UserRole.PATIENT)
    hospital_id: Optional[uuid.UUID] = None
    phone_number: Optional[str] = None
    terms_accepted: bool = Field(default=True)

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class OAuthLoginRequest(BaseModel):
    provider: str = Field(description="google or facebook")
    token: str = Field(description="Id token or access code from provider")
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None

class PasswordResetRequest(BaseModel):
    email: EmailStr

class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str = Field(min_length=8)

class UserProfileOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    full_name: str
    phone_number: Optional[str] = None
    address: Optional[str] = None
    emergency_contact: Optional[str] = None
    avatar_url: Optional[str] = None
    preferences: dict = {}

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    email: EmailStr
    role: str
    is_active: bool
    is_verified: bool
    hospital_id: Optional[uuid.UUID] = None
    hospital_name: Optional[str] = None
    profile: Optional[UserProfileOut] = None
    created_at: datetime
