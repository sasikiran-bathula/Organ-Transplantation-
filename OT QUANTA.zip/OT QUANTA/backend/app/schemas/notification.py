import uuid
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel

class NotificationOut(BaseModel):
    id: uuid.UUID
    recipient_user_id: uuid.UUID
    event_type: str
    title: str
    message: str
    related_record_id: Optional[uuid.UUID] = None
    related_record_type: Optional[str] = None
    is_read: bool
    read_at: Optional[datetime] = None
    delivery_status: str
    created_at: datetime

    class Config:
        from_attributes = True

class NotificationCountOut(BaseModel):
    unread_count: int

class NotificationPreferenceUpdate(BaseModel):
    email_alerts: bool = True
    push_alerts: bool = True
    critical_alerts_only: bool = False
