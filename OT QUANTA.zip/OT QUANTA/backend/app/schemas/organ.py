import uuid
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field
from app.models.enums import OrganType, UrgencyLevel, OrganInventoryStatus, OrganRequestStatus

class OrganCatalogOut(BaseModel):
    id: uuid.UUID
    organ_type: str
    display_name: str
    max_ischemia_hours: float
    requires_hla_match: bool
    requires_size_match: bool
    description: Optional[str] = None

    class Config:
        from_attributes = True

class OrganInventoryCreate(BaseModel):
    organ_catalog_id: uuid.UUID
    donor_id: uuid.UUID
    hospital_id: uuid.UUID
    procurement_timestamp: Optional[datetime] = None
    preservation_method: str = "Static Cold Storage"
    cold_ischemia_start: Optional[datetime] = None
    storage_location: Optional[str] = None
    notes: Optional[str] = None

class OrganInventoryUpdate(BaseModel):
    status: Optional[OrganInventoryStatus] = None
    preservation_method: Optional[str] = None
    storage_location: Optional[str] = None
    notes: Optional[str] = None

class OrganInventoryOut(BaseModel):
    id: uuid.UUID
    organ_catalog_id: uuid.UUID
    organ_type: Optional[str] = None
    donor_id: uuid.UUID
    donor_code: Optional[str] = None
    donor_blood_group: Optional[str] = None
    hospital_id: uuid.UUID
    hospital_name: Optional[str] = None
    procurement_timestamp: datetime
    preservation_method: str
    cold_ischemia_start: datetime
    ischemia_elapsed_hours: Optional[float] = None
    max_ischemia_hours: Optional[float] = None
    status: str
    storage_location: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

class OrganRequestCreate(BaseModel):
    patient_id: uuid.UUID
    hospital_id: uuid.UUID
    required_organ: OrganType
    urgency_level: UrgencyLevel = UrgencyLevel.MEDIUM
    living_or_deceased_preference: str = "EITHER"
    clinical_summary: Optional[str] = None

class OrganRequestUpdate(BaseModel):
    urgency_level: Optional[UrgencyLevel] = None
    status: Optional[OrganRequestStatus] = None
    living_or_deceased_preference: Optional[str] = None
    clinical_summary: Optional[str] = None

class OrganRequestOut(BaseModel):
    id: uuid.UUID
    request_code: str
    patient_id: uuid.UUID
    patient_code: Optional[str] = None
    patient_name: Optional[str] = None
    hospital_id: uuid.UUID
    hospital_name: Optional[str] = None
    required_organ: str
    urgency_level: str
    blood_group: Optional[str] = None
    status: str
    living_or_deceased_preference: str
    clinical_summary: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class WaitingListEntryOut(BaseModel):
    id: uuid.UUID
    patient_id: uuid.UUID
    patient_code: Optional[str] = None
    patient_name: Optional[str] = None
    organ_type: str
    registration_date: datetime
    urgency_category: str
    calculated_priority: float
    status: str
    updated_at: datetime

    class Config:
        from_attributes = True
