import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from app.models.enums import OrganType, CrossmatchResult, ApprovalStatus

class CrossmatchAssessmentRequest(BaseModel):
    patient_id: uuid.UUID
    donor_id: uuid.UUID
    organ_type: OrganType

class MatchReviewAction(BaseModel):
    decision: ApprovalStatus  # APPROVED or REJECTED
    review_notes: str = Field(min_length=5, description="Clinician clinical reasoning and justification")

class CrossmatchReportOut(BaseModel):
    id: uuid.UUID
    assessment_code: str
    patient_id: uuid.UUID
    patient_code: Optional[str] = None
    patient_name: Optional[str] = None
    patient_blood_group: Optional[str] = None
    donor_id: uuid.UUID
    donor_code: Optional[str] = None
    donor_name: Optional[str] = None
    donor_blood_group: Optional[str] = None
    organ_type: str
    
    blood_group_compatible: bool
    hla_compatibility_score: Optional[float] = None
    crossmatch_result: str
    tests_completed: List[str]
    tests_pending: List[str]
    clinical_warnings: List[str]
    evidence_references: List[str]
    explanation: Optional[str] = None
    
    reviewer_id: Optional[uuid.UUID] = None
    reviewer_name: Optional[str] = None
    review_status: str
    review_notes: Optional[str] = None
    reviewed_at: Optional[datetime] = None
    algorithm_version: str
    created_at: datetime

    class Config:
        from_attributes = True

class CandidatePairOut(BaseModel):
    id: uuid.UUID
    patient_id: uuid.UUID
    patient_code: Optional[str] = None
    patient_name: Optional[str] = None
    donor_id: uuid.UUID
    donor_code: Optional[str] = None
    organ_type: str
    eligibility_satisfied: bool
    exclusion_reasons: List[str]
    priority_score: float
    rank: Optional[int] = None
    created_at: datetime

    class Config:
        from_attributes = True

class AllocationRunRequest(BaseModel):
    organ_inventory_id: Optional[uuid.UUID] = None
    algorithm: str = "CLASSICAL_MILP"  # CLASSICAL_MILP or QUANTUM_QAOA

class AllocationRunOut(BaseModel):
    id: uuid.UUID
    run_code: str
    algorithm_used: str
    objective_score: Optional[float] = None
    candidates_evaluated: int
    allocations_found: int
    feasibility_rate: float
    runtime_ms: float
    status: str
    created_at: datetime

    class Config:
        from_attributes = True

class TransplantRecordCreate(BaseModel):
    patient_id: uuid.UUID
    donor_id: uuid.UUID
    organ_inventory_id: uuid.UUID
    hospital_id: uuid.UUID
    primary_surgeon: str
    transplant_date: Optional[datetime] = None
    outcome_status: str = "SUCCESSFUL"
    cold_ischemia_actual_hours: float
    postoperative_notes: Optional[str] = None

class TransplantRecordOut(BaseModel):
    id: uuid.UUID
    patient_id: uuid.UUID
    patient_name: Optional[str] = None
    donor_id: uuid.UUID
    donor_name: Optional[str] = None
    organ_type: Optional[str] = None
    hospital_name: Optional[str] = None
    primary_surgeon: str
    transplant_date: datetime
    outcome_status: str
    cold_ischemia_actual_hours: float
    postoperative_notes: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True
