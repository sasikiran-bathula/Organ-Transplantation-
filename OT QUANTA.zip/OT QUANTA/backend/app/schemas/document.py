import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

class GeminiMedicalExtraction(BaseModel):
    document_title: str
    patient_or_donor_identifier: Optional[str] = None
    blood_group_detected: Optional[str] = None
    rh_factor_detected: Optional[str] = None
    hla_loci_detected: Dict[str, List[str]] = Field(default_factory=dict)
    crossmatch_indications: Optional[str] = None
    infectious_disease_findings: Dict[str, str] = Field(default_factory=dict)
    organ_suitability_notes: Optional[str] = None
    contraindications_identified: List[str] = Field(default_factory=list)
    missing_critical_tests: List[str] = Field(default_factory=list)
    confidence_score: float = Field(ge=0.0, le=1.0)
    source_references: List[str] = Field(default_factory=list, description="Citations to page or section")
    uncertainty_warnings: List[str] = Field(default_factory=list)

class DocumentOut(BaseModel):
    id: uuid.UUID
    record_type: str
    record_id: uuid.UUID
    file_name: str
    file_size_bytes: int
    mime_type: str
    classification: str
    processing_status: str
    extracted_data: Optional[Dict[str, Any]] = None
    human_verified_by: Optional[uuid.UUID] = None
    human_verified_at: Optional[datetime] = None
    verification_notes: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

class DocumentExtractionVerify(BaseModel):
    verified_data: Dict[str, Any]
    verification_notes: str = Field(min_length=3)
    apply_to_record: bool = Field(default=False, description="Whether to update clinical record with verified fields")

class ConsentRecordCreate(BaseModel):
    record_type: str  # PATIENT_RECEIPT, LIVING_DONATION, DECEASED_AUTHORIZATION
    subject_id: uuid.UUID
    legal_document_type: str
    authorized_by_name: str
    relationship_to_subject: str = "SELF"
    witness_name: Optional[str] = None
    signature_digest: str = Field(description="Digital signature hash or biometric token")

class ConsentRecordOut(BaseModel):
    id: uuid.UUID
    record_type: str
    subject_id: uuid.UUID
    legal_document_type: str
    authorized_by_name: str
    relationship_to_subject: str
    is_revoked: bool
    signature_digest: str
    witness_name: Optional[str] = None
    consent_timestamp: datetime
    created_at: datetime

    class Config:
        from_attributes = True
