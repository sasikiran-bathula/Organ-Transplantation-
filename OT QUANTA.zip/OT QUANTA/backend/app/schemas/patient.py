import uuid
from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, Field
from app.models.enums import BloodGroup, OrganType, UrgencyLevel

class PatientCreate(BaseModel):
    full_name: str = Field(min_length=2)
    date_of_birth: date
    gender: str
    blood_group: BloodGroup
    rh_factor: str = "POSITIVE"
    primary_contact: Optional[str] = None
    emergency_contact: Optional[str] = None
    address: Optional[str] = None
    hospital_id: uuid.UUID
    
    # Clinical
    required_organ: OrganType
    clinical_indication: Optional[str] = None
    medical_history: Optional[str] = None
    current_medications: Optional[str] = None
    allergies: Optional[str] = None
    
    urgency_category: UrgencyLevel = UrgencyLevel.MEDIUM
    meld_score: Optional[float] = None
    epts_score: Optional[float] = None
    las_score: Optional[float] = None
    consent_status: str = "OBTAINED"

class PatientUpdate(BaseModel):
    full_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    gender: Optional[str] = None
    blood_group: Optional[BloodGroup] = None
    rh_factor: Optional[str] = None
    primary_contact: Optional[str] = None
    emergency_contact: Optional[str] = None
    address: Optional[str] = None
    hospital_id: Optional[uuid.UUID] = None
    required_organ: Optional[OrganType] = None
    clinical_indication: Optional[str] = None
    medical_history: Optional[str] = None
    current_medications: Optional[str] = None
    allergies: Optional[str] = None
    urgency_category: Optional[UrgencyLevel] = None
    meld_score: Optional[float] = None
    epts_score: Optional[float] = None
    las_score: Optional[float] = None
    evaluation_status: Optional[str] = None
    waiting_list_status: Optional[str] = None
    consent_status: Optional[str] = None
    assigned_coordinator_id: Optional[uuid.UUID] = None

class PatientOut(BaseModel):
    id: uuid.UUID
    patient_code: str
    user_id: Optional[uuid.UUID] = None
    hospital_id: uuid.UUID
    hospital_name: Optional[str] = None
    full_name: str
    date_of_birth: date
    gender: str
    blood_group: str
    rh_factor: str
    primary_contact: Optional[str] = None
    emergency_contact: Optional[str] = None
    address: Optional[str] = None
    required_organ: str
    clinical_indication: Optional[str] = None
    medical_history: Optional[str] = None
    current_medications: Optional[str] = None
    allergies: Optional[str] = None
    urgency_category: str
    meld_score: Optional[float] = None
    epts_score: Optional[float] = None
    las_score: Optional[float] = None
    evaluation_status: str
    waiting_list_status: str
    consent_status: str
    assigned_coordinator_id: Optional[uuid.UUID] = None
    coordinator_name: Optional[str] = None
    is_archived: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class PatientListResponse(BaseModel):
    items: List[PatientOut]
    total: int
    page: int
    size: int
    pages: int
