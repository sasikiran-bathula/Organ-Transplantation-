import uuid
from datetime import date, datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from app.models.enums import BloodGroup, OrganType, DonorPathway, DonorEligibilityStatus

class DonorCreate(BaseModel):
    full_name: str = Field(min_length=2)
    date_of_birth: date
    gender: str
    blood_group: BloodGroup
    rh_factor: str = "POSITIVE"
    contact_details: Optional[str] = None
    address: Optional[str] = None
    hospital_id: uuid.UUID
    
    donor_pathway: DonorPathway = DonorPathway.LIVING
    organs_offered: List[OrganType] = Field(default_factory=list)
    hla_typing: Dict[str, Any] = Field(default_factory=dict)
    infection_screening: Dict[str, Any] = Field(default_factory=dict)
    health_assessment_summary: Optional[str] = None
    legal_authorization_status: str = "PENDING"
    eligibility_status: DonorEligibilityStatus = DonorEligibilityStatus.PENDING

class DonorUpdate(BaseModel):
    full_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    gender: Optional[str] = None
    blood_group: Optional[BloodGroup] = None
    rh_factor: Optional[str] = None
    contact_details: Optional[str] = None
    address: Optional[str] = None
    hospital_id: Optional[uuid.UUID] = None
    donor_pathway: Optional[DonorPathway] = None
    organs_offered: Optional[List[OrganType]] = None
    hla_typing: Optional[Dict[str, Any]] = None
    infection_screening: Optional[Dict[str, Any]] = None
    health_assessment_summary: Optional[str] = None
    eligibility_status: Optional[DonorEligibilityStatus] = None
    legal_authorization_status: Optional[str] = None
    assigned_reviewer_id: Optional[uuid.UUID] = None

class DonorOut(BaseModel):
    id: uuid.UUID
    donor_code: str
    user_id: Optional[uuid.UUID] = None
    hospital_id: uuid.UUID
    hospital_name: Optional[str] = None
    full_name: str
    date_of_birth: date
    gender: str
    blood_group: str
    rh_factor: str
    contact_details: Optional[str] = None
    address: Optional[str] = None
    donor_pathway: str
    organs_offered: List[str]
    hla_typing: Dict[str, Any]
    infection_screening: Dict[str, Any]
    health_assessment_summary: Optional[str] = None
    eligibility_status: str
    legal_authorization_status: str
    assigned_reviewer_id: Optional[uuid.UUID] = None
    reviewer_name: Optional[str] = None
    is_archived: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class DonorListResponse(BaseModel):
    items: List[DonorOut]
    total: int
    page: int
    size: int
    pages: int
