from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
import uuid
from sqlalchemy.orm import Session
from app.models.clinical import PatientRecord, DonorRecord
from app.models.organ import OrganInventory, OrganRequest, WaitingListEntry
from app.models.crossmatch import CandidatePair, AllocationRun, AllocationDecision
from app.models.enums import UrgencyLevel, OrganInventoryStatus

def calculate_candidate_priority(patient: PatientRecord) -> float:
    """Calculate clinical priority score based on approved urgency criteria."""
    base_score = 10.0
    if patient.urgency_category == UrgencyLevel.HIGH.value:
        base_score += 50.0
    elif patient.urgency_category == UrgencyLevel.MEDIUM.value:
        base_score += 25.0
    
    # Specific clinical indexes if present
    if patient.meld_score:  # Model for End-Stage Liver Disease (6 to 40)
        base_score += float(patient.meld_score) * 1.5
    if patient.las_score:   # Lung Allocation Score (0 to 100)
        base_score += float(patient.las_score) * 0.8
    if patient.epts_score:  # Estimated Post-Transplant Survival (0 to 100%)
        # Lower EPTS indicates longer expected survival benefit
        base_score += (100.0 - float(patient.epts_score)) * 0.3
        
    return round(base_score, 2)

def rank_candidates_for_organ(
    db: Session,
    organ_inventory: OrganInventory
) -> List[Dict[str, Any]]:
    """Retrieve and rank medically eligible candidates for a procured organ."""
    organ_catalog = organ_inventory.catalog_item
    organ_type = organ_catalog.organ_type if organ_catalog else "KIDNEY"

    # Find active patients waiting for this organ type
    candidates = db.query(PatientRecord).filter(
        PatientRecord.required_organ == organ_type,
        PatientRecord.is_archived == False,
        PatientRecord.waiting_list_status.in_(["ACTIVE", "PENDING"])
    ).all()

    ranked_results = []
    for patient in candidates:
        priority = calculate_candidate_priority(patient)
        ranked_results.append({
            "patient": patient,
            "priority_score": priority,
            "organ_type": organ_type
        })

    # Sort candidates by descending priority score
    ranked_results.sort(key=lambda x: x["priority_score"], reverse=True)
    return ranked_results
