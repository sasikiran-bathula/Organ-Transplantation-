from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from app.models.notification_audit import AuditEvent
from app.models.user import User

def record_audit_event(
    db: Session,
    action: str,
    resource_type: str,
    resource_id: Optional[str] = None,
    user: Optional[User] = None,
    changes: Optional[Dict[str, Any]] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None
) -> AuditEvent:
    """Log an immutable clinical audit trail event."""
    event = AuditEvent(
        user_id=user.id if user else None,
        user_email=user.email if user else None,
        action=action,
        resource_type=resource_type,
        resource_id=str(resource_id) if resource_id else None,
        changes=changes or {},
        ip_address=ip_address,
        user_agent=user_agent
    )
    db.add(event)
    db.commit()
    return event
