import os
import hashlib
from datetime import datetime, timezone
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from app.core.config import settings

def generate_crossmatch_pdf(
    assessment_id: str,
    assessment_code: str,
    patient_name: str,
    patient_code: str,
    patient_bg: str,
    donor_name: str,
    donor_code: str,
    donor_bg: str,
    organ_type: str,
    compatibility_result: str,
    algorithm_version: str,
    tests_completed: list,
    tests_pending: list,
    clinical_warnings: list,
    reviewer_name: str,
    review_status: str,
    output_filename: str
) -> tuple[str, int, str]:
    """Generate professional medical PDF report for clinical crossmatch."""
    reports_dir = os.path.join(settings.STORAGE_DIR, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    full_path = os.path.join(reports_dir, output_filename)

    doc = SimpleDocTemplate(
        full_path,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )
    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#0F172A'),
        spaceAfter=6
    )
    subtitle_style = ParagraphStyle(
        'DocSub',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#0D9488'),
        spaceAfter=15
    )
    disclaimer_style = ParagraphStyle(
        'DocDisc',
        parent=styles['Italic'],
        fontSize=8,
        leading=11,
        textColor=colors.HexColor('#DC2626'),
        spaceBefore=15
    )
    body_style = styles['Normal']

    story = []

    # Header
    story.append(Paragraph("QUANTAORGAN — CLINICAL CROSSMATCH REPORT", title_style))
    story.append(Paragraph(f"Official Crossmatch Compatibility Assessment • Protocol Version: {algorithm_version}", subtitle_style))
    story.append(Spacer(1, 10))

    # Assessment Meta Table
    meta_data = [
        ["Assessment ID", str(assessment_id), "Assessment Code", str(assessment_code)],
        ["Date Generated", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), "Review Status", str(review_status)],
        ["Requested Organ", str(organ_type), "Clinician Reviewer", str(reviewer_name or "Pending Review")]
    ]
    t_meta = Table(meta_data, colWidths=[110, 150, 110, 150])
    t_meta.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F8FAFC')),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1E293B')),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_meta)
    story.append(Spacer(1, 15))

    # Patient & Donor Details Table
    party_data = [
        ["Clinical Subject", "Recipient (Patient)", "Donor Candidate"],
        ["Full Name", patient_name, donor_name],
        ["Identification Code", patient_code, donor_code],
        ["Blood Group & Rh", patient_bg, donor_bg]
    ]
    t_party = Table(party_data, colWidths=[120, 200, 200])
    t_party.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0F172A')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_party)
    story.append(Spacer(1, 15))

    # Compatibility Decision Card
    result_color = colors.HexColor('#16A34A') if compatibility_result == "COMPATIBLE" else (
        colors.HexColor('#DC2626') if compatibility_result == "INCOMPATIBLE" else colors.HexColor('#D97706')
    )
    result_data = [
        ["DETERMINISTIC COMPATIBILITY FINDING", str(compatibility_result)],
        ["Verified Laboratory Tests", ", ".join(tests_completed) if tests_completed else "None"],
        ["Pending Critical Tests", ", ".join(tests_pending) if tests_pending else "None"],
        ["Clinical Warnings / Contraindications", "; ".join(clinical_warnings) if clinical_warnings else "None"]
    ]
    t_result = Table(result_data, colWidths=[160, 360])
    t_result.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#F1F5F9')),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('TEXTCOLOR', (1, 0), (1, 0), result_color),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_result)
    story.append(Spacer(1, 20))

    # Regulatory Disclaimer
    story.append(Paragraph(
        "MANDATORY CLINICAL & REGULATORY NOTICE: This report is generated by TransplantCare Quantum for clinical decision support. "
        "It does NOT replace an independent, signed medical consultation or statutory institutional review board authorization. "
        "Transplantation must proceed solely under authorized physician orders in accordance with UNOS/OPTN or regional health authority regulations.",
        disclaimer_style
    ))

    doc.build(story)

    # Compute checksum and file size
    file_size = os.path.getsize(full_path)
    with open(full_path, "rb") as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()

    return full_path, file_size, file_hash
