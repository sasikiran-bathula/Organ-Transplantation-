from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime, timezone
import uuid
from app.models.clinical import PatientRecord, DonorRecord
from app.models.enums import CrossmatchResult, OrganType, BloodGroup

ABO_COMPATIBILITY_MATRIX = {
    # Donor Blood Group: [Compatible Recipient Groups]
    "O+": ["O+", "A+", "B+", "AB+"],
    "O-": ["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"],
    "A+": ["A+", "AB+"],
    "A-": ["A+", "A-", "AB+", "AB-"],
    "B+": ["B+", "AB+"],
    "B-": ["B+", "B-", "AB+", "AB-"],
    "AB+": ["AB+"],
    "AB-": ["AB+", "AB-"],
    "UNKNOWN": []
}

def check_abo_compatibility(donor_bg: str, patient_bg: str) -> Tuple[bool, Optional[str]]:
    """Determine ABO compatibility based on standard hemagglutination rules."""
    donor_norm = donor_bg.strip().upper()
    patient_norm = patient_bg.strip().upper()
    
    if donor_norm == "UNKNOWN" or patient_norm == "UNKNOWN":
        return False, "Blood group data missing for donor or recipient."
        
    compatible_recipients = ABO_COMPATIBILITY_MATRIX.get(donor_norm, [])
    if patient_norm in compatible_recipients:
        return True, f"Donor {donor_norm} is ABO-compatible with recipient {patient_norm}."
    else:
        return False, f"ABO Incompatible: Donor {donor_norm} cannot donate to recipient {patient_norm}."

def calculate_hla_mismatches(donor_hla: Dict[str, Any], patient_hla: Dict[str, Any]) -> Tuple[int, int, List[str]]:
    """Calculate HLA locus matches and identify missing antigens.
    Checks HLA-A, HLA-B, HLA-DR loci (up to 6 total antigens).
    """
    loci = ["A", "B", "DR"]
    matches = 0
    total_evaluated = 0
    missing = []
    
    for locus in loci:
        d_alleles = donor_hla.get(locus, [])
        p_alleles = patient_hla.get(locus, [])
        
        if not d_alleles or not p_alleles:
            missing.append(f"HLA-{locus} typing incomplete")
            continue
            
        for d in d_alleles:
            total_evaluated += 1
            if d in p_alleles:
                matches += 1
                
    return matches, total_evaluated, missing

def evaluate_crossmatch(
    patient: PatientRecord,
    donor: DonorRecord,
    organ_type: str
) -> Dict[str, Any]:
    """Execute deterministic clinical crossmatch pipeline."""
    tests_completed = []
    tests_pending = []
    clinical_warnings = []
    evidence = []
    
    # 1. ABO Compatibility
    is_abo_compat, abo_msg = check_abo_compatibility(donor.blood_group, patient.blood_group)
    evidence.append(abo_msg)
    if not is_abo_compat:
        clinical_warnings.append(f"Major Contraindication: {abo_msg}")
    tests_completed.append("ABO_RH_TYPING")
    
    # Organ Specific Rules
    organ_norm = organ_type.upper()
    hla_score = None
    
    if organ_norm in [OrganType.KIDNEY.value, OrganType.BONE_MARROW.value]:
        d_hla = donor.hla_typing or {}
        p_hla = {}  # In a clinical scenario, from patient labs
        # Check if HLA information is present
        if not d_hla:
            tests_pending.append("DONOR_HLA_TYPING")
        else:
            tests_completed.append("DONOR_HLA_TYPING")
            
        # Example: check HLA match if available
        if d_hla and p_hla:
            matches, total, missing_loci = calculate_hla_mismatches(d_hla, p_hla)
            hla_score = float(matches)
            evidence.append(f"HLA Mismatch Analysis: {matches}/{total} evaluated loci matched.")
            if missing_loci:
                for ml in missing_loci:
                    tests_pending.append(ml)
        else:
            tests_pending.append("RECIPIENT_HLA_CROSSMATCH")
            
    # 2. Infection Screening
    donor_infections = donor.infection_screening or {}
    if not donor_infections:
        tests_pending.append("DONOR_INFECTIOUS_DISEASE_PANEL")
        clinical_warnings.append("Caution: Complete infectious disease panel not recorded.")
    else:
        tests_completed.append("DONOR_INFECTIOUS_DISEASE_PANEL")
        for pathogen, status in donor_infections.items():
            if str(status).lower() in ["positive", "reactive", "detected"]:
                clinical_warnings.append(f"Infectious Risk Alert: Donor positive for {pathogen}.")
                evidence.append(f"Donor {pathogen} status: {status}.")

    # 3. Categorical Assessment Decision
    # Immune-privileged organs (e.g., corneas) do not require strict ABO compatibility
    if organ_norm == OrganType.CORNEAS.value:
        if tests_pending:
            result = CrossmatchResult.INSUFFICIENT_DATA
            explanation = "Corneal tissue assessment awaiting required infectious disease verification."
        else:
            result = CrossmatchResult.COMPATIBLE
            explanation = "Immune-privileged corneal graft compatible under standard tissue banking protocol."
    elif not is_abo_compat:
        result = CrossmatchResult.INCOMPATIBLE
        explanation = f"Transplant contraindicated due to ABO incompatibility ({donor.blood_group} -> {patient.blood_group})."
    elif len(tests_pending) > 0:
        result = CrossmatchResult.INSUFFICIENT_DATA
        explanation = f"Assessment cannot be finalized: {len(tests_pending)} critical laboratory tests pending."
    elif len(clinical_warnings) > 0:
        result = CrossmatchResult.CONDITIONALLY_ACCEPTABLE
        explanation = "Conditionally acceptable pending desensitization or clinical risk protocol authorization."
    else:
        result = CrossmatchResult.COMPATIBLE
        explanation = "Full clinical crossmatch criteria satisfied without contraindications."

    return {
        "blood_group_compatible": is_abo_compat,
        "hla_compatibility_score": hla_score,
        "crossmatch_result": result.value,
        "tests_completed": tests_completed,
        "tests_pending": tests_pending,
        "clinical_warnings": clinical_warnings,
        "evidence_references": evidence,
        "explanation": explanation
    }
