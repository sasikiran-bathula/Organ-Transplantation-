import uuid
from typing import Optional, List
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models.notification_audit import Notification, NotificationDelivery
from app.models.user import User
from app.models.enums import NotificationEventType, UserRole

def create_notification(
    db: Session,
    recipient_user_id: uuid.UUID,
    event_type: NotificationEventType,
    title: str,
    message: str,
    related_record_id: Optional[uuid.UUID] = None,
    related_record_type: Optional[str] = None
) -> Notification:
    notification = Notification(
        recipient_user_id=recipient_user_id,
        event_type=event_type.value if hasattr(event_type, "value") else str(event_type),
        title=title,
        message=message,
        related_record_id=related_record_id,
        related_record_type=related_record_type,
        is_read=False,
        delivery_status="DELIVERED"
    )
    db.add(notification)
    db.flush()

    # In-app delivery record
    delivery = NotificationDelivery(
        notification_id=notification.id,
        channel="IN_APP",
        delivery_attempt=1,
        status="SUCCESS",
        attempted_at=datetime.now(timezone.utc)
    )
    db.add(delivery)
    db.commit()
    db.refresh(notification)
    return notification

def notify_hospital_coordinators(
    db: Session,
    hospital_id: uuid.UUID,
    event_type: NotificationEventType,
    title: str,
    message: str,
    related_record_id: Optional[uuid.UUID] = None,
    related_record_type: Optional[str] = None
) -> List[Notification]:
    """Broadcast notification to all coordinators and clinicians assigned to a hospital."""
    staff = db.query(User).filter(
        User.hospital_id == hospital_id,
        User.role.in_([
            UserRole.TRANSPLANT_COORDINATOR.value,
            UserRole.CLINICIAN.value,
            UserRole.HOSPITAL_ADMIN.value
        ]),
        User.is_active == True
    ).all()

    notifications = []
    for member in staff:
        n = create_notification(
            db=db,
            recipient_user_id=member.id,
            event_type=event_type,
            title=title,
            message=message,
            related_record_id=related_record_id,
            related_record_type=related_record_type
        )
        notifications.append(n)
    return notifications
