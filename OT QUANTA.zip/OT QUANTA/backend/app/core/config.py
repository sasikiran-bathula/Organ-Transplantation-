import os
from typing import List, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    PROJECT_NAME: str = "QuantaOrgan"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: str = Field(default="development", description="development, demo, or production")
    
    SECRET_KEY: str = Field(default="transplantcare-quantum-production-super-secret-key-2026", description="JWT secret key")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 12  # 12 hours
    
    # Database
    DATABASE_URL: str = Field(
        default="sqlite:///./transplantcare.db",
        description="Database connection URL (PostgreSQL for prod, SQLite for dev/test)"
    )
    
    # Private Storage
    STORAGE_DIR: str = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage")
    
    # External APIs
    GEMINI_API_KEY: Optional[str] = Field(default=None, description="Google Gemini API Key for clinical doc extraction")
    GOOGLE_CLIENT_ID: Optional[str] = None
    GOOGLE_CLIENT_SECRET: Optional[str] = None
    FACEBOOK_CLIENT_ID: Optional[str] = None
    FACEBOOK_CLIENT_SECRET: Optional[str] = None
    
    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:8000"]
    
    # Quantum Simulator
    DEFAULT_QUANTUM_BACKEND: str = "aer_simulator_statevector"

settings = Settings()
