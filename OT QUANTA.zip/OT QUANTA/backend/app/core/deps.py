import uuid
from typing import Generator, List, Optional
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.security import decode_access_token
from app.models.user import User
from app.models.enums import UserRole

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/token")

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception
    user_id_str: str = payload.get("sub")
    if user_id_str is None:
        raise credentials_exception
    try:
        user_uuid = uuid.UUID(user_id_str)
    except ValueError:
        raise credentials_exception
        
    user = db.query(User).filter(User.id == user_uuid).first()
    if user is None:
        raise credentials_exception
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Inactive user account")
    return user

def require_roles(*allowed_roles: UserRole):
    def role_checker(current_user: User = Depends(get_current_user)) -> User:
        allowed_values = [r.value if hasattr(r, 'value') else r for r in allowed_roles]
        if current_user.role not in allowed_values and current_user.role != UserRole.SYSTEM_ADMIN.value:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access forbidden: requires one of [{', '.join(allowed_values)}]"
            )
        return current_user
    return role_checker

def verify_record_access(current_user: User, record_user_id: Optional[uuid.UUID] = None, record_hospital_id: Optional[uuid.UUID] = None):
    """Enforces patient/donor privacy isolation and hospital boundaries."""
    # System Admin and Read-Only Auditor can view
    if current_user.role in [UserRole.SYSTEM_ADMIN.value, UserRole.AUDITOR.value]:
        return True
    
    # If user is a Patient or Donor, they can strictly view ONLY their own linked record
    if current_user.role in [UserRole.PATIENT.value, UserRole.DONOR.value]:
        if record_user_id != current_user.id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden: You can only access your own clinical records.")
        return True

    # If clinician/coordinator/hospital admin, verify same hospital or explicit authorization
    if record_hospital_id and current_user.hospital_id:
        if record_hospital_id != current_user.hospital_id and current_user.role != UserRole.SYSTEM_ADMIN.value:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden: Cross-hospital access is restricted.")
            
    return True
