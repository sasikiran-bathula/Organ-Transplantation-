"""DEVELOPMENT & DEMO SEEDER ONLY
Clearly labeled synthetic clinical data for QuantaOrgan.
Never run this seeder in a certified production clinical environment.
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import uuid
from datetime import datetime, timezone, date, timedelta
from app.core.database import SessionLocal, Base, engine
from app.core.security import hash_password
from app.models.user import Hospital, User, UserProfile
from app.models.clinical import PatientRecord, DonorRecord, LaboratoryTest, LaboratoryResult
from app.models.organ import OrganCatalog, OrganInventory, OrganRequest, WaitingListEntry
from app.models.crossmatch import MatchAssessment, CandidatePair, TransplantRecord
from app.models.notification_audit import Notification, AuditEvent
from app.models.quantum import QuantumExperiment, QuantumBenchmarkResult
from app.models.enums import (
    UserRole, BloodGroup, OrganType, UrgencyLevel, DonorPathway,
    DonorEligibilityStatus, OrganInventoryStatus, OrganRequestStatus,
    CrossmatchResult, ApprovalStatus, NotificationEventType
)
from quantum_optimizer.benchmark import run_allocation_benchmark

def seed_demo_data():
    db = SessionLocal()
    try:
        print("[DEMO SEEDER] Initializing schema...")
        Base.metadata.create_all(bind=engine)

        if db.query(Hospital).first():
            print("[DEMO SEEDER] Database already contains records. Skipping seeder.")
            return

        print("[DEMO SEEDER] Seeding synthetic demonstration hospital...")
        hosp = Hospital(
            name="Metropolitan Transplant Institute (Synthetic Demo Center)",
            code="MTI",
            city="New York",
            state="NY",
            country="United States",
            contact_email="coordinator@mti-demo.health",
            contact_phone="+1-212-555-0199",
            is_active=True
        )
        db.add(hosp)
        db.flush()

        print("[DEMO SEEDER] Seeding demo users with distinct roles...")
        users_meta = [
            ("admin@quantaorgan.demo", "AdminPass123!", UserRole.SYSTEM_ADMIN.value, "Dr. Arthur Pendelton (System Admin)"),
            ("coordinator@quantaorgan.demo", "CoordPass123!", UserRole.TRANSPLANT_COORDINATOR.value, "Sarah Jenkins, RN (Transplant Coordinator)"),
            ("clinician@quantaorgan.demo", "DoctorPass123!", UserRole.CLINICIAN.value, "Dr. Elena Rostova, MD (Transplant Surgeon)"),
            ("lab@quantaorgan.demo", "LabPass123!", UserRole.LAB_REVIEWER.value, "David Zhang (Immunogenetics Specialist)"),
            ("auditor@quantaorgan.demo", "AuditPass123!", UserRole.AUDITOR.value, "Rachel Vance (Clinical Compliance Auditor)"),
            ("patient@quantaorgan.demo", "PatientPass123!", UserRole.PATIENT.value, "Marcus Vance (Registered Patient)"),
            ("donor@quantaorgan.demo", "DonorPass123!", UserRole.DONOR.value, "Clara Oswald (Registered Donor)"),
        ]

        user_objects = {}
        for email, pwd, role, full_name in users_meta:
            u = User(
                email=email,
                hashed_password=hash_password(pwd),
                role=role,
                is_active=True,
                is_verified=True,
                hospital_id=hosp.id
            )
            db.add(u)
            db.flush()
            prof = UserProfile(
                user_id=u.id,
                full_name=full_name,
                phone_number="+1-555-0144",
                address="100 Medical Center Plaza, New York, NY",
                preferences={"email_alerts": True, "push_alerts": True}
            )
            db.add(prof)
            user_objects[role] = u
        db.flush()

        print("[DEMO SEEDER] Seeding organ catalog...")
        catalog_items = [
            OrganCatalog(organ_type=OrganType.HEART.value, display_name="Heart", max_ischemia_hours=4.0, requires_hla_match=True, requires_size_match=True, description="Cardiac allograft"),
            OrganCatalog(organ_type=OrganType.LUNGS.value, display_name="Lungs", max_ischemia_hours=6.0, requires_hla_match=True, requires_size_match=True, description="Pulmonary bilateral allograft"),
            OrganCatalog(organ_type=OrganType.KIDNEY.value, display_name="Kidney", max_ischemia_hours=24.0, requires_hla_match=True, requires_size_match=False, description="Renal graft with extended preservation window"),
            OrganCatalog(organ_type=OrganType.LIVER.value, display_name="Liver", max_ischemia_hours=12.0, requires_hla_match=False, requires_size_match=True, description="Hepatic orthotopic allograft"),
            OrganCatalog(organ_type=OrganType.PANCREAS.value, display_name="Pancreas", max_ischemia_hours=12.0, requires_hla_match=True, requires_size_match=False, description="Pancreas composite graft"),
            OrganCatalog(organ_type=OrganType.CORNEAS.value, display_name="Corneas / Eyes", max_ischemia_hours=168.0, requires_hla_match=False, requires_size_match=False, description="Immune-privileged corneal disc"),
            OrganCatalog(organ_type=OrganType.BONE_MARROW.value, display_name="Bone Marrow", max_ischemia_hours=48.0, requires_hla_match=True, requires_size_match=False, description="Hematopoietic stem cells"),
            OrganCatalog(organ_type=OrganType.UTERUS.value, display_name="Uterus", max_ischemia_hours=6.0, requires_hla_match=True, requires_size_match=True, description="Uterine vascularized composite allograft"),
            OrganCatalog(organ_type=OrganType.OTHER.value, display_name="Other Tissues", max_ischemia_hours=24.0, requires_hla_match=False, requires_size_match=False, description="Configurable graft"),
        ]
        db.add_all(catalog_items)
        db.flush()

        catalog_map = {c.organ_type: c for c in catalog_items}

        print("[DEMO SEEDER] Seeding synthetic patient records...")
        patients_data = [
            ("PT-MTI-1001", "Marcus Vance", date(1982, 5, 14), "MALE", "O+", "POSITIVE", OrganType.KIDNEY.value, UrgencyLevel.HIGH.value, None, 22.5, None, user_objects[UserRole.PATIENT.value].id),
            ("PT-MTI-1002", "Samantha Hayes", date(1975, 11, 20), "FEMALE", "A+", "POSITIVE", OrganType.HEART.value, UrgencyLevel.HIGH.value, None, None, 78.4, None),
            ("PT-MTI-1003", "Julian Thorne", date(1968, 3, 9), "MALE", "B+", "POSITIVE", OrganType.LIVER.value, UrgencyLevel.HIGH.value, 31.0, None, None, None),
            ("PT-MTI-1004", "Amira Patel", date(1991, 8, 27), "FEMALE", "AB+", "POSITIVE", OrganType.KIDNEY.value, UrgencyLevel.MEDIUM.value, None, 14.0, None, None),
            ("PT-MTI-1005", "Robert Kowalski", date(1962, 1, 15), "MALE", "O-", "NEGATIVE", OrganType.LUNGS.value, UrgencyLevel.MEDIUM.value, None, None, 45.2, None),
            ("PT-MTI-1006", "Chloe Bennett", date(1995, 9, 30), "FEMALE", "A-", "NEGATIVE", OrganType.CORNEAS.value, UrgencyLevel.LOW.value, None, None, None, None),
        ]

        created_patients = []
        for code, name, dob, gender, bg, rh, organ, urg, meld, epts, las, uid in patients_data:
            p = PatientRecord(
                patient_code=code,
                user_id=uid,
                hospital_id=hosp.id,
                full_name=name,
                date_of_birth=dob,
                gender=gender,
                blood_group=bg,
                rh_factor=rh,
                primary_contact="+1-555-0188",
                address="Synthetic Demo Residence, NY",
                required_organ=organ,
                clinical_indication="End-stage organ failure requiring transplantation",
                urgency_category=urg,
                meld_score=meld,
                epts_score=epts,
                las_score=las,
                evaluation_status="APPROVED",
                waiting_list_status="ACTIVE",
                consent_status="OBTAINED",
                assigned_coordinator_id=user_objects[UserRole.TRANSPLANT_COORDINATOR.value].id
            )
            db.add(p)
            db.flush()
            created_patients.append(p)

            # Add to waiting list
            p_score = 50.0 if urg == UrgencyLevel.HIGH.value else 25.0
            wl = WaitingListEntry(
                patient_id=p.id,
                organ_type=organ,
                urgency_category=urg,
                calculated_priority=p_score + (meld or 0) * 1.5 + (las or 0) * 0.8,
                status="ACTIVE"
            )
            db.add(wl)

            # Create organ request
            req = OrganRequest(
                request_code=f"REQ-{hosp.code}-{code[-4:]}",
                patient_id=p.id,
                hospital_id=hosp.id,
                required_organ=organ,
                urgency_level=urg,
                status=OrganRequestStatus.OPEN.value,
                living_or_deceased_preference="EITHER",
                clinical_summary="Standard clinical evaluation completed; crossmatch required."
            )
            db.add(req)

        print("[DEMO SEEDER] Seeding synthetic donor records...")
        donors_data = [
            ("DN-MTI-1001", "Clara Oswald", date(1994, 4, 12), "FEMALE", "O+", "POSITIVE", DonorPathway.LIVING.value, [OrganType.KIDNEY.value], {"A": ["02:01", "24:02"], "B": ["07:02", "44:02"], "DR": ["04:01", "15:01"]}, DonorEligibilityStatus.ELIGIBLE.value, user_objects[UserRole.DONOR.value].id),
            ("DN-MTI-1002", "Jonathan Archer (Deceased)", date(1980, 7, 3), "MALE", "O-", "NEGATIVE", DonorPathway.DECEASED.value, [OrganType.HEART.value, OrganType.LUNGS.value, OrganType.LIVER.value, OrganType.KIDNEY.value], {"A": ["01:01", "03:01"], "B": ["08:01", "35:01"], "DR": ["03:01", "07:01"]}, DonorEligibilityStatus.ELIGIBLE.value, None),
            ("DN-MTI-1003", "Maria Santos", date(1989, 12, 19), "FEMALE", "A+", "POSITIVE", DonorPathway.LIVING.value, [OrganType.KIDNEY.value, OrganType.BONE_MARROW.value], {"A": ["02:01", "11:01"], "B": ["15:01", "40:01"], "DR": ["04:01", "11:01"]}, DonorEligibilityStatus.ELIGIBLE.value, None),
        ]

        created_donors = []
        for code, name, dob, gender, bg, rh, pathway, organs, hla, elig, uid in donors_data:
            d = DonorRecord(
                donor_code=code,
                user_id=uid,
                hospital_id=hosp.id,
                full_name=name,
                date_of_birth=dob,
                gender=gender,
                blood_group=bg,
                rh_factor=rh,
                contact_details="+1-555-0177",
                address="Synthetic Donor Address, NY",
                donor_pathway=pathway,
                organs_offered=organs,
                hla_typing=hla,
                infection_screening={"HIV": "Non-reactive", "HepB": "Non-reactive", "HepC": "Non-reactive", "CMV": "Negative"},
                health_assessment_summary="Approved candidate meeting clinical donor criteria.",
                eligibility_status=elig,
                legal_authorization_status="AUTHORIZED",
                assigned_reviewer_id=user_objects[UserRole.CLINICIAN.value].id
            )
            db.add(d)
            db.flush()
            created_donors.append(d)

        print("[DEMO SEEDER] Seeding synthetic organ inventory...")
        now = datetime.now(timezone.utc)
        # 1 Procured Heart from deceased donor
        inv_heart = OrganInventory(
            organ_catalog_id=catalog_map[OrganType.HEART.value].id,
            donor_id=created_donors[1].id,
            hospital_id=hosp.id,
            procurement_timestamp=now - timedelta(hours=1),
            preservation_method="Static Cold Storage with Custodiol HTK",
            cold_ischemia_start=now - timedelta(hours=1),
            status=OrganInventoryStatus.PROCURED.value,
            storage_location="Operating Suite Perfusion Unit 3",
            notes="Excellent cardiac ejection fraction; ready for immediate recipient allocation."
        )
        db.add(inv_heart)

        # 1 Procured Kidney from living donor
        inv_kidney = OrganInventory(
            organ_catalog_id=catalog_map[OrganType.KIDNEY.value].id,
            donor_id=created_donors[0].id,
            hospital_id=hosp.id,
            procurement_timestamp=now - timedelta(hours=3),
            preservation_method="Pulsatile Hypothermic Machine Perfusion",
            cold_ischemia_start=now - timedelta(hours=3),
            status=OrganInventoryStatus.PRESERVED.value,
            storage_location="Cold Perfusion Lab B",
            notes="Renal resistance index optimal (<0.20 mmHg/ml/min)."
        )
        db.add(inv_kidney)
        db.flush()

        print("[DEMO SEEDER] Seeding synthetic crossmatch assessment & completed transplant...")
        # Crossmatch for Marcus Vance (O+) and Clara Oswald (O+)
        xmatch = MatchAssessment(
            assessment_code="XMATCH-1001",
            patient_id=created_patients[0].id,
            donor_id=created_donors[0].id,
            organ_type=OrganType.KIDNEY.value,
            blood_group_compatible=True,
            hla_compatibility_score=4.0,
            crossmatch_result=CrossmatchResult.COMPATIBLE.value,
            tests_completed=["ABO_RH_TYPING", "DONOR_HLA_TYPING", "CDC_CYTOTOXIC_CROSSMATCH", "FLOW_CYTOMETRY_CROSSMATCH"],
            tests_pending=[],
            clinical_warnings=["Mild CMV mismatch risk (Donor negative / Recipient positive; standard prophylaxis indicated)"],
            evidence_references=["CDC Crossmatch Negative (0% cell death)", "Flow Cytometry Channel Shift < 20 MCS"],
            explanation="Both candidates share identical O+ serology. 4/6 HLA loci compatible. No donor-specific antibodies identified.",
            reviewer_id=user_objects[UserRole.CLINICIAN.value].id,
            review_status=ApprovalStatus.APPROVED.value,
            review_notes="Full clinical authorization granted. Proceed with perioperative schedule.",
            reviewed_at=now - timedelta(days=2),
            algorithm_version="TCQ-RULE-ENGINE-v1.0"
        )
        db.add(xmatch)
        db.flush()

        # Seed completed transplant record
        inv_transplanted = OrganInventory(
            organ_catalog_id=catalog_map[OrganType.KIDNEY.value].id,
            donor_id=created_donors[2].id,
            hospital_id=hosp.id,
            procurement_timestamp=now - timedelta(days=5),
            preservation_method="Static Cold Storage",
            cold_ischemia_start=now - timedelta(days=5),
            status=OrganInventoryStatus.COMPLETED.value,
            notes="Completed procedure."
        )
        db.add(inv_transplanted)
        db.flush()

        transplant = TransplantRecord(
            patient_id=created_patients[3].id,
            donor_id=created_donors[2].id,
            organ_inventory_id=inv_transplanted.id,
            hospital_id=hosp.id,
            primary_surgeon="Dr. Elena Rostova, MD",
            transplant_date=now - timedelta(days=4),
            outcome_status="SUCCESSFUL",
            cold_ischemia_actual_hours=14.2,
            postoperative_notes="Immediate graft function verified. Serum creatinine stabilized to 1.1 mg/dL."
        )
        db.add(transplant)

        print("[DEMO SEEDER] Running initial Quantum vs. Classical benchmark instance...")
        bench_res = run_allocation_benchmark(num_organs=3, num_candidates=6, num_trials=3)
        exp = QuantumExperiment(
            experiment_code="QEXP-DEMO-001",
            title=bench_res["title"],
            problem_size=bench_res["problem_size"],
            num_candidates=bench_res["num_candidates"],
            num_organs=bench_res["num_organs"],
            classical_algorithm=bench_res["classical_algorithm"],
            quantum_algorithm=bench_res["quantum_algorithm"],
            backend_name=bench_res["backend_name"],
            classical_runtime_ms=bench_res["classical_runtime_ms"],
            quantum_runtime_ms=bench_res["quantum_runtime_ms"],
            measured_speedup=bench_res["measured_speedup"],
            objective_score=bench_res["objective_score"],
            feasibility_rate=bench_res["feasibility_rate"],
            constraint_violations=bench_res["constraint_violations"],
            status="COMPLETED",
            limitations_notes=bench_res["limitations_notes"]
        )
        db.add(exp)
        db.flush()

        for tr in bench_res["trials"]:
            db.add(QuantumBenchmarkResult(
                experiment_id=exp.id,
                trial_index=tr["trial_index"],
                classical_time_ms=tr["classical_time_ms"],
                quantum_time_ms=tr["quantum_time_ms"],
                cost_value=tr["cost_value"],
                valid_solution=tr["valid_solution"]
            ))

        print("[DEMO SEEDER] Seeding notifications...")
        for uid in [user_objects[UserRole.SYSTEM_ADMIN.value].id, user_objects[UserRole.TRANSPLANT_COORDINATOR.value].id]:
            db.add(Notification(
                recipient_user_id=uid,
                event_type=NotificationEventType.NEW_POTENTIAL_MATCH.value,
                title="Cardiac Allograft Procurement Notification",
                message="Donor Jonathan Archer (O-) cardiac allograft procured. 2 candidates on waiting list match criteria.",
                related_record_id=inv_heart.id,
                related_record_type="ORGAN_INVENTORY",
                is_read=False,
                delivery_status="DELIVERED"
            ))

        db.commit()
        print("[DEMO SEEDER] Synthetic demonstration data successfully committed to database!")

    except Exception as e:
        db.rollback()
        print(f"[DEMO SEEDER ERROR] Seeding failed: {e}")
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    seed_demo_data()
