import uuid
from datetime import datetime, timezone, date
from sqlalchemy import Column, String, Boolean, DateTime, Date, ForeignKey, Text, JSON, Float, Integer
from sqlalchemy.orm import relationship
from app.core.database import Base, GUID
from app.models.enums import BloodGroup, OrganType, UrgencyLevel, DonorPathway, DonorEligibilityStatus

def utc_now():
    return datetime.now(timezone.utc)

class PatientRecord(Base):
    __tablename__ = "patient_records"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    patient_code = Column(String(50), unique=True, nullable=False, index=True)
    user_id = Column(GUID, ForeignKey("users.id"), nullable=True, index=True)
    hospital_id = Column(GUID, ForeignKey("hospitals.id"), nullable=False, index=True)
    full_name = Column(String(255), nullable=False, index=True)
    date_of_birth = Column(Date, nullable=False)
    gender = Column(String(20), nullable=False)
    blood_group = Column(String(10), default=BloodGroup.UNKNOWN.value, nullable=False)
    rh_factor = Column(String(10), default="POSITIVE")
    primary_contact = Column(String(50), nullable=True)
    emergency_contact = Column(String(255), nullable=True)
    address = Column(Text, nullable=True)
    
    # Clinical details
    required_organ = Column(String(50), nullable=False, index=True)
    clinical_indication = Column(Text, nullable=True)
    medical_history = Column(Text, nullable=True)
    current_medications = Column(Text, nullable=True)
    allergies = Column(Text, nullable=True)
    
    # Priority & Scores
    urgency_category = Column(String(20), default=UrgencyLevel.UNCLASSIFIED.value, nullable=False)
    meld_score = Column(Float, nullable=True)
    epts_score = Column(Float, nullable=True)
    las_score = Column(Float, nullable=True)
    
    # Workflow status
    evaluation_status = Column(String(30), default="PENDING", nullable=False)
    waiting_list_status = Column(String(30), default="PENDING", nullable=False)
    consent_status = Column(String(30), default="NOT_OBTAINED", nullable=False)
    assigned_coordinator_id = Column(GUID, ForeignKey("users.id"), nullable=True)
    
    # Audit & Soft Deletion
    is_archived = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), default=utc_now)
    updated_at = Column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)

    # Relationships
    hospital = relationship("Hospital", back_populates="patients")
    user = relationship("User", foreign_keys=[user_id])
    coordinator = relationship("User", foreign_keys=[assigned_coordinator_id])
    requests = relationship("OrganRequest", back_populates="patient", cascade="all, delete-orphan")
    documents = relationship("MedicalDocument", primaryjoin="and_(foreign(MedicalDocument.record_id)==PatientRecord.id, MedicalDocument.record_type=='PATIENT')")
    match_assessments = relationship("MatchAssessment", back_populates="patient")

class DonorRecord(Base):
    __tablename__ = "donor_records"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    donor_code = Column(String(50), unique=True, nullable=False, index=True)
    user_id = Column(GUID, ForeignKey("users.id"), nullable=True, index=True)
    hospital_id = Column(GUID, ForeignKey("hospitals.id"), nullable=False, index=True)
    full_name = Column(String(255), nullable=False, index=True)
    date_of_birth = Column(Date, nullable=False)
    gender = Column(String(20), nullable=False)
    blood_group = Column(String(10), default=BloodGroup.UNKNOWN.value, nullable=False)
    rh_factor = Column(String(10), default="POSITIVE")
    contact_details = Column(String(255), nullable=True)
    address = Column(Text, nullable=True)
    
    # Pathway: LIVING or DECEASED
    donor_pathway = Column(String(20), default=DonorPathway.LIVING.value, nullable=False)
    organs_offered = Column(JSON, default=list)  # list of OrganType strings
    hla_typing = Column(JSON, default=dict)      # {"A": ["02:01", "24:02"], "B": ...}
    infection_screening = Column(JSON, default=dict) # {"HIV": "Negative", "HepB": "Negative", ...}
    health_assessment_summary = Column(Text, nullable=True)
    
    # Eligibility & Workflow
    eligibility_status = Column(String(30), default=DonorEligibilityStatus.PENDING.value, nullable=False)
    legal_authorization_status = Column(String(30), default="PENDING", nullable=False)
    assigned_reviewer_id = Column(GUID, ForeignKey("users.id"), nullable=True)
    
    # Audit & Soft Deletion
    is_archived = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), default=utc_now)
    updated_at = Column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)

    # Relationships
    hospital = relationship("Hospital", back_populates="donors")
    user = relationship("User", foreign_keys=[user_id])
    reviewer = relationship("User", foreign_keys=[assigned_reviewer_id])
    inventory = relationship("OrganInventory", back_populates="donor")
    documents = relationship("MedicalDocument", primaryjoin="and_(foreign(MedicalDocument.record_id)==DonorRecord.id, MedicalDocument.record_type=='DONOR')", overlaps="documents")
    match_assessments = relationship("MatchAssessment", back_populates="donor")

class MedicalDocument(Base):
    __tablename__ = "medical_documents"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    record_type = Column(String(20), nullable=False)  # 'PATIENT' or 'DONOR'
    record_id = Column(GUID, nullable=False, index=True)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(512), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    mime_type = Column(String(100), nullable=False)
    classification = Column(String(50), default="CLINICAL_NOTE")
    
    # Extraction Lifecycle
    processing_status = Column(String(30), default="UPLOADED")  # UPLOADED, EXTRACTING, EXTRACTED, VERIFIED, FAILED
    extracted_data = Column(JSON, nullable=True)
    human_verified_by = Column(GUID, ForeignKey("users.id"), nullable=True)
    human_verified_at = Column(DateTime(timezone=True), nullable=True)
    verification_notes = Column(Text, nullable=True)
    
    is_archived = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), default=utc_now)

class LaboratoryTest(Base):
    __tablename__ = "laboratory_tests"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    patient_id = Column(GUID, ForeignKey("patient_records.id"), nullable=True)
    donor_id = Column(GUID, ForeignKey("donor_records.id"), nullable=True)
    test_name = Column(String(100), nullable=False)
    test_category = Column(String(50), nullable=False)
    ordered_date = Column(DateTime(timezone=True), default=utc_now)
    completed_date = Column(DateTime(timezone=True), nullable=True)
    status = Column(String(30), default="PENDING")  # PENDING, COMPLETED, FAILED, INCONCLUSIVE
    
    results = relationship("LaboratoryResult", back_populates="test", cascade="all, delete-orphan")

class LaboratoryResult(Base):
    __tablename__ = "laboratory_results"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    test_id = Column(GUID, ForeignKey("laboratory_tests.id"), nullable=False)
    marker_name = Column(String(100), nullable=False)
    numeric_value = Column(Float, nullable=True)
    unit = Column(String(30), nullable=True)
    text_value = Column(String(255), nullable=True)
    reference_range = Column(String(100), nullable=True)
    is_normal = Column(Boolean, default=True)
    interpretation = Column(Text, nullable=True)

    test = relationship("LaboratoryTest", back_populates="results")

class MedicalAssessment(Base):
    __tablename__ = "medical_assessments"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    record_type = Column(String(20), nullable=False)
    record_id = Column(GUID, nullable=False, index=True)
    clinician_id = Column(GUID, ForeignKey("users.id"), nullable=False)
    assessment_type = Column(String(50), nullable=False)
    clinical_notes = Column(Text, nullable=False)
    recommendations = Column(Text, nullable=True)
    status = Column(String(30), default="FINALIZED")
    created_at = Column(DateTime(timezone=True), default=utc_now)
