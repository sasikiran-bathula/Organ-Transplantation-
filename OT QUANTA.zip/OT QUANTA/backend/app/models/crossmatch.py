import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Text, JSON, Float, Integer
from sqlalchemy.orm import relationship
from app.core.database import Base, GUID
from app.models.enums import CrossmatchResult, ApprovalStatus

def utc_now():
    return datetime.now(timezone.utc)

class MatchAssessment(Base):
    __tablename__ = "match_assessments"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    assessment_code = Column(String(50), unique=True, nullable=False, index=True)
    patient_id = Column(GUID, ForeignKey("patient_records.id"), nullable=False, index=True)
    donor_id = Column(GUID, ForeignKey("donor_records.id"), nullable=False, index=True)
    organ_type = Column(String(50), nullable=False, index=True)
    
    # Deterministic findings
    blood_group_compatible = Column(Boolean, nullable=False)
    hla_compatibility_score = Column(Float, nullable=True)  # e.g., 0 to 6 antigens or loci matched
    crossmatch_result = Column(String(30), default=CrossmatchResult.INSUFFICIENT_DATA.value, nullable=False)
    tests_completed = Column(JSON, default=list)
    tests_pending = Column(JSON, default=list)
    clinical_warnings = Column(JSON, default=list)
    evidence_references = Column(JSON, default=list)
    explanation = Column(Text, nullable=True)
    
    # Clinical Review Barrier
    reviewer_id = Column(GUID, ForeignKey("users.id"), nullable=True)
    review_status = Column(String(30), default=ApprovalStatus.PENDING.value, nullable=False)
    review_notes = Column(Text, nullable=True)
    reviewed_at = Column(DateTime(timezone=True), nullable=True)
    
    algorithm_version = Column(String(50), default="TCQ-RULE-ENGINE-v1.0", nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now)
    updated_at = Column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)

    # Relationships
    patient = relationship("PatientRecord", back_populates="match_assessments")
    donor = relationship("DonorRecord", back_populates="match_assessments")
    reviewer = relationship("User")
    candidate_pair = relationship("CandidatePair", uselist=False, back_populates="assessment")

class CandidatePair(Base):
    __tablename__ = "candidate_pairs"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    match_assessment_id = Column(GUID, ForeignKey("match_assessments.id"), nullable=True)
    patient_id = Column(GUID, ForeignKey("patient_records.id"), nullable=False, index=True)
    donor_id = Column(GUID, ForeignKey("donor_records.id"), nullable=False, index=True)
    organ_type = Column(String(50), nullable=False)
    eligibility_satisfied = Column(Boolean, default=False, nullable=False)
    exclusion_reasons = Column(JSON, default=list)
    priority_score = Column(Float, default=0.0)
    rank = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now)

    assessment = relationship("MatchAssessment", back_populates="candidate_pair")
    patient = relationship("PatientRecord")
    donor = relationship("DonorRecord")

class AllocationRun(Base):
    __tablename__ = "allocation_runs"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    run_code = Column(String(50), unique=True, nullable=False, index=True)
    organ_inventory_id = Column(GUID, ForeignKey("organ_inventory.id"), nullable=True)
    algorithm_used = Column(String(50), nullable=False)  # CLASSICAL_MILP, QUANTUM_QAOA, HYBRID
    objective_score = Column(Float, nullable=True)
    candidates_evaluated = Column(Integer, default=0)
    allocations_found = Column(Integer, default=0)
    feasibility_rate = Column(Float, default=1.0)
    runtime_ms = Column(Float, default=0.0)
    is_benchmark = Column(Boolean, default=False)
    status = Column(String(30), default="COMPLETED")
    created_at = Column(DateTime(timezone=True), default=utc_now)

    decisions = relationship("AllocationDecision", back_populates="allocation_run")

class AllocationDecision(Base):
    __tablename__ = "allocation_decisions"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    allocation_run_id = Column(GUID, ForeignKey("allocation_runs.id"), nullable=False)
    patient_id = Column(GUID, ForeignKey("patient_records.id"), nullable=False)
    donor_id = Column(GUID, ForeignKey("donor_records.id"), nullable=False)
    organ_inventory_id = Column(GUID, ForeignKey("organ_inventory.id"), nullable=False)
    decision_status = Column(String(30), default="OFFERED")  # OFFERED, ACCEPTED, DECLINED, SUPERSEDED
    clinician_reviewer_id = Column(GUID, ForeignKey("users.id"), nullable=True)
    review_notes = Column(Text, nullable=True)
    decision_timestamp = Column(DateTime(timezone=True), default=utc_now)

    allocation_run = relationship("AllocationRun", back_populates="decisions")
    patient = relationship("PatientRecord")
    donor = relationship("DonorRecord")
    organ_inventory = relationship("OrganInventory")
    reviewer = relationship("User")

class TransplantRecord(Base):
    __tablename__ = "transplant_records"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    patient_id = Column(GUID, ForeignKey("patient_records.id"), nullable=False, index=True)
    donor_id = Column(GUID, ForeignKey("donor_records.id"), nullable=False, index=True)
    organ_inventory_id = Column(GUID, ForeignKey("organ_inventory.id"), unique=True, nullable=False)
    hospital_id = Column(GUID, ForeignKey("hospitals.id"), nullable=False)
    primary_surgeon = Column(String(255), nullable=False)
    transplant_date = Column(DateTime(timezone=True), default=utc_now, nullable=False)
    outcome_status = Column(String(50), default="SUCCESSFUL", nullable=False)
    cold_ischemia_actual_hours = Column(Float, nullable=False)
    postoperative_notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now)

    patient = relationship("PatientRecord")
    donor = relationship("DonorRecord")
    organ_inventory = relationship("OrganInventory", back_populates="transplant_record")
    hospital = relationship("Hospital")
