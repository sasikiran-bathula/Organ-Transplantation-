import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Text, JSON, Integer
from sqlalchemy.orm import relationship
from app.core.database import Base, GUID
from app.models.enums import NotificationEventType

def utc_now():
    return datetime.now(timezone.utc)

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    recipient_user_id = Column(GUID, ForeignKey("users.id"), nullable=False, index=True)
    event_type = Column(String(50), default=NotificationEventType.NEW_ORGAN_REQUEST.value, nullable=False)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    related_record_id = Column(GUID, nullable=True)
    related_record_type = Column(String(50), nullable=True)
    is_read = Column(Boolean, default=False, index=True)
    read_at = Column(DateTime(timezone=True), nullable=True)
    delivery_status = Column(String(30), default="DELIVERED")  # PENDING, DELIVERED, FAILED
    created_at = Column(DateTime(timezone=True), default=utc_now, index=True)

    recipient = relationship("User", back_populates="notifications")
    deliveries = relationship("NotificationDelivery", back_populates="notification", cascade="all, delete-orphan")

class NotificationDelivery(Base):
    __tablename__ = "notification_deliveries"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    notification_id = Column(GUID, ForeignKey("notifications.id"), nullable=False, index=True)
    channel = Column(String(30), default="IN_APP")  # IN_APP, EMAIL_SIMULATED, WEB_PUSH
    delivery_attempt = Column(Integer, default=1)
    status = Column(String(30), default="SUCCESS")
    error_message = Column(Text, nullable=True)
    attempted_at = Column(DateTime(timezone=True), default=utc_now)

    notification = relationship("Notification", back_populates="deliveries")

class AuditEvent(Base):
    __tablename__ = "audit_events"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    user_id = Column(GUID, ForeignKey("users.id"), nullable=True, index=True)
    user_email = Column(String(255), nullable=True)
    action = Column(String(100), nullable=False, index=True)  # e.g., CREATE_PATIENT, CROSSMATCH_REVIEW, VIEW_CONFIDENTIAL_RECORD
    resource_type = Column(String(100), nullable=False, index=True)
    resource_id = Column(String(100), nullable=True, index=True)
    changes = Column(JSON, default=dict)
    ip_address = Column(String(100), nullable=True)
    user_agent = Column(String(255), nullable=True)
    timestamp = Column(DateTime(timezone=True), default=utc_now, index=True)
