import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Text, Float, Integer
from sqlalchemy.orm import relationship
from app.core.database import Base, GUID
from app.models.enums import OrganType, UrgencyLevel, OrganInventoryStatus, OrganRequestStatus

def utc_now():
    return datetime.now(timezone.utc)

class OrganCatalog(Base):
    __tablename__ = "organ_catalog"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    organ_type = Column(String(50), unique=True, nullable=False, index=True)
    display_name = Column(String(100), nullable=False)
    max_ischemia_hours = Column(Float, nullable=False)  # e.g., Heart: 4-6h, Liver: 8-12h, Kidney: 24-36h
    requires_hla_match = Column(Boolean, default=True)
    requires_size_match = Column(Boolean, default=True)
    description = Column(Text, nullable=True)

    inventory_items = relationship("OrganInventory", back_populates="catalog_item")

class OrganInventory(Base):
    __tablename__ = "organ_inventory"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    organ_catalog_id = Column(GUID, ForeignKey("organ_catalog.id"), nullable=False)
    donor_id = Column(GUID, ForeignKey("donor_records.id"), nullable=False, index=True)
    hospital_id = Column(GUID, ForeignKey("hospitals.id"), nullable=False, index=True)
    
    procurement_timestamp = Column(DateTime(timezone=True), default=utc_now, nullable=False)
    preservation_method = Column(String(100), default="Static Cold Storage")
    cold_ischemia_start = Column(DateTime(timezone=True), default=utc_now, nullable=False)
    status = Column(String(30), default=OrganInventoryStatus.PROCURED.value, nullable=False, index=True)
    storage_location = Column(String(255), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now)

    # Relationships
    catalog_item = relationship("OrganCatalog", back_populates="inventory_items")
    donor = relationship("DonorRecord", back_populates="inventory")
    hospital = relationship("Hospital")
    transplant_record = relationship("TransplantRecord", back_populates="organ_inventory", uselist=False)

class OrganRequest(Base):
    __tablename__ = "organ_requests"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    request_code = Column(String(50), unique=True, nullable=False, index=True)
    patient_id = Column(GUID, ForeignKey("patient_records.id"), nullable=False, index=True)
    hospital_id = Column(GUID, ForeignKey("hospitals.id"), nullable=False, index=True)
    required_organ = Column(String(50), nullable=False, index=True)
    urgency_level = Column(String(20), default=UrgencyLevel.MEDIUM.value, nullable=False)
    status = Column(String(30), default=OrganRequestStatus.OPEN.value, nullable=False, index=True)
    living_or_deceased_preference = Column(String(20), default="EITHER")
    clinical_summary = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now)
    updated_at = Column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)

    patient = relationship("PatientRecord", back_populates="requests")
    hospital = relationship("Hospital")

class WaitingListEntry(Base):
    __tablename__ = "waiting_list_entries"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    patient_id = Column(GUID, ForeignKey("patient_records.id"), nullable=False, index=True)
    organ_type = Column(String(50), nullable=False, index=True)
    registration_date = Column(DateTime(timezone=True), default=utc_now, nullable=False)
    urgency_category = Column(String(20), default=UrgencyLevel.MEDIUM.value, nullable=False)
    calculated_priority = Column(Float, default=1.0, nullable=False)
    status = Column(String(30), default="ACTIVE", nullable=False)  # ACTIVE, TEMPORARILY_INACTIVE, REMOVED
    updated_at = Column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)

    patient = relationship("PatientRecord")
