import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Text, Float, Integer
from sqlalchemy.orm import relationship
from app.core.database import Base, GUID

def utc_now():
    return datetime.now(timezone.utc)

class QuantumExperiment(Base):
    __tablename__ = "quantum_experiments"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    experiment_code = Column(String(50), unique=True, nullable=False, index=True)
    title = Column(String(255), nullable=False)
    problem_size = Column(Integer, nullable=False)
    num_candidates = Column(Integer, nullable=False)
    num_organs = Column(Integer, nullable=False)
    
    # Solvers
    classical_algorithm = Column(String(100), default="SciPy Mixed-Integer / Hungarian")
    quantum_algorithm = Column(String(100), default="Qiskit QAOA / Statevector QUBO")
    backend_name = Column(String(100), default="qiskit_aer_simulator")
    
    # Benchmarks
    classical_runtime_ms = Column(Float, nullable=True)
    quantum_runtime_ms = Column(Float, nullable=True)
    measured_speedup = Column(Float, nullable=True)  # classical / quantum runtime
    objective_score = Column(Float, nullable=True)
    feasibility_rate = Column(Float, default=1.0)
    constraint_violations = Column(Integer, default=0)
    
    status = Column(String(30), default="COMPLETED")  # NOT_YET_BENCHMARKED, RUNNING, COMPLETED, FAILED
    limitations_notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now)

    benchmark_trials = relationship("QuantumBenchmarkResult", back_populates="experiment", cascade="all, delete-orphan")

class QuantumBenchmarkResult(Base):
    __tablename__ = "quantum_benchmark_results"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    experiment_id = Column(GUID, ForeignKey("quantum_experiments.id"), nullable=False, index=True)
    trial_index = Column(Integer, nullable=False)
    classical_time_ms = Column(Float, nullable=False)
    quantum_time_ms = Column(Float, nullable=False)
    cost_value = Column(Float, nullable=False)
    valid_solution = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=utc_now)

    experiment = relationship("QuantumExperiment", back_populates="benchmark_trials")
