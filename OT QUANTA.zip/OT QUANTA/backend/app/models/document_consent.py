import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Text, Integer
from sqlalchemy.orm import relationship
from app.core.database import Base, GUID

def utc_now():
    return datetime.now(timezone.utc)

class ConsentRecord(Base):
    __tablename__ = "consent_records"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    record_type = Column(String(50), nullable=False)  # PATIENT_RECEIPT, LIVING_DONATION, DECEASED_AUTHORIZATION
    subject_id = Column(GUID, nullable=False, index=True)  # patient_id or donor_id
    legal_document_type = Column(String(100), nullable=False)
    authorized_by_name = Column(String(255), nullable=False)
    relationship_to_subject = Column(String(100), default="SELF")
    is_revoked = Column(Boolean, default=False)
    signature_digest = Column(String(255), nullable=False)  # SHA-256 hash representing digital sign
    witness_name = Column(String(255), nullable=True)
    consent_timestamp = Column(DateTime(timezone=True), default=utc_now, nullable=False)
    audit_reference = Column(String(100), nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now)

class GeneratedReport(Base):
    __tablename__ = "generated_reports"

    id = Column(GUID, primary_key=True, default=uuid.uuid4)
    report_type = Column(String(50), nullable=False)  # CROSSMATCH_REPORT, ALLOCATION_CERTIFICATE, CLINICAL_SUMMARY
    reference_id = Column(GUID, nullable=False, index=True)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(512), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    generated_by_user_id = Column(GUID, ForeignKey("users.id"), nullable=False)
    checksum = Column(String(64), nullable=False)  # SHA-256 of file
    download_count = Column(Integer, default=0)
    disclaimer = Column(Text, nullable=False, default="Research & clinical decision support prototype. Requires certified clinical validation.")
    created_at = Column(DateTime(timezone=True), default=utc_now)

    generated_by = relationship("User")
