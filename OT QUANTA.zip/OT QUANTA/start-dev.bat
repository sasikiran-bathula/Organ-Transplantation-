@echo off
echo ==============================================================
echo   QuantaOrgan — Starting Full Stack Platform
echo ==============================================================

cd /d "%~dp0"

echo [1/2] Launching FastAPI Backend on http://localhost:8000 ...
start "QuantaOrgan Backend" cmd /k "cd backend && venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload"

echo [2/2] Launching Next.js Frontend on http://localhost:3000 ...
start "QuantaOrgan Frontend" cmd /k "cd frontend && npm.cmd run dev"

echo.
echo Application initialized!
echo Open http://localhost:3000 in your browser to access the dashboard.
echo Backend API Docs: http://localhost:8000/api/v1/docs
echo ==============================================================
