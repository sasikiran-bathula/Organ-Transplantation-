# QuantaOrgan

**QuantaOrgan** is a production-oriented, full-stack organ transplantation management and donor–recipient coordination platform. It integrates clinical patient and donor registries, private medical document extraction via Google Gemini, deterministic compatibility rule validation, allocation waiting list prioritization, classical vs. quantum matching optimization via Qiskit, audit logging, and analytical dashboards.

---

## 1. System Architecture

- **Frontend**: Next.js 15 (React 19, TypeScript), Tailwind CSS, TanStack Query, Lucide icons.
- **Backend**: Python 3.14/3.11+, FastAPI REST API (`/api/v1`), Pydantic v2, SQLAlchemy 2.0 ORM, Alembic migrations, ReportLab PDF generator.
- **AI Engine**: Official Google Gemini SDK (`gemini-2.5-flash`) for medical document entity extraction with page/line citations, uncertainty flags, and mandatory human review verification.
- **Quantum Research Module**: Python & Qiskit 2.x QUBO statevector simulation compared against a classical SciPy Hungarian / MILP baseline with measured runtime and feasibility tracking.
- **Database & Storage**: PostgreSQL (production) with SQLite zero-config development fallback; private encrypted local/S3-compatible object storage.

---

## 2. Directory Structure

```
transplantcare-quantum/
├── backend/
│   ├── app/
│   │   ├── api/v1/endpoints/     # REST API routes (Auth, Patients, Donors, Organs, Crossmatch, etc.)
│   │   ├── core/                 # Config, DB connection, JWT & BCrypt security, RBAC dependencies
│   │   ├── models/               # SQLAlchemy 2.0 models for all 22 domain tables
│   │   ├── schemas/              # Pydantic v2 validation schemas
│   │   ├── services/             # Deterministic crossmatch, audit trail, Gemini AI, ReportLab PDF
│   │   ├── main.py               # FastAPI application entry point
│   │   └── seed_data.py          # Synthetic demo data seeder (strictly labeled)
│   ├── alembic/                  # Database migration scripts
│   ├── tests/                    # Pytest test suite (Auth, RBAC boundaries, Crossmatch, Concurrency)
│   ├── storage/                  # Access-controlled private document & PDF storage
│   └── requirements.txt          # Python dependencies
├── quantum_optimizer/
│   ├── formulation.py            # Bipartite matching QUBO formulation and constraints
│   ├── classical_solver.py       # SciPy maximum weight matching baseline
│   ├── quantum_solver.py         # Qiskit QAOA / QUBO quantum statevector solver
│   └── benchmark.py              # Side-by-side benchmark runner (Speedup = T_classical / T_quantum)
├── frontend/
│   ├── app/                      # Next.js App Router (Layout, Page, Global CSS)
│   ├── components/               # Navbar, Sidebar, AuthModal, and domain views
│   ├── lib/                      # API client with token management and auto-serialization
│   └── package.json              # Frontend dependencies
├── docker-compose.yml            # Multi-service production stack (PostgreSQL, Redis, Backend, Frontend)
├── .env.example                  # Environment template
├── start-dev.bat                 # One-click Windows startup script
└── README.md
```

---

## 3. Quickstart & Installation

### Prerequisites
- Python 3.11+ or 3.14 (with `pip` and `venv`)
- Node.js 18+ and `npm`
- (Optional) Docker and Docker Compose

### 1. Backend Setup
```bash
cd backend
python -m venv venv

# On Windows:
venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate

pip install -r requirements.txt
```

### 2. Database Migrations & Synthetic Demo Seeder
```bash
# Apply database schema
python -m alembic upgrade head

# Seed synthetic demo hospital, staff, patients, donors, and initial benchmark
python app/seed_data.py
```

### 3. Run Backend Server
```bash
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```
API Documentation will be available at: `http://localhost:8000/api/v1/docs`.

### 4. Frontend Setup
```bash
cd ../frontend
npm install
npm run dev
```
Open `http://localhost:3000` in your web browser.

---

## 4. Demo User Accounts

The database comes pre-seeded with labeled synthetic demo accounts:

| Role | Email | Password | Key Permissions |
|---|---|---|---|
| **System Administrator** | `admin@transplantcare.demo` | `AdminPass123!` | Full system & audit log access |
| **Transplant Coordinator** | `coordinator@transplantcare.demo` | `CoordPass123!` | Registries, organ requests, matching queue |
| **Clinician / Surgeon** | `clinician@transplantcare.demo` | `DoctorPass123!` | Crossmatch medical review, PDF certification |
| **Laboratory Reviewer** | `lab@transplantcare.demo` | `LabPass123!` | HLA typing, serology verification |
| **Registered Patient** | `patient@transplantcare.demo` | `PatientPass123!` | View personal medical record & request status |
| **Compliance Auditor** | `auditor@transplantcare.demo` | `AuditPass123!` | Read-only clinical audit log inspection |

---

## 5. Automated Tests

Run the backend Pytest test suite:
```bash
cd backend
venv\Scripts\python -m pytest tests/ -v
```

The test suite validates:
- User registration, login, and invalid credential rejections.
- Record-level data isolation (patients cannot access other patients' records).
- Deterministic crossmatch rule evaluation (ABO/Rh matrix, HLA typing, contraindications).
- Qiskit quantum optimization benchmark execution and constraint feasibility.
- ReportLab PDF generation and cryptographic SHA-256 checksum verification.
- Audit log RBAC restrictions (admin/auditor only).

---

## 6. Docker Deployment

To launch the full production stack using Docker Compose:
```bash
docker compose up --build -d
```
This deploys:
- PostgreSQL 16 on port 5432
- Redis 7 on port 6379
- FastAPI backend on port 8000
- Next.js frontend on port 3000

---

## 7. Clinical & Regulatory Notice

> [!IMPORTANT]
> **Research and Clinical Decision Support Notice:**
> TransplantCare Quantum is an advanced research and engineering platform designed for software demonstration and optimization benchmarking. It does **NOT** substitute for certified medical devices, official national organ procurement organizations (e.g., UNOS/OPTN, Eurotransplant), or independent licensed medical judgment.
> 
> AI-assisted document extractions and quantum optimization solutions must undergo independent licensed clinician verification before any clinical intervention.
