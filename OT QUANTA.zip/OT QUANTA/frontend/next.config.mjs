import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isExport = process.env.STATIC_EXPORT === 'true';

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output: isExport ? 'export' : undefined,
  outputFileTracingRoot: __dirname,
  ...(!isExport && {
    async rewrites() {
      return [
        {
          source: '/api/:path*',
          destination: process.env.BACKEND_API_URL 
            ? `${process.env.BACKEND_API_URL}/api/:path*`
            : 'http://127.0.0.1:8000/api/:path*',
        },
      ];
    },
  }),
};

export default nextConfig;
