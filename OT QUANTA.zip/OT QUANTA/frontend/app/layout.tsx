"use client";

import "./globals.css";
import React, { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            refetchOnWindowFocus: false,
            retry: 1,
            staleTime: 1000 * 30, // 30 seconds
          },
        },
      })
  );

  return (
    <html lang="en" className="dark">
      <head>
        <title>QuantaOrgan — Organ Transplantation & Donor Coordination</title>
        <meta
          name="description"
          content="Production-oriented organ transplantation management and donor-recipient coordination platform with AI-assisted crossmatch and quantum optimization research."
        />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body className="min-h-screen bg-navy-950 text-slate-100 antialiased selection:bg-teal-500 selection:text-white">
        <QueryClientProvider client={queryClient}>
          {children}
        </QueryClientProvider>
      </body>
    </html>
  );
}
