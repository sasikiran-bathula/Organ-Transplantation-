"use client";

import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/Navbar";
import { Sidebar, NavSection } from "@/components/Sidebar";
import { AuthModal } from "@/components/AuthModal";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { DashboardView } from "@/components/views/DashboardView";
import { PatientsView } from "@/components/views/PatientsView";
import { DonorsView } from "@/components/views/DonorsView";
import { DocumentsView } from "@/components/views/DocumentsView";
import { InventoryView } from "@/components/views/InventoryView";
import { RequestsView } from "@/components/views/RequestsView";
import { CrossmatchView } from "@/components/views/CrossmatchView";
import { QuantumView } from "@/components/views/QuantumView";
import { NotificationsView } from "@/components/views/NotificationsView";
import { ConsentView } from "@/components/views/ConsentView";
import { SettingsView } from "@/components/views/SettingsView";
import { AuditLogsView } from "@/components/views/AuditLogsView";
import { getStoredUser, getAuthToken, removeAuthToken, apiRequest, setAuthToken, setStoredUser } from "@/lib/api";

export default function Home() {
  const [user, setUser] = useState<any | null>(null);
  const [currentSection, setCurrentSection] = useState<NavSection>("dashboard");
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    const stored = getStoredUser();
    const token = getAuthToken();
    if (stored && token) {
      setUser(stored);
    } else {
      // Auto-login default demo coordinator so the user immediately sees a rich, active system
      apiRequest("/auth/login", {
        method: "POST",
        body: JSON.stringify({
          email: "coordinator@quantaorgan.demo",
          password: "CoordPass123!",
        }),
      })
        .then((res) => {
          setAuthToken(res.access_token);
          const u = {
            id: res.user_id,
            email: res.email,
            role: res.role,
            full_name: res.full_name,
            hospital_id: res.hospital_id,
          };
          setStoredUser(u);
          setUser(u);
        })
        .catch(() => {
          // If seed not loaded, open auth modal
          setIsAuthOpen(true);
        });
    }
  }, []);

  const { data: unreadData } = useQuery({
    queryKey: ["unread-notifications-count", user?.id],
    queryFn: () => apiRequest("/notifications/unread-count"),
    enabled: !!user,
    refetchInterval: 15000,
  });

  const handleLogout = () => {
    removeAuthToken();
    setUser(null);
    setIsAuthOpen(true);
  };

  if (!isClient) {
    return null;
  }

  return (
    <div className="min-h-screen bg-navy-950 flex flex-col">
      <Navbar
        user={user}
        unreadCount={unreadData?.unread_count || 0}
        onOpenNotifications={() => setCurrentSection("notifications")}
        onLogout={handleLogout}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          currentSection={currentSection}
          onSelectSection={setCurrentSection}
          userRole={user?.role}
          unreadCount={unreadData?.unread_count || 0}
        />

        <main className="flex-1 overflow-y-auto p-6 md:p-8">
          <div className="mx-auto max-w-7xl">
            <ErrorBoundary fallbackTitle="Clinical View Error">
              {currentSection === "dashboard" && <DashboardView onNavigate={setCurrentSection} />}
              {currentSection === "patients" && <PatientsView user={user} />}
              {currentSection === "donors" && <DonorsView user={user} />}
              {currentSection === "documents" && <DocumentsView user={user} />}
              {currentSection === "inventory" && <InventoryView user={user} />}
              {currentSection === "requests" && <RequestsView user={user} />}
              {currentSection === "crossmatch" && <CrossmatchView user={user} />}
              {currentSection === "waiting-list" && <DashboardView onNavigate={setCurrentSection} />}
              {currentSection === "quantum" && <QuantumView />}
              {currentSection === "notifications" && <NotificationsView />}
              {currentSection === "consent" && <ConsentView />}
              {currentSection === "analytics" && <DashboardView onNavigate={setCurrentSection} />}
              {currentSection === "settings" && <SettingsView user={user} onLogout={handleLogout} />}
              {currentSection === "audit-logs" && <AuditLogsView user={user} />}
            </ErrorBoundary>
          </div>
        </main>
      </div>

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={(newUser) => setUser(newUser)}
      />
    </div>
  );
}
