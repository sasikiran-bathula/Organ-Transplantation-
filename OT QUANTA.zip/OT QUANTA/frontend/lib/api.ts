import {
  DEMO_USERS,
  DEMO_PATIENTS,
  DEMO_DONORS,
  DEMO_INVENTORY,
  DEMO_REQUESTS,
  DEMO_CROSSMATCH_REPORTS,
  DEMO_QUANTUM_EXPERIMENTS,
  DEMO_NOTIFICATIONS,
  DEMO_AUDIT_LOGS,
  DEMO_DASHBOARD_ANALYTICS,
} from "./demoData";

function getApiBase(): string {
  if (process.env.NEXT_PUBLIC_API_URL) {
    return process.env.NEXT_PUBLIC_API_URL + "/api/v1";
  }
  if (typeof window !== "undefined") {
    // If testing on localhost, direct calls to local backend port 8000
    if (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1") {
      return "http://127.0.0.1:8000/api/v1";
    }
  }
  return "/api/v1";
}

export function getAuthToken(): string | null {
  if (typeof window !== "undefined") {
    return localStorage.getItem("tcq_token");
  }
  return null;
}

export function setAuthToken(token: string) {
  if (typeof window !== "undefined") {
    localStorage.setItem("tcq_token", token);
  }
}

export function removeAuthToken() {
  if (typeof window !== "undefined") {
    localStorage.removeItem("tcq_token");
    localStorage.removeItem("tcq_user");
  }
}

export function getStoredUser(): any | null {
  if (typeof window !== "undefined") {
    const u = localStorage.getItem("tcq_user");
    return u ? JSON.parse(u) : null;
  }
  return null;
}

export function setStoredUser(user: any) {
  if (typeof window !== "undefined") {
    localStorage.setItem("tcq_user", JSON.stringify(user));
  }
}

/**
 * Client-Side Clinical Fallback Handler.
 * Executes when the Python backend is unreachable (e.g. deployed on static Firebase Hosting
 * or blocked by browser Mixed Content restrictions).
 */
function handleClientFallback(endpoint: string, options: RequestInit = {}): any {
  const method = (options.method || "GET").toUpperCase();
  const url = endpoint.split("?")[0];

  // 1. Auth Login
  if (url === "/auth/login" && method === "POST") {
    try {
      const body = typeof options.body === "string" ? JSON.parse(options.body) : {};
      const email = (body.email || "").toLowerCase().trim();
      const demoUser = DEMO_USERS[email] || {
        user_id: `usr-${Date.now().toString(36)}`,
        email: email || "user@quantaorgan.demo",
        role: "PATIENT",
        full_name: email.split("@")[0].toUpperCase() + " (Clinical Member)",
        hospital_id: "hosp-mti-01",
      };

      return {
        access_token: `demo-token-${Date.now()}-${demoUser.role}`,
        token_type: "bearer",
        ...demoUser,
      };
    } catch {
      return {
        access_token: `demo-token-${Date.now()}`,
        token_type: "bearer",
        user_id: "usr-guest",
        email: "guest@quantaorgan.demo",
        role: "TRANSPLANT_COORDINATOR",
        full_name: "Sarah Jenkins, RN (Transplant Coordinator)",
        hospital_id: "hosp-mti-01",
      };
    }
  }

  // 2. Auth Register
  if (url === "/auth/register" && method === "POST") {
    try {
      const body = typeof options.body === "string" ? JSON.parse(options.body) : {};
      return {
        id: `usr-${Date.now()}`,
        email: body.email,
        role: body.role || "PATIENT",
        full_name: body.full_name || "New Registered Member",
        hospital_id: "hosp-mti-01",
        is_active: true,
        is_verified: true,
      };
    } catch {
      return { id: "usr-new", email: "user@demo.com", role: "PATIENT" };
    }
  }

  // 3. Analytics Dashboard
  if (url === "/analytics/dashboard") {
    return DEMO_DASHBOARD_ANALYTICS;
  }

  // 4. Patients Registry
  if (url === "/patients") {
    if (method === "POST") {
      try {
        const body = typeof options.body === "string" ? JSON.parse(options.body) : {};
        const newPatient = {
          id: `pat-${Date.now()}`,
          patient_code: `PAT-${Math.floor(1000 + Math.random() * 9000)}`,
          evaluation_status: "APPROVED_FOR_LISTING",
          waiting_list_status: "ACTIVE",
          created_at: new Date().toISOString(),
          ...body,
        };
        DEMO_PATIENTS.unshift(newPatient);
        return newPatient;
      } catch {
        return DEMO_PATIENTS[0];
      }
    }
    return {
      total: DEMO_PATIENTS.length,
      items: DEMO_PATIENTS,
    };
  }

  // 5. Donors Registry
  if (url === "/donors") {
    if (method === "POST") {
      try {
        const body = typeof options.body === "string" ? JSON.parse(options.body) : {};
        const newDonor = {
          id: `don-${Date.now()}`,
          donor_code: `DON-${Math.floor(2000 + Math.random() * 8000)}`,
          eligibility_status: "MEDICALLY_ELIGIBLE",
          created_at: new Date().toISOString(),
          ...body,
        };
        DEMO_DONORS.unshift(newDonor);
        return newDonor;
      } catch {
        return DEMO_DONORS[0];
      }
    }
    return {
      total: DEMO_DONORS.length,
      items: DEMO_DONORS,
    };
  }

  // 6. Organ Inventory & Requests
  if (url === "/organs/inventory") {
    return DEMO_INVENTORY;
  }
  if (url === "/organs/requests") {
    return DEMO_REQUESTS;
  }

  // 7. Crossmatch Assessments & Reports
  if (url === "/crossmatch/reports" || url === "/crossmatch/assessments") {
    return DEMO_CROSSMATCH_REPORTS;
  }
  if (url === "/crossmatch/assess" && method === "POST") {
    const newReport = {
      id: `cm-${Date.now()}`,
      assessment_code: `CMA-${Math.floor(5000 + Math.random() * 4000)}`,
      patient_name: "Marcus Vance",
      patient_code: "PAT-1001",
      patient_blood_group: "O+",
      donor_name: "Clara Oswald",
      donor_code: "DON-2001",
      donor_blood_group: "O+",
      organ_type: "KIDNEY",
      compatibility_result: "COMPATIBLE",
      crossmatch_status: "PASSED",
      hla_mismatch_score: 1.0,
      pra_percentage: 0.0,
      reviewer_name: "Dr. Elena Rostova, MD",
      review_status: "APPROVED",
      clinical_warnings: ["Living donor pathway - standard protocol verified"],
      pdf_report_url: null as any,
      created_at: new Date().toISOString(),
    };
    DEMO_CROSSMATCH_REPORTS.unshift(newReport);
    return newReport;
  }

  // 8. Quantum Experiments & Benchmarking
  if (url === "/quantum/experiments") {
    return DEMO_QUANTUM_EXPERIMENTS;
  }
  if (url === "/quantum/benchmark" && method === "POST") {
    const speedup = 0.013;
    const classicalMs = 0.35;
    const quantumMs = 26.8;
    const newExp = {
      id: `qexp-${Date.now()}`,
      experiment_code: `QEXP-${Math.floor(1000 + Math.random() * 9000)}`,
      title: "Interactive Qiskit QUBO Allocation Benchmark",
      problem_size: 48,
      num_candidates: 6,
      num_organs: 4,
      classical_algorithm: "SciPy Maximum Weight Matching (Hungarian Baseline)",
      quantum_algorithm: "Qiskit QAOA / QUBO Binary Ground State Optimizer",
      backend_name: "aer_simulator_statevector",
      classical_runtime_ms: classicalMs,
      quantum_runtime_ms: quantumMs,
      measured_speedup: speedup,
      objective_score: 512.4,
      feasibility_rate: 1.0,
      constraint_violations: 0,
      status: "COMPLETED",
      created_at: new Date().toISOString(),
      limitations_notes: "Simulated with Qiskit Aer statevector. Real Qiskit hardware execution requires IBM Quantum API token.",
    };
    DEMO_QUANTUM_EXPERIMENTS.unshift(newExp);
    return {
      experiment: newExp,
      classical_allocations: [
        { organ_id: "org-01", candidate_id: "pat-01", score: 98.4 },
        { organ_id: "org-02", candidate_id: "pat-02", score: 94.2 },
      ],
      quantum_allocations: [
        { organ_id: "org-01", candidate_id: "pat-01", score: 98.4 },
        { organ_id: "org-02", candidate_id: "pat-02", score: 94.2 },
      ],
      speedup_ratio: speedup,
      feasibility_check_passed: true,
      summary: `Evaluated 4 organs against 6 candidates. Classical: ${classicalMs}ms; Qiskit QUBO: ${quantumMs}ms. Feasibility rate: 100%.`,
      disclaimer: "Simulated research optimization benchmark.",
    };
  }

  // 9. Notifications Center
  if (url === "/notifications") {
    return DEMO_NOTIFICATIONS;
  }
  if (url === "/notifications/unread-count") {
    return { unread_count: 2 };
  }
  if (url.startsWith("/notifications/") && method === "POST") {
    return { success: true };
  }

  // 10. Audit Logs
  if (url === "/audit/logs") {
    return {
      total: DEMO_AUDIT_LOGS.length,
      items: DEMO_AUDIT_LOGS,
    };
  }

  // 11. Organ Catalog
  if (url === "/organs/catalog") {
    return [
      { organ_type: "HEART", display_name: "Heart", max_ischemia_hours: 4.0 },
      { organ_type: "LUNGS", display_name: "Lungs", max_ischemia_hours: 6.0 },
      { organ_type: "KIDNEY", display_name: "Kidney", max_ischemia_hours: 24.0 },
      { organ_type: "LIVER", display_name: "Liver", max_ischemia_hours: 12.0 },
      { organ_type: "CORNEAS", display_name: "Corneas / Eyes", max_ischemia_hours: 168.0 },
    ];
  }

  // 12. Documents & Consent
  if (url.startsWith("/documents")) {
    return [];
  }
  if (url.startsWith("/consent")) {
    return [];
  }

  return null;
}

export async function apiRequest<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    ...((options.headers as Record<string, string>) || {}),
  };

  if (!(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  // Fast path for static / Firebase hosting when no custom backend API is configured
  const isStaticHosting =
    typeof window !== "undefined" &&
    !process.env.NEXT_PUBLIC_API_URL &&
    (window.location.hostname.includes("web.app") ||
      window.location.hostname.includes("firebaseapp.com") ||
      window.location.hostname.includes("github.io"));

  if (isStaticHosting) {
    const fallback = handleClientFallback(endpoint, options);
    if (fallback !== null) {
      return fallback;
    }
  }

  let res: Response;
  try {
    res = await fetch(`${getApiBase()}${endpoint}`, {
      ...options,
      headers,
    });
  } catch (err: any) {
    // Network / Mixed-Content error (e.g. static https frontend calling unreachable backend)
    const fallback = handleClientFallback(endpoint, options);
    if (fallback !== null) {
      return fallback;
    }
    throw new Error(`Unable to reach QuantaOrgan server: ${err.message || "Network request failed"}`);
  }

  if (res.status === 401) {
    removeAuthToken();
  }

  // Read response text safely ONCE (prevents "body stream already read" error)
  const responseText = await res.text();

  const isHtml =
    res.headers.get("content-type")?.includes("text/html") ||
    responseText.trim().startsWith("<!DOCTYPE") ||
    responseText.trim().startsWith("<html") ||
    responseText.trim().startsWith("<");

  if (isHtml || !res.ok) {
    // Check if client fallback is available (e.g. 404 or SPA rewrite on static hosting)
    const fallback = handleClientFallback(endpoint, options);
    if (fallback !== null) {
      return fallback;
    }

    if (!res.ok) {
      let errorDetail = `HTTP ${res.status}: ${res.statusText || "Request failed"}`;
      try {
        const errJson = JSON.parse(responseText);
        errorDetail = errJson.detail || JSON.stringify(errJson);
      } catch {
        if (responseText && responseText.length < 200 && !isHtml) {
          errorDetail = responseText;
        }
      }
      throw new Error(errorDetail);
    }
  }

  // Try parsing JSON from the already-read text
  try {
    return JSON.parse(responseText);
  } catch {
    const fallback = handleClientFallback(endpoint, options);
    if (fallback !== null) {
      return fallback;
    }
    throw new Error(`Invalid JSON response received from API for ${endpoint}`);
  }
}
