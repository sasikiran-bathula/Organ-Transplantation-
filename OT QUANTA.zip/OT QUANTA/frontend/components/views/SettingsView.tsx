"use client";

import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Settings, User, Mail, Phone, Lock, ShieldCheck, LogOut, Check } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function SettingsView({ user, onLogout }: { user: any; onLogout: () => void }) {
  const queryClient = useQueryClient();
  const [fullName, setFullName] = useState(user?.full_name || "");
  const [phoneNumber, setPhoneNumber] = useState("+1-555-0144");
  const [saved, setSaved] = useState(false);

  const profileMutation = useMutation({
    mutationFn: (payload: any) =>
      apiRequest("/users/profile", {
        method: "PUT",
        body: JSON.stringify(payload),
      }),
    onSuccess: () => {
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    },
  });

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="border-b border-navy-700 pb-4">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <Settings className="h-5 w-5 text-teal-400" />
          Account & Clinical Security Settings
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Profile details, session management, and authentication credentials.
        </p>
      </div>

      <div className="glass-card rounded-2xl p-6 border border-navy-700 space-y-4">
        <h3 className="text-sm font-bold text-white mb-2">Profile & Identification</h3>

        {saved && (
          <div className="rounded-lg bg-emerald-500/20 border border-emerald-500/30 p-2.5 text-xs text-emerald-300 flex items-center gap-2">
            <Check className="h-4 w-4" /> Changes saved successfully.
          </div>
        )}

        <div className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">Email Address (Identity Provider)</label>
            <input
              type="text"
              disabled
              value={user?.email || ""}
              className="w-full rounded-lg border border-navy-800 bg-navy-950/60 py-2 px-3 text-slate-400 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Assigned Clinical Role</label>
            <input
              type="text"
              disabled
              value={user?.role || ""}
              className="w-full rounded-lg border border-navy-800 bg-navy-950/60 py-2 px-3 text-teal-300 font-bold cursor-not-allowed"
            />
            <p className="text-[10px] text-slate-500 mt-1">
              Role permissions are strictly managed by system administrators.
            </p>
          </div>

          <div>
            <label className="block text-slate-300 mb-1">Full Legal Name</label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-1">Contact Phone</label>
            <input
              type="text"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
            />
          </div>

          <button
            onClick={() => profileMutation.mutate({ full_name: fullName, phone_number: phoneNumber })}
            disabled={profileMutation.isPending}
            className="rounded-lg bg-teal-600 px-4 py-2 text-xs font-semibold text-white hover:bg-teal-500 transition"
          >
            {profileMutation.isPending ? "Updating..." : "Save Profile"}
          </button>
        </div>
      </div>

      {/* Session Security */}
      <div className="glass-card rounded-2xl p-6 border border-navy-700 space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-emerald-400" />
          Active Session & Revocation
        </h3>
        <p className="text-xs text-slate-400">
          Revoke all active sessions and refresh your cryptographic authentication token.
        </p>
        <button
          onClick={onLogout}
          className="flex items-center gap-2 rounded-lg bg-rose-600/30 border border-rose-500/40 px-3.5 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-600/50 transition"
        >
          <LogOut className="h-4 w-4" />
          Revoke Sessions & Sign Out
        </button>
      </div>
    </div>
  );
}
