"use client";

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FileCheck2, FileDown, Shield, CheckCircle, Lock } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function ConsentView() {
  const { data: reports, isLoading } = useQuery({
    queryKey: ["all-crossmatch-reports"],
    queryFn: () => apiRequest("/crossmatch/reports"),
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-navy-700 pb-4">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <FileCheck2 className="h-5 w-5 text-teal-400" />
          Consent Records & Certified PDF Reports
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Cryptographically hashed digital authorizations, living donation consent, and downloadable ReportLab clinical certificates.
        </p>
      </div>

      <div className="glass-card rounded-2xl p-5 border border-navy-700">
        <h3 className="text-sm font-bold text-white mb-3">Certified Crossmatch Reports (PDF)</h3>
        <div className="space-y-3">
          {isLoading ? (
            <p className="text-xs text-slate-500">Loading certified documents...</p>
          ) : !Array.isArray(reports) || reports.length === 0 ? (
            <p className="text-xs text-slate-500">No generated reports available.</p>
          ) : (
            reports.map((rep: any) => (
              <div
                key={rep.id}
                className="flex items-center justify-between rounded-xl border border-navy-800 bg-navy-950 p-4"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white text-xs">{rep.assessment_code}</span>
                    <span className="text-[10px] text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded border border-teal-500/20">
                      {rep.organ_type}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Recipient: {rep.patient_name || rep.patient_code} • Donor: {rep.donor_name || rep.donor_code}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                      rep.crossmatch_result === "COMPATIBLE"
                        ? "text-emerald-400 bg-emerald-500/20"
                        : "text-rose-400 bg-rose-500/20"
                    }`}
                  >
                    {rep.crossmatch_result}
                  </span>
                  <button
                    onClick={async () => {
                      const res = await apiRequest(`/consent/reports/${rep.id}/generate-pdf`, { method: "POST" });
                      window.open(res.download_url, "_blank");
                    }}
                    className="flex items-center gap-1.5 rounded-lg bg-navy-800 px-3 py-1.5 text-xs text-teal-300 hover:bg-navy-700 transition"
                  >
                    <FileDown className="h-4 w-4" />
                    Download PDF
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
