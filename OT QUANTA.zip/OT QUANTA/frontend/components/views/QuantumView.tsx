"use client";

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Atom, Play, CheckCircle, AlertTriangle, Cpu, Layers, RefreshCw, BarChart2, Info } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function QuantumView() {
  const queryClient = useQueryClient();
  const [numCandidates, setNumCandidates] = useState(8);
  const [numOrgans, setNumOrgans] = useState(4);
  const [penaltyWeight, setPenaltyWeight] = useState(150.0);
  const [lastResult, setLastResult] = useState<any | null>(null);

  const { data: experiments, isLoading } = useQuery({
    queryKey: ["quantum-experiments"],
    queryFn: () => apiRequest("/quantum/experiments"),
  });

  const benchmarkMutation = useMutation({
    mutationFn: () =>
      apiRequest("/quantum/benchmark", {
        method: "POST",
        body: JSON.stringify({
          num_candidates: numCandidates,
          num_organs: numOrgans,
          penalty_weight: penaltyWeight,
          backend_type: "aer_simulator_statevector",
        }),
      }),
    onSuccess: (data) => {
      setLastResult(data);
      queryClient.invalidateQueries({ queryKey: ["quantum-experiments"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard-analytics"] });
    },
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-700 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Atom className="h-6 w-6 text-quantum-cyan animate-spin" style={{ animationDuration: "14s" }} />
            Quantum Optimization & Allocation Benchmarking
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Quadratic Unconstrained Binary Optimization (QUBO) with Qiskit QAOA / Statevector Simulation vs. Classical Baseline.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="rounded-full bg-quantum-purple/20 px-3 py-1 text-xs font-semibold text-purple-300 border border-purple-500/40">
            Qiskit 2.x • Statevector Simulator
          </span>
        </div>
      </div>

      {/* Interactive Control Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="glass-card rounded-2xl p-5 border border-teal-500/30">
          <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
            <Cpu className="h-4 w-4 text-teal-400" />
            Benchmark Configuration
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Candidate Recipients ({numCandidates})</span>
                <span className="text-teal-400 font-mono">{numCandidates} patients</span>
              </div>
              <input
                type="range"
                min="4"
                max="16"
                value={numCandidates}
                onChange={(e) => setNumCandidates(parseInt(e.target.value))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Available Organs ({numOrgans})</span>
                <span className="text-cyan-400 font-mono">{numOrgans} organs</span>
              </div>
              <input
                type="range"
                min="2"
                max="6"
                value={numOrgans}
                onChange={(e) => setNumOrgans(parseInt(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>QUBO Constraint Penalty (P)</span>
                <span className="text-purple-400 font-mono">{penaltyWeight}</span>
              </div>
              <input
                type="range"
                min="50"
                max="300"
                step="10"
                value={penaltyWeight}
                onChange={(e) => setPenaltyWeight(parseFloat(e.target.value))}
                className="w-full accent-purple-500 cursor-pointer"
              />
            </div>

            <div className="rounded-lg bg-navy-950 p-2.5 border border-navy-800 text-[11px] text-slate-400">
              Total Binary Variables (Qubits): <span className="font-mono text-teal-300 font-bold">{numCandidates * numOrgans}</span>
            </div>

            <button
              onClick={() => benchmarkMutation.mutate()}
              disabled={benchmarkMutation.isPending}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-teal-600 via-cyan-600 to-purple-600 py-2.5 text-xs font-bold text-white shadow-lg shadow-teal-500/20 hover:opacity-95 transition disabled:opacity-50"
            >
              {benchmarkMutation.isPending ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Simulating Quantum Circuit...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4" />
                  Execute Side-by-Side Benchmark
                </>
              )}
            </button>
          </div>
        </div>

        {/* Live Measured Benchmark Results */}
        <div className="lg:col-span-2 glass-card rounded-2xl p-5 border border-navy-700 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <BarChart2 className="h-4 w-4 text-cyan-400" />
                Comparative Solver Metrics
              </h3>
              {lastResult && (
                <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-[10px] font-bold text-emerald-300 border border-emerald-500/30">
                  Feasibility Check Passed
                </span>
              )}
            </div>

            {lastResult ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="rounded-xl bg-navy-950 p-3 border border-navy-800">
                    <span className="text-[10px] text-slate-400 uppercase">Classical Runtime</span>
                    <div className="text-base font-bold text-white mt-1">
                      {lastResult.experiment.classical_runtime_ms} ms
                    </div>
                    <span className="text-[9px] text-slate-500">SciPy Hungarian</span>
                  </div>

                  <div className="rounded-xl bg-navy-950 p-3 border border-navy-800">
                    <span className="text-[10px] text-slate-400 uppercase">Quantum Runtime</span>
                    <div className="text-base font-bold text-quantum-cyan mt-1">
                      {lastResult.experiment.quantum_runtime_ms} ms
                    </div>
                    <span className="text-[9px] text-slate-500">Qiskit Simulator</span>
                  </div>

                  <div className="rounded-xl bg-navy-950 p-3 border border-navy-800">
                    <span className="text-[10px] text-slate-400 uppercase">Measured Speedup</span>
                    <div className="text-base font-bold text-purple-300 mt-1">
                      {lastResult.speedup_ratio !== null ? `${lastResult.speedup_ratio}x` : "N/A"}
                    </div>
                    <span className="text-[9px] text-slate-500">T_class / T_quant</span>
                  </div>

                  <div className="rounded-xl bg-navy-950 p-3 border border-navy-800">
                    <span className="text-[10px] text-slate-400 uppercase">Feasibility Rate</span>
                    <div className="text-base font-bold text-emerald-400 mt-1">
                      {(lastResult.experiment.feasibility_rate * 100).toFixed(0)}%
                    </div>
                    <span className="text-[9px] text-slate-500">0 Constraint Violations</span>
                  </div>
                </div>

                <div className="rounded-xl bg-navy-950 p-3 border border-navy-800 text-xs">
                  <span className="text-teal-400 font-semibold block text-[11px] mb-1">Experiment Summary</span>
                  <p className="text-slate-300 text-[11px] leading-relaxed">{lastResult.summary}</p>
                </div>
              </div>
            ) : (
              <div className="flex h-48 flex-col items-center justify-center text-center text-slate-500">
                <Atom className="h-10 w-10 text-slate-600 mb-2" />
                <p className="text-xs">Adjust problem dimensions and execute a benchmark to observe measured runtimes.</p>
              </div>
            )}
          </div>

          <div className="mt-4 rounded-lg bg-navy-950/80 p-3 border border-navy-800 text-[11px] text-slate-400 flex items-start gap-2">
            <Info className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
            <p>
              <strong className="text-slate-300">Scientific Rigor & Ethics Policy:</strong> Speedup is measured strictly as Classical Runtime / Quantum Runtime. Quantum advantage claims are exploratory and do not supersede certified clinical allocation protocols.
            </p>
          </div>
        </div>
      </div>

      {/* Historical Experiments Log */}
      <div className="glass-card rounded-2xl p-5 border border-navy-700">
        <h3 className="text-sm font-bold text-white mb-4">Recorded Optimization Benchmarks</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-navy-700 text-[11px] font-semibold text-slate-400 bg-navy-950/70">
              <tr>
                <th className="py-2.5 px-3">Experiment Code</th>
                <th className="py-2.5 px-3">Problem Size</th>
                <th className="py-2.5 px-3">Organs × Candidates</th>
                <th className="py-2.5 px-3">Classical (ms)</th>
                <th className="py-2.5 px-3">Quantum (ms)</th>
                <th className="py-2.5 px-3">Speedup</th>
                <th className="py-2.5 px-3">Feasibility</th>
                <th className="py-2.5 px-3">Backend Simulator</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-navy-800 text-slate-300">
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="py-6 text-center text-slate-500">
                    Loading benchmark history...
                  </td>
                </tr>
              ) : !Array.isArray(experiments) || experiments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-6 text-center text-slate-500">
                    No benchmark history recorded yet.
                  </td>
                </tr>
              ) : (
                experiments.map((exp: any) => (
                <tr key={exp.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-2.5 px-3 font-mono font-medium text-teal-300">{exp.experiment_code}</td>
                  <td className="py-2.5 px-3 font-semibold text-white">{exp.problem_size} qubits</td>
                  <td className="py-2.5 px-3 text-slate-400">{exp.num_organs} × {exp.num_candidates}</td>
                  <td className="py-2.5 px-3 font-mono">{exp.classical_runtime_ms}</td>
                  <td className="py-2.5 px-3 font-mono text-quantum-cyan">{exp.quantum_runtime_ms}</td>
                  <td className="py-2.5 px-3 font-bold text-purple-300">{exp.measured_speedup ? `${exp.measured_speedup}x` : "N/A"}</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-semibold">{(exp.feasibility_rate * 100).toFixed(0)}%</td>
                  <td className="py-2.5 px-3 text-slate-400 font-mono text-[10px]">{exp.backend_name}</td>
                </tr>
              )))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
