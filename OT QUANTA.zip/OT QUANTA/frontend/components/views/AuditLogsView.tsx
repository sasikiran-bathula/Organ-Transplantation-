"use client";

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ShieldAlert, Search, Filter, Lock, Clock, User } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function AuditLogsView({ user }: { user: any }) {
  const [actionFilter, setActionFilter] = useState("");
  const [resourceFilter, setResourceFilter] = useState("");
  const [page, setPage] = useState(1);

  const { data, isLoading, error } = useQuery({
    queryKey: ["audit-logs", page, actionFilter, resourceFilter],
    queryFn: () => {
      const params = new URLSearchParams();
      params.set("page", page.toString());
      params.set("size", "20");
      if (actionFilter) params.set("action", actionFilter);
      if (resourceFilter) params.set("resource_type", resourceFilter);
      return apiRequest(`/audit/logs?${params.toString()}`);
    },
    enabled: user?.role === "SYSTEM_ADMIN" || user?.role === "AUDITOR",
  });

  if (user?.role !== "SYSTEM_ADMIN" && user?.role !== "AUDITOR") {
    return (
      <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-6 text-sm text-rose-300 flex items-center gap-3">
        <Lock className="h-5 w-5" />
        Access Restricted: Audit Logs are accessible exclusively to System Administrators and Certified Compliance Auditors.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-700 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldAlert className="h-5 w-5 text-rose-400" />
            Immutable Clinical Audit Trail
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Tamper-evident logs of all record creation, crossmatch authorizations, document accesses, and patient data interactions.
          </p>
        </div>
        <span className="rounded bg-rose-500/20 px-2.5 py-1 text-xs font-semibold text-rose-300 border border-rose-500/40">
          Strict Least-Privilege Access
        </span>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <input
          type="text"
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          placeholder="Filter by action (e.g. USER_LOGIN, CROSSMATCH)..."
          className="rounded-lg border border-navy-700 bg-navy-900 py-2 px-3 text-xs text-white placeholder-slate-500 focus:border-teal-500 focus:outline-none min-w-[240px]"
        />

        <select
          value={resourceFilter}
          onChange={(e) => setResourceFilter(e.target.value)}
          className="rounded-lg border border-navy-700 bg-navy-900 py-2 px-3 text-xs text-white focus:border-teal-500 focus:outline-none"
        >
          <option value="">All Resources</option>
          <option value="USER">User Accounts</option>
          <option value="PATIENT_RECORD">Patient Records</option>
          <option value="DONOR_RECORD">Donor Records</option>
          <option value="MATCH_ASSESSMENT">Crossmatch Assessments</option>
          <option value="ORGAN_INVENTORY">Organ Inventory</option>
          <option value="ORGAN_REQUEST">Organ Requests</option>
          <option value="MEDICAL_DOCUMENT">Medical Documents</option>
          <option value="QUANTUM_EXPERIMENT">Quantum Experiments</option>
        </select>
      </div>

      {/* Audit Log Table */}
      <div className="glass-card rounded-2xl border border-navy-700 overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-navy-700 text-[11px] font-semibold text-slate-400 bg-navy-950/70">
            <tr>
              <th className="py-3 px-4">Timestamp (UTC)</th>
              <th className="py-3 px-4">Actor Email</th>
              <th className="py-3 px-4">Action</th>
              <th className="py-3 px-4">Resource Target</th>
              <th className="py-3 px-4">Resource ID</th>
              <th className="py-3 px-4">Changes / Details</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-navy-800 text-slate-300">
            {isLoading ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-500">
                  Loading immutable audit events...
                </td>
              </tr>
            ) : !Array.isArray(data?.items) || data.items.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-500">
                  No audit events found.
                </td>
              </tr>
            ) : (
              data.items.map((event: any) => (
                <tr key={event.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-2.5 px-4 font-mono text-[11px] text-slate-400">
                    {new Date(event.timestamp).toISOString().replace("T", " ").slice(0, 19)}
                  </td>
                  <td className="py-2.5 px-4 font-medium text-white">{event.user_email || "System Service"}</td>
                  <td className="py-2.5 px-4">
                    <span className="rounded bg-navy-800 px-1.5 py-0.5 text-[10px] font-bold text-teal-300 border border-navy-700 font-mono">
                      {event.action}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-cyan-300 font-medium">{event.resource_type}</td>
                  <td className="py-2.5 px-4 font-mono text-[10px] text-slate-400">
                    {event.resource_id ? event.resource_id.slice(0, 13) + "..." : "N/A"}
                  </td>
                  <td className="py-2.5 px-4 font-mono text-[10px] text-slate-400 truncate max-w-xs">
                    {JSON.stringify(event.changes)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
