"use client";

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { HeartHandshake, Search, Plus, Eye, ShieldCheck, X, Check, Dna, FileText } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function DonorsView({ user }: { user: any }) {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [pathwayFilter, setPathwayFilter] = useState("");
  const [page, setPage] = useState(1);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedDonor, setSelectedDonor] = useState<any | null>(null);

  const [formData, setFormData] = useState({
    full_name: "",
    date_of_birth: "1992-04-10",
    gender: "FEMALE",
    blood_group: "O+",
    rh_factor: "POSITIVE",
    contact_details: "+1-555-0177",
    address: "New York, NY",
    donor_pathway: "LIVING",
    organs_offered: ["KIDNEY"],
    hla_typing: { A: ["02:01", "24:02"], B: ["07:02", "44:02"], DR: ["04:01", "15:01"] },
    infection_screening: { HIV: "Negative", HepB: "Negative", HepC: "Negative" },
    legal_authorization_status: "AUTHORIZED",
    eligibility_status: "ELIGIBLE",
    hospital_id: user?.hospital_id || "",
  });

  const { data, isLoading } = useQuery({
    queryKey: ["donors", page, search, pathwayFilter],
    queryFn: () => {
      const params = new URLSearchParams();
      params.set("page", page.toString());
      params.set("size", "10");
      if (search) params.set("search", search);
      if (pathwayFilter) params.set("pathway", pathwayFilter);
      return apiRequest(`/donors?${params.toString()}`);
    },
  });

  const createMutation = useMutation({
    mutationFn: (newDonor: any) =>
      apiRequest("/donors", {
        method: "POST",
        body: JSON.stringify(newDonor),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["donors"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard-analytics"] });
      setIsCreateOpen(false);
    },
  });

  const isClinicianOrAdmin =
    user?.role === "SYSTEM_ADMIN" ||
    user?.role === "TRANSPLANT_COORDINATOR" ||
    user?.role === "CLINICIAN";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-700 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <HeartHandshake className="h-5 w-5 text-cyan-400" />
            Donor Registry & Immunogenetics
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Living donors, deceased donor authorizations, HLA antigen profiles, and infection panels.
          </p>
        </div>
        {isClinicianOrAdmin && (
          <button
            onClick={() => setIsCreateOpen(true)}
            className="flex items-center gap-2 rounded-lg bg-teal-600 px-3.5 py-2 text-xs font-semibold text-white shadow-md shadow-teal-500/20 hover:bg-teal-500 transition"
          >
            <Plus className="h-4 w-4" />
            Register Donor Candidate
          </button>
        )}
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Search donors by name or code..."
            className="w-full rounded-lg border border-navy-700 bg-navy-900 py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:border-teal-500 focus:outline-none"
          />
        </div>

        <select
          value={pathwayFilter}
          onChange={(e) => {
            setPathwayFilter(e.target.value);
            setPage(1);
          }}
          className="rounded-lg border border-navy-700 bg-navy-900 py-2 px-3 text-xs text-white focus:border-teal-500 focus:outline-none"
        >
          <option value="">All Pathways</option>
          <option value="LIVING">Living Donors</option>
          <option value="DECEASED">Deceased Donors</option>
        </select>
      </div>

      {/* Donors Data Table */}
      <div className="glass-card rounded-2xl border border-navy-700 overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-navy-700 text-[11px] font-semibold text-slate-400 bg-navy-950/70">
            <tr>
              <th className="py-3 px-4">Donor Code</th>
              <th className="py-3 px-4">Full Name</th>
              <th className="py-3 px-4">Pathway</th>
              <th className="py-3 px-4">Blood Group</th>
              <th className="py-3 px-4">Organs Offered</th>
              <th className="py-3 px-4">HLA Loci</th>
              <th className="py-3 px-4">Eligibility Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-navy-800 text-slate-300">
            {isLoading ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  Loading donor registry from PostgreSQL...
                </td>
              </tr>
            ) : data?.items?.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  No donors found.
                </td>
              </tr>
            ) : (
              data?.items?.map((donor: any) => (
                <tr key={donor.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-3 px-4 font-mono font-medium text-cyan-300">{donor.donor_code}</td>
                  <td className="py-3 px-4 font-semibold text-white">{donor.full_name}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                        donor.donor_pathway === "LIVING"
                          ? "bg-teal-500/20 text-teal-300 border border-teal-500/30"
                          : "bg-purple-500/20 text-purple-300 border border-purple-500/30"
                      }`}
                    >
                      {donor.donor_pathway}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="rounded bg-navy-800 px-2 py-0.5 text-[10px] font-bold text-cyan-300 border border-navy-700">
                      {donor.blood_group} ({donor.rh_factor})
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {donor.organs_offered?.join(", ") || "General"}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-teal-400">
                    {donor.hla_typing?.A ? `A*${donor.hla_typing.A.join("/")}` : "Pending"}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-semibold ${
                        donor.eligibility_status === "ELIGIBLE"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : "bg-amber-500/20 text-amber-300"
                      }`}
                    >
                      {donor.eligibility_status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => setSelectedDonor(donor)}
                      className="rounded p-1 text-slate-400 hover:text-white hover:bg-navy-800 transition"
                      title="View Donor Details"
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Donor Details Modal */}
      {selectedDonor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl border border-navy-700 bg-navy-900 p-6 shadow-2xl">
            <button
              onClick={() => setSelectedDonor(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
            <h3 className="text-lg font-bold text-white mb-1 flex items-center gap-2">
              <HeartHandshake className="h-5 w-5 text-cyan-400" />
              {selectedDonor.full_name}
            </h3>
            <p className="text-xs text-slate-400 mb-4 font-mono">{selectedDonor.donor_code}</p>

            <div className="grid grid-cols-2 gap-3 text-xs mb-4">
              <div className="rounded-lg bg-navy-950 p-2.5 border border-navy-800">
                <span className="text-slate-400 block text-[10px]">Pathway & Blood Group</span>
                <span className="font-bold text-white">{selectedDonor.donor_pathway} • {selectedDonor.blood_group}</span>
              </div>
              <div className="rounded-lg bg-navy-950 p-2.5 border border-navy-800">
                <span className="text-slate-400 block text-[10px]">Authorization Status</span>
                <span className="font-bold text-emerald-400">{selectedDonor.legal_authorization_status}</span>
              </div>
            </div>

            <div className="rounded-lg bg-navy-950 p-3 border border-navy-800 text-xs mb-3">
              <span className="text-teal-400 font-semibold block text-[11px] mb-1 flex items-center gap-1">
                <Dna className="h-3.5 w-3.5" /> High-Resolution HLA Profile
              </span>
              <pre className="text-[11px] text-slate-300 font-mono bg-navy-900 p-2 rounded">
                {JSON.stringify(selectedDonor.hla_typing, null, 2)}
              </pre>
            </div>

            <div className="rounded-lg bg-navy-950 p-3 border border-navy-800 text-xs">
              <span className="text-cyan-400 font-semibold block text-[11px] mb-1 flex items-center gap-1">
                <ShieldCheck className="h-3.5 w-3.5" /> Serology & Infection Panel
              </span>
              <pre className="text-[11px] text-slate-300 font-mono bg-navy-900 p-2 rounded">
                {JSON.stringify(selectedDonor.infection_screening, null, 2)}
              </pre>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setSelectedDonor(null)}
                className="rounded-lg bg-navy-800 px-4 py-2 text-xs font-semibold text-white hover:bg-navy-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
