"use client";

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { FileText, Upload, Sparkles, CheckCircle2, AlertTriangle, FileDown, ShieldCheck, X } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function DocumentsView({ user }: { user: any }) {
  const queryClient = useQueryClient();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [recordType, setRecordType] = useState("PATIENT");
  const [recordId, setRecordId] = useState("");
  const [classification, setClassification] = useState("LAB_REPORT");
  const [activeDocForVerification, setActiveDocForVerification] = useState<any | null>(null);
  const [verificationNotes, setVerificationNotes] = useState("");

  const { data: patients } = useQuery({
    queryKey: ["patients-doc-selector"],
    queryFn: () => apiRequest("/patients?size=50"),
  });

  const { data: donors } = useQuery({
    queryKey: ["donors-doc-selector"],
    queryFn: () => apiRequest("/donors?size=50"),
  });

  // If recordId not set, default to first patient
  React.useEffect(() => {
    if (!recordId && patients?.items?.length > 0) {
      setRecordId(patients.items[0].id);
    }
  }, [patients, recordId]);

  const { data: documents, isLoading } = useQuery({
    queryKey: ["documents", recordType, recordId],
    queryFn: () => {
      if (!recordId) return [];
      return apiRequest(`/documents/by-record/${recordType}/${recordId}`);
    },
    enabled: !!recordId,
  });

  const uploadMutation = useMutation({
    mutationFn: (formData: FormData) =>
      apiRequest("/documents/upload", {
        method: "POST",
        body: formData,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
      setSelectedFile(null);
    },
  });

  const extractMutation = useMutation({
    mutationFn: (docId: string) =>
      apiRequest(`/documents/${docId}/extract`, { method: "POST" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });

  const verifyMutation = useMutation({
    mutationFn: ({ docId, payload }: { docId: string; payload: any }) =>
      apiRequest(`/documents/${docId}/verify`, {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
      queryClient.invalidateQueries({ queryKey: ["patients"] });
      setActiveDocForVerification(null);
    },
  });

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile || !recordId) return;

    const fd = new FormData();
    fd.append("file", selectedFile);
    fd.append("record_type", recordType);
    fd.append("record_id", recordId);
    fd.append("classification", classification);

    uploadMutation.mutate(fd);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-700 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <FileText className="h-5 w-5 text-teal-400" />
            Medical History & AI Document Extraction
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Private document repository with Google Gemini clinical extraction, source traceability, and clinician verification.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upload & Target Selector */}
        <div className="glass-card rounded-2xl p-5 border border-navy-700 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Upload className="h-4 w-4 text-teal-400" />
            Upload Clinical Document
          </h3>

          <form onSubmit={handleUpload} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-slate-300 mb-1">Subject Type</label>
              <select
                value={recordType}
                onChange={(e) => {
                  setRecordType(e.target.value);
                  setRecordId("");
                }}
                className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
              >
                <option value="PATIENT">Patient (Recipient)</option>
                <option value="DONOR">Donor Candidate</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Select Subject Record</label>
              <select
                value={recordId}
                onChange={(e) => setRecordId(e.target.value)}
                className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
              >
                {recordType === "PATIENT"
                  ? patients?.items?.map((p: any) => (
                      <option key={p.id} value={p.id}>
                        {p.full_name} ({p.patient_code})
                      </option>
                    ))
                  : donors?.items?.map((d: any) => (
                      <option key={d.id} value={d.id}>
                        {d.full_name} ({d.donor_code})
                      </option>
                    ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Document Classification</label>
              <select
                value={classification}
                onChange={(e) => setClassification(e.target.value)}
                className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
              >
                <option value="LAB_REPORT">Immunology / Lab Report</option>
                <option value="HLA_TYPING">High-Res HLA Typing</option>
                <option value="IMAGING">Diagnostic Imaging</option>
                <option value="CLINICAL_NOTE">Surgical / Clinical Summary</option>
                <option value="CONSENT_FORM">Consent Authorization</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Select File (PDF, Image, Text)</label>
              <input
                type="file"
                required
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                className="w-full text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-navy-800 file:text-teal-400 hover:file:bg-navy-700"
              />
            </div>

            <button
              type="submit"
              disabled={!selectedFile || uploadMutation.isPending}
              className="w-full rounded-lg bg-teal-600 py-2 font-semibold text-white hover:bg-teal-500 transition disabled:opacity-50"
            >
              {uploadMutation.isPending ? "Uploading..." : "Save to Private Storage"}
            </button>
          </form>
        </div>

        {/* Documents List & Gemini Extraction Cards */}
        <div className="lg:col-span-2 space-y-4">
          <div className="glass-card rounded-2xl p-5 border border-navy-700">
            <h3 className="text-sm font-bold text-white mb-3">Stored Medical Documents</h3>

            {isLoading ? (
              <p className="text-xs text-slate-500">Loading documents...</p>
            ) : !Array.isArray(documents) || documents.length === 0 ? (
              <p className="text-xs text-slate-500">No medical documents uploaded for this record.</p>
            ) : (
              <div className="space-y-3">
                {documents.map((doc: any) => (
                  <div
                    key={doc.id}
                    className="rounded-xl border border-navy-800 bg-navy-950 p-4 transition hover:border-navy-700"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <span className="font-semibold text-white text-xs block">{doc.file_name}</span>
                        <span className="text-[10px] text-slate-400">
                          {doc.classification} • {(doc.file_size_bytes / 1024).toFixed(1)} KB
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                            doc.processing_status === "VERIFIED"
                              ? "bg-emerald-500/20 text-emerald-300"
                              : doc.processing_status === "EXTRACTED"
                              ? "bg-cyan-500/20 text-cyan-300"
                              : "bg-slate-500/20 text-slate-300"
                          }`}
                        >
                          {doc.processing_status}
                        </span>

                        {doc.processing_status === "UPLOADED" && (
                          <button
                            onClick={() => extractMutation.mutate(doc.id)}
                            disabled={extractMutation.isPending}
                            className="flex items-center gap-1 rounded bg-teal-600/30 border border-teal-500/40 px-2 py-1 text-[11px] font-semibold text-teal-300 hover:bg-teal-600/50"
                          >
                            <Sparkles className="h-3.5 w-3.5 text-teal-400" />
                            Run Gemini AI
                          </button>
                        )}

                        {doc.processing_status === "EXTRACTED" && (
                          <button
                            onClick={() => {
                              setActiveDocForVerification(doc);
                              setVerificationNotes("");
                            }}
                            className="flex items-center gap-1 rounded bg-cyan-600/30 border border-cyan-500/40 px-2 py-1 text-[11px] font-semibold text-cyan-300 hover:bg-cyan-600/50"
                          >
                            <ShieldCheck className="h-3.5 w-3.5 text-cyan-400" />
                            Clinician Verify
                          </button>
                        )}

                        <a
                          href={`/api/v1/documents/${doc.id}/download`}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded p-1 text-slate-400 hover:text-white"
                          title="Download Document"
                        >
                          <FileDown className="h-4 w-4" />
                        </a>
                      </div>
                    </div>

                    {/* Extracted Schema Preview */}
                    {doc.extracted_data && (
                      <div className="mt-3 rounded-lg bg-navy-900/90 p-3 border border-navy-800 text-[11px]">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-semibold text-teal-400 flex items-center gap-1">
                            <Sparkles className="h-3.5 w-3.5" /> Structured Gemini Output (Confidence:{" "}
                            {((doc.extracted_data.confidence_score || 0.9) * 100).toFixed(0)}%)
                          </span>
                          <span className="text-[10px] text-slate-400">Source: Page & Line Citations</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-slate-300">
                          <div>
                            <span className="text-slate-500 block text-[10px]">Blood Group Detected:</span>
                            <span className="font-bold text-white">
                              {doc.extracted_data.blood_group_detected} ({doc.extracted_data.rh_factor_detected})
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-500 block text-[10px]">Missing Critical Tests:</span>
                            <span className="text-amber-300">
                              {doc.extracted_data.missing_critical_tests?.join(", ") || "None"}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Clinician Verification Modal */}
      {activeDocForVerification && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl border border-navy-700 bg-navy-900 p-6 shadow-2xl">
            <button
              onClick={() => setActiveDocForVerification(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-teal-400" />
              Clinician Verification of AI Extraction
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              AI outputs are untrusted until verified by an authorized clinician. Verify extracted serology.
            </p>

            <div className="space-y-3 text-xs mb-4">
              <div className="rounded-lg bg-navy-950 p-3 border border-navy-800">
                <span className="text-slate-400 block text-[10px] mb-1">Extracted Serology</span>
                <span className="font-semibold text-white text-sm">
                  Blood Group: {activeDocForVerification.extracted_data?.blood_group_detected}
                </span>
                <p className="text-slate-300 text-[11px] mt-1">
                  Indications: {activeDocForVerification.extracted_data?.crossmatch_indications}
                </p>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Clinician Verification Statement</label>
                <textarea
                  rows={3}
                  required
                  value={verificationNotes}
                  onChange={(e) => setVerificationNotes(e.target.value)}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                  placeholder="I have inspected the source lab document and confirm the extracted values are accurate..."
                />
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setActiveDocForVerification(null)}
                className="rounded-lg bg-navy-800 px-4 py-2 text-xs text-white hover:bg-navy-700"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  verifyMutation.mutate({
                    docId: activeDocForVerification.id,
                    payload: {
                      verified_data: activeDocForVerification.extracted_data,
                      verification_notes: verificationNotes,
                      apply_to_record: true,
                    },
                  });
                }}
                disabled={verificationNotes.length < 5 || verifyMutation.isPending}
                className="rounded-lg bg-teal-600 px-4 py-2 text-xs font-semibold text-white hover:bg-teal-500 disabled:opacity-50"
              >
                {verifyMutation.isPending ? "Authorizing..." : "Certify & Apply to Record"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
