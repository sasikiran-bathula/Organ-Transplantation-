"use client";

import React from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Bell, CheckCheck, Clock, ShieldAlert, Heart, FileText, CheckCircle } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function NotificationsView() {
  const queryClient = useQueryClient();

  const { data: notifications, isLoading } = useQuery({
    queryKey: ["notifications"],
    queryFn: () => apiRequest("/notifications"),
  });

  const markReadMutation = useMutation({
    mutationFn: (notifId: string) =>
      apiRequest(`/notifications/${notifId}/read`, { method: "POST" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
      queryClient.invalidateQueries({ queryKey: ["unread-notifications-count"] });
    },
  });

  const markAllReadMutation = useMutation({
    mutationFn: () => apiRequest("/notifications/read-all", { method: "POST" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
      queryClient.invalidateQueries({ queryKey: ["unread-notifications-count"] });
    },
  });

  const getEventIcon = (type: string) => {
    switch (type) {
      case "NEW_ORGAN_REQUEST":
      case "NEW_POTENTIAL_MATCH":
        return <Heart className="h-4 w-4 text-cyan-400" />;
      case "CLINICAL_APPROVAL_REJECTION":
        return <CheckCircle className="h-4 w-4 text-emerald-400" />;
      case "SECURITY_ALERT":
        return <ShieldAlert className="h-4 w-4 text-rose-400" />;
      default:
        return <FileText className="h-4 w-4 text-teal-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-700 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Bell className="h-5 w-5 text-teal-400" />
            Clinical Notification Center
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Database-backed clinical events, crossmatch approvals, and urgent organ matching alerts.
          </p>
        </div>
        <button
          onClick={() => markAllReadMutation.mutate()}
          className="flex items-center gap-1.5 rounded-lg border border-navy-700 bg-navy-800 px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-navy-700 transition"
        >
          <CheckCheck className="h-4 w-4" />
          Mark All as Read
        </button>
      </div>

      {/* Notifications List */}
      <div className="space-y-2.5">
        {isLoading ? (
          <p className="text-xs text-slate-500">Loading notifications...</p>
        ) : !Array.isArray(notifications) || notifications.length === 0 ? (
          <div className="rounded-xl border border-navy-800 bg-navy-950 p-8 text-center text-slate-500">
            <Bell className="mx-auto h-8 w-8 text-slate-600 mb-2" />
            <p className="text-xs">No notifications awaiting attention.</p>
          </div>
        ) : (
          notifications.map((n: any) => (
            <div
              key={n.id}
              className={`flex items-start justify-between rounded-xl border p-4 transition ${
                n.is_read
                  ? "border-navy-800 bg-navy-950/60 text-slate-400"
                  : "border-teal-500/40 bg-navy-900/90 text-white shadow-md shadow-teal-500/5"
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5 rounded-lg bg-navy-800 p-2 border border-navy-700">
                  {getEventIcon(n.event_type)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-bold text-white">{n.title}</h4>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(n.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">{n.message}</p>
                </div>
              </div>

              {!n.is_read && (
                <button
                  onClick={() => markReadMutation.mutate(n.id)}
                  className="rounded px-2 py-1 text-[11px] font-semibold text-teal-400 hover:bg-teal-500/20"
                >
                  Mark Read
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
