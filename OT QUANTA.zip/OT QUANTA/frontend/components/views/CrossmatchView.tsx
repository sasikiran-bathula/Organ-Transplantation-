"use client";

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { GitCompare, Plus, CheckCircle, XCircle, AlertTriangle, FileDown, Shield, FileText, Check, X } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function CrossmatchView({ user }: { user: any }) {
  const queryClient = useQueryClient();
  const [isAssessModalOpen, setIsAssessModalOpen] = useState(false);
  const [selectedAssessment, setSelectedAssessment] = useState<any | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");
  const [reviewDecision, setReviewDecision] = useState("APPROVED");

  const [assessForm, setAssessForm] = useState({
    patient_id: "",
    donor_id: "",
    organ_type: "KIDNEY",
  });

  const { data: reports, isLoading } = useQuery({
    queryKey: ["crossmatch-reports"],
    queryFn: () => apiRequest("/crossmatch/reports"),
  });

  const { data: patients } = useQuery({
    queryKey: ["patients-selector"],
    queryFn: () => apiRequest("/patients?size=50"),
  });

  const { data: donors } = useQuery({
    queryKey: ["donors-selector"],
    queryFn: () => apiRequest("/donors?size=50"),
  });

  const assessMutation = useMutation({
    mutationFn: (payload: any) =>
      apiRequest("/crossmatch/assess", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["crossmatch-reports"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard-analytics"] });
      setIsAssessModalOpen(false);
    },
  });

  const reviewMutation = useMutation({
    mutationFn: ({ assessmentId, payload }: { assessmentId: string; payload: any }) =>
      apiRequest(`/crossmatch/reports/${assessmentId}/review`, {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["crossmatch-reports"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard-analytics"] });
      setSelectedAssessment(null);
    },
  });

  const pdfMutation = useMutation({
    mutationFn: (assessmentId: string) =>
      apiRequest(`/consent/reports/${assessmentId}/generate-pdf`, { method: "POST" }),
    onSuccess: (data) => {
      window.open(data.download_url, "_blank");
    },
  });

  const isClinician = user?.role === "CLINICIAN" || user?.role === "SYSTEM_ADMIN";

  const getResultBadge = (result: string) => {
    switch (result) {
      case "COMPATIBLE":
        return "bg-emerald-500/20 text-emerald-300 border-emerald-500/40";
      case "INCOMPATIBLE":
        return "bg-rose-500/20 text-rose-300 border-rose-500/40";
      case "CONDITIONALLY_ACCEPTABLE":
        return "bg-amber-500/20 text-amber-300 border-amber-500/40";
      default:
        return "bg-slate-500/20 text-slate-300 border-slate-500/40";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-700 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <GitCompare className="h-5 w-5 text-teal-400" />
            AI-Assisted Crossmatch Assessment & Clinical Review
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Deterministic ABO/Rh compatibility, HLA antigen scoring, clinical warnings, and authorized physician sign-off.
          </p>
        </div>
        <button
          onClick={() => setIsAssessModalOpen(true)}
          className="flex items-center gap-2 rounded-lg bg-teal-600 px-3.5 py-2 text-xs font-semibold text-white shadow-md shadow-teal-500/20 hover:bg-teal-500 transition"
        >
          <Plus className="h-4 w-4" />
          Run Compatibility Assessment
        </button>
      </div>

      {/* Reports Table */}
      <div className="glass-card rounded-2xl border border-navy-700 overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-navy-700 text-[11px] font-semibold text-slate-400 bg-navy-950/70">
            <tr>
              <th className="py-3 px-4">Assessment Code</th>
              <th className="py-3 px-4">Patient (Recipient)</th>
              <th className="py-3 px-4">Donor Candidate</th>
              <th className="py-3 px-4">Organ</th>
              <th className="py-3 px-4">ABO Match</th>
              <th className="py-3 px-4">Deterministic Finding</th>
              <th className="py-3 px-4">Review Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-navy-800 text-slate-300">
            {isLoading ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  Loading crossmatch evaluations...
                </td>
              </tr>
            ) : !Array.isArray(reports) || reports.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  No crossmatch assessments recorded yet. Run a new assessment above.
                </td>
              </tr>
            ) : (
              reports.map((rep: any) => (
                <tr key={rep.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-3 px-4 font-mono font-medium text-teal-300">{rep.assessment_code}</td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-white block">{rep.patient_name || rep.patient_code}</span>
                    <span className="text-[10px] text-slate-400">Blood: {rep.patient_blood_group}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-white block">{rep.donor_name || rep.donor_code}</span>
                    <span className="text-[10px] text-slate-400">Blood: {rep.donor_blood_group}</span>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-200">{rep.organ_type}</td>
                  <td className="py-3 px-4">
                    {rep.blood_group_compatible ? (
                      <span className="text-emerald-400 font-semibold flex items-center gap-1">
                        <CheckCircle className="h-3.5 w-3.5" /> Compatible
                      </span>
                    ) : (
                      <span className="text-rose-400 font-semibold flex items-center gap-1">
                        <XCircle className="h-3.5 w-3.5" /> Incompatible
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`rounded border px-2 py-0.5 text-[10px] font-bold ${getResultBadge(rep.crossmatch_result)}`}>
                      {rep.crossmatch_result}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-semibold ${
                        rep.review_status === "APPROVED"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : rep.review_status === "REJECTED"
                          ? "bg-rose-500/20 text-rose-300"
                          : "bg-amber-500/20 text-amber-300"
                      }`}
                    >
                      {rep.review_status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right space-x-1.5">
                    {isClinician && rep.review_status === "PENDING" && (
                      <button
                        onClick={() => {
                          setSelectedAssessment(rep);
                          setReviewNotes("");
                        }}
                        className="rounded bg-teal-600/30 border border-teal-500/50 px-2 py-1 text-[11px] text-teal-300 hover:bg-teal-600/50"
                      >
                        Clinical Review
                      </button>
                    )}
                    <button
                      onClick={() => pdfMutation.mutate(rep.id)}
                      className="rounded bg-navy-800 p-1.5 text-slate-300 hover:text-white hover:bg-navy-700"
                      title="Download Official PDF Report"
                    >
                      <FileDown className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Trigger Assessment Modal */}
      {isAssessModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-navy-700 bg-navy-900 p-6 shadow-2xl">
            <button
              onClick={() => setIsAssessModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
            <h3 className="text-lg font-bold text-white mb-4">Run Deterministic Crossmatch</h3>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                assessMutation.mutate(assessForm);
              }}
              className="space-y-3.5 text-xs"
            >
              <div>
                <label className="block text-slate-300 mb-1">Select Recipient (Patient)</label>
                <select
                  required
                  value={assessForm.patient_id}
                  onChange={(e) => setAssessForm({ ...assessForm, patient_id: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="">-- Choose Patient --</option>
                  {patients?.items?.map((p: any) => (
                    <option key={p.id} value={p.id}>
                      {p.full_name} ({p.patient_code} • {p.blood_group} • {p.required_organ})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Select Donor Candidate</label>
                <select
                  required
                  value={assessForm.donor_id}
                  onChange={(e) => setAssessForm({ ...assessForm, donor_id: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="">-- Choose Donor --</option>
                  {donors?.items?.map((d: any) => (
                    <option key={d.id} value={d.id}>
                      {d.full_name} ({d.donor_code} • {d.blood_group} • {d.donor_pathway})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Target Organ</label>
                <select
                  value={assessForm.organ_type}
                  onChange={(e) => setAssessForm({ ...assessForm, organ_type: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="KIDNEY">Kidney</option>
                  <option value="HEART">Heart</option>
                  <option value="LIVER">Liver</option>
                  <option value="LUNGS">Lungs</option>
                  <option value="CORNEAS">Corneas</option>
                  <option value="BONE_MARROW">Bone Marrow</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAssessModalOpen(false)}
                  className="rounded-lg bg-navy-800 px-4 py-2 text-white hover:bg-navy-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={assessMutation.isPending}
                  className="rounded-lg bg-teal-600 px-4 py-2 font-semibold text-white hover:bg-teal-500"
                >
                  {assessMutation.isPending ? "Evaluating..." : "Execute Evaluation"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Clinical Review Decision Modal */}
      {selectedAssessment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl border border-navy-700 bg-navy-900 p-6 shadow-2xl">
            <button
              onClick={() => setSelectedAssessment(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
              <Shield className="h-5 w-5 text-teal-400" />
              Clinician Review Sign-off
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Authorized clinical decision for assessment <span className="font-mono text-teal-300">{selectedAssessment.assessment_code}</span>.
            </p>

            <div className="space-y-3 text-xs mb-4">
              <div className="rounded-lg bg-navy-950 p-3 border border-navy-800">
                <span className="text-slate-400 block text-[10px]">Deterministic Finding</span>
                <span className="text-white font-semibold text-sm">{selectedAssessment.crossmatch_result}</span>
                <p className="text-slate-300 mt-1 text-[11px]">{selectedAssessment.explanation}</p>
              </div>

              {selectedAssessment.clinical_warnings?.length > 0 && (
                <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-2.5 text-amber-300">
                  <span className="font-bold flex items-center gap-1 mb-1">
                    <AlertTriangle className="h-3.5 w-3.5" /> Clinical Contraindication Warnings
                  </span>
                  <ul className="list-disc pl-4 space-y-0.5 text-[11px]">
                    {selectedAssessment.clinical_warnings.map((w: string, i: number) => (
                      <li key={i}>{w}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Review Decision</label>
                <div className="flex gap-3">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="decision"
                      value="APPROVED"
                      checked={reviewDecision === "APPROVED"}
                      onChange={() => setReviewDecision("APPROVED")}
                    />
                    <span className="text-emerald-300 font-semibold">Grant Clinical Approval</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="decision"
                      value="REJECTED"
                      checked={reviewDecision === "REJECTED"}
                      onChange={() => setReviewDecision("REJECTED")}
                    />
                    <span className="text-rose-300 font-semibold">Reject / Incompatible</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Mandatory Clinical Justification Notes</label>
                <textarea
                  rows={3}
                  required
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                  placeholder="Record medical reasoning, serology verification, and risk protocol adherence..."
                />
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedAssessment(null)}
                className="rounded-lg bg-navy-800 px-4 py-2 text-xs text-white hover:bg-navy-700"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  reviewMutation.mutate({
                    assessmentId: selectedAssessment.id,
                    payload: { decision: reviewDecision, review_notes: reviewNotes },
                  });
                }}
                disabled={reviewNotes.length < 5 || reviewMutation.isPending}
                className="rounded-lg bg-teal-600 px-4 py-2 text-xs font-semibold text-white hover:bg-teal-500 disabled:opacity-50"
              >
                {reviewMutation.isPending ? "Submitting..." : "Submit Formal Decision"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
