"use client";

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Boxes, Plus, Clock, AlertTriangle, ShieldCheck, Thermometer, MapPin } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function InventoryView({ user }: { user: any }) {
  const queryClient = useQueryClient();
  const [isProcureOpen, setIsProcureOpen] = useState(false);

  const { data: inventory, isLoading } = useQuery({
    queryKey: ["organ-inventory"],
    queryFn: () => apiRequest("/organs/inventory"),
  });

  const { data: catalog } = useQuery({
    queryKey: ["organ-catalog"],
    queryFn: () => apiRequest("/organs/catalog"),
  });

  const { data: donors } = useQuery({
    queryKey: ["donors-inventory-selector"],
    queryFn: () => apiRequest("/donors?size=50"),
  });

  const [form, setForm] = useState({
    organ_catalog_id: "",
    donor_id: "",
    preservation_method: "Pulsatile Hypothermic Machine Perfusion",
    storage_location: "Preservation Lab A - Unit 2",
    notes: "Organ harvested under aseptic conditions; optimal perfusion parameters.",
    hospital_id: user?.hospital_id || "",
  });

  const procureMutation = useMutation({
    mutationFn: (payload: any) =>
      apiRequest("/organs/inventory", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organ-inventory"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard-analytics"] });
      setIsProcureOpen(false);
    },
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-700 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Boxes className="h-5 w-5 text-emerald-400" />
            Organ Inventory & Preservation Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Cold ischemia duration tracking, preservation methods, and clinical procurement state.
          </p>
        </div>
        <button
          onClick={() => setIsProcureOpen(true)}
          className="flex items-center gap-2 rounded-lg bg-teal-600 px-3.5 py-2 text-xs font-semibold text-white shadow-md shadow-teal-500/20 hover:bg-teal-500 transition"
        >
          <Plus className="h-4 w-4" />
          Procure / Log Organ
        </button>
      </div>

      {/* Inventory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          <p className="text-xs text-slate-500">Loading inventory records...</p>
        ) : !Array.isArray(inventory) || inventory.length === 0 ? (
          <p className="text-xs text-slate-500">No organs currently in inventory.</p>
        ) : (
          inventory.map((item: any) => {
            const isNearLimit = item.ischemia_elapsed_hours && item.max_ischemia_hours && item.ischemia_elapsed_hours > item.max_ischemia_hours * 0.75;
            return (
              <div
                key={item.id}
                className="glass-card rounded-2xl p-5 border border-navy-700 hover:border-teal-500/40 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-white text-sm">{item.organ_type}</span>
                    <span className="rounded bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                      {item.status}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-300 mb-3">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Donor Code:</span>
                      <span className="font-mono text-cyan-300">{item.donor_code || "N/A"}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Donor Blood Group:</span>
                      <span className="font-bold text-white">{item.donor_blood_group || "N/A"}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Preservation:</span>
                      <span className="text-slate-200">{item.preservation_method}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Storage Location:</span>
                      <span className="text-slate-200">{item.storage_location || "Central Lab"}</span>
                    </div>
                  </div>
                </div>

                {/* Cold Ischemia Countdown Meter */}
                <div className="rounded-xl bg-navy-950 p-3 border border-navy-800 text-xs mt-2">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5 text-teal-400" /> Cold Ischemia Elapsed:
                    </span>
                    <span className={`font-mono font-bold ${isNearLimit ? "text-rose-400" : "text-teal-300"}`}>
                      {item.ischemia_elapsed_hours || 0} hrs / Max {item.max_ischemia_hours || 24} hrs
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-navy-900 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${isNearLimit ? "bg-rose-500" : "bg-teal-500"}`}
                      style={{
                        width: `${Math.min(
                          100,
                          ((item.ischemia_elapsed_hours || 1) / (item.max_ischemia_hours || 24)) * 100
                        )}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Procure Modal */}
      {isProcureOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-navy-700 bg-navy-900 p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-4">Procure & Register Organ</h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                procureMutation.mutate(form);
              }}
              className="space-y-3.5 text-xs"
            >
              <div>
                <label className="block text-slate-300 mb-1">Select Organ Type</label>
                <select
                  required
                  value={form.organ_catalog_id}
                  onChange={(e) => setForm({ ...form, organ_catalog_id: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="">-- Choose Organ --</option>
                  {catalog?.map((c: any) => (
                    <option key={c.id} value={c.id}>
                      {c.display_name} (Max Ischemia: {c.max_ischemia_hours}h)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Select Donor</label>
                <select
                  required
                  value={form.donor_id}
                  onChange={(e) => setForm({ ...form, donor_id: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="">-- Choose Donor --</option>
                  {donors?.items?.map((d: any) => (
                    <option key={d.id} value={d.id}>
                      {d.full_name} ({d.donor_code} • {d.blood_group})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Preservation Method</label>
                <input
                  type="text"
                  required
                  value={form.preservation_method}
                  onChange={(e) => setForm({ ...form, preservation_method: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Storage Location</label>
                <input
                  type="text"
                  required
                  value={form.storage_location}
                  onChange={(e) => setForm({ ...form, storage_location: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsProcureOpen(false)}
                  className="rounded-lg bg-navy-800 px-4 py-2 text-white hover:bg-navy-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={procureMutation.isPending}
                  className="rounded-lg bg-teal-600 px-4 py-2 font-semibold text-white hover:bg-teal-500"
                >
                  {procureMutation.isPending ? "Logging..." : "Log to Inventory"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
