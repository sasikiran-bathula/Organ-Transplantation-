"use client";

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ClipboardList, Plus, AlertCircle, CheckCircle, Clock } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function RequestsView({ user }: { user: any }) {
  const queryClient = useQueryClient();
  const [isSubmitOpen, setIsSubmitOpen] = useState(false);

  const { data: requests, isLoading } = useQuery({
    queryKey: ["organ-requests"],
    queryFn: () => apiRequest("/organs/requests"),
  });

  const { data: patients } = useQuery({
    queryKey: ["patients-request-selector"],
    queryFn: () => apiRequest("/patients?size=50"),
  });

  const [form, setForm] = useState({
    patient_id: "",
    required_organ: "KIDNEY",
    urgency_level: "MEDIUM",
    living_or_deceased_preference: "EITHER",
    clinical_summary: "Patient evaluated and placed on active waiting list.",
    hospital_id: user?.hospital_id || "",
  });

  const submitMutation = useMutation({
    mutationFn: (payload: any) =>
      apiRequest("/organs/requests", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organ-requests"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard-analytics"] });
      setIsSubmitOpen(false);
    },
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-700 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <ClipboardList className="h-5 w-5 text-amber-400" />
            Organ Requests & Matching Queue
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time organ demand requests and active match coordination.
          </p>
        </div>
        <button
          onClick={() => setIsSubmitOpen(true)}
          className="flex items-center gap-2 rounded-lg bg-teal-600 px-3.5 py-2 text-xs font-semibold text-white shadow-md shadow-teal-500/20 hover:bg-teal-500 transition"
        >
          <Plus className="h-4 w-4" />
          Submit Organ Request
        </button>
      </div>

      {/* Requests Table */}
      <div className="glass-card rounded-2xl border border-navy-700 overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-navy-700 text-[11px] font-semibold text-slate-400 bg-navy-950/70">
            <tr>
              <th className="py-3 px-4">Request Code</th>
              <th className="py-3 px-4">Patient Candidate</th>
              <th className="py-3 px-4">Blood Group</th>
              <th className="py-3 px-4">Required Organ</th>
              <th className="py-3 px-4">Urgency Level</th>
              <th className="py-3 px-4">Donor Pathway Preference</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4">Hospital</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-navy-800 text-slate-300">
            {isLoading ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  Loading requests from PostgreSQL...
                </td>
              </tr>
            ) : !Array.isArray(requests) || requests.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  No organ requests currently active.
                </td>
              </tr>
            ) : (
              requests.map((req: any) => (
                <tr key={req.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-3 px-4 font-mono font-medium text-teal-300">{req.request_code}</td>
                  <td className="py-3 px-4 font-semibold text-white">{req.patient_name || req.patient_code}</td>
                  <td className="py-3 px-4">
                    <span className="rounded bg-navy-800 px-2 py-0.5 text-[10px] font-bold text-cyan-300 border border-navy-700">
                      {req.blood_group}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-200">{req.required_organ}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                        req.urgency_level === "HIGH"
                          ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                          : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                      }`}
                    >
                      {req.urgency_level}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">{req.living_or_deceased_preference}</td>
                  <td className="py-3 px-4">
                    <span className="rounded bg-emerald-500/20 px-2 py-0.5 text-[10px] font-semibold text-emerald-300">
                      {req.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">{req.hospital_name || "MTI Demo"}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Submit Modal */}
      {isSubmitOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-navy-700 bg-navy-900 p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-4">Log Patient Organ Request</h3>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                submitMutation.mutate(form);
              }}
              className="space-y-3.5 text-xs"
            >
              <div>
                <label className="block text-slate-300 mb-1">Select Candidate Patient</label>
                <select
                  required
                  value={form.patient_id}
                  onChange={(e) => setForm({ ...form, patient_id: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="">-- Choose Patient --</option>
                  {patients?.items?.map((p: any) => (
                    <option key={p.id} value={p.id}>
                      {p.full_name} ({p.patient_code} • {p.blood_group})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Required Organ</label>
                <select
                  value={form.required_organ}
                  onChange={(e) => setForm({ ...form, required_organ: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="KIDNEY">Kidney</option>
                  <option value="HEART">Heart</option>
                  <option value="LIVER">Liver</option>
                  <option value="LUNGS">Lungs</option>
                  <option value="PANCREAS">Pancreas</option>
                  <option value="CORNEAS">Corneas</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Urgency Classification</label>
                <select
                  value={form.urgency_level}
                  onChange={(e) => setForm({ ...form, urgency_level: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="HIGH">High Priority (Status 1A / Critical)</option>
                  <option value="MEDIUM">Medium Priority (Standard Active)</option>
                  <option value="LOW">Low Priority (Elective / Stable)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Donor Pathway Preference</label>
                <select
                  value={form.living_or_deceased_preference}
                  onChange={(e) => setForm({ ...form, living_or_deceased_preference: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="EITHER">Either Living or Deceased</option>
                  <option value="LIVING_ONLY">Living Donor Preferred</option>
                  <option value="DECEASED_ONLY">Deceased Donor Only</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Clinical Summary</label>
                <textarea
                  rows={2}
                  value={form.clinical_summary}
                  onChange={(e) => setForm({ ...form, clinical_summary: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsSubmitOpen(false)}
                  className="rounded-lg bg-navy-800 px-4 py-2 text-white hover:bg-navy-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitMutation.isPending}
                  className="rounded-lg bg-teal-600 px-4 py-2 font-semibold text-white hover:bg-teal-500"
                >
                  {submitMutation.isPending ? "Submitting..." : "Submit Request"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
