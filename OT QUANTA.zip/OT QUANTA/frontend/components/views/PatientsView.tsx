"use client";

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Users, Search, Plus, Eye, Archive, X, Check, Activity, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/api";

export function PatientsView({ user }: { user: any }) {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [organFilter, setOrganFilter] = useState("");
  const [urgencyFilter, setUrgencyFilter] = useState("");
  const [page, setPage] = useState(1);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<any | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    full_name: "",
    date_of_birth: "1985-06-15",
    gender: "MALE",
    blood_group: "O+",
    rh_factor: "POSITIVE",
    primary_contact: "+1-555-0188",
    emergency_contact: "+1-555-0199",
    address: "New York, NY",
    required_organ: "KIDNEY",
    urgency_category: "MEDIUM",
    meld_score: "",
    epts_score: "",
    las_score: "",
    clinical_indication: "End-stage renal failure, dialysis dependent",
    hospital_id: user?.hospital_id || "",
  });

  const { data, isLoading, error } = useQuery({
    queryKey: ["patients", page, search, organFilter, urgencyFilter],
    queryFn: () => {
      const params = new URLSearchParams();
      params.set("page", page.toString());
      params.set("size", "10");
      if (search) params.set("search", search);
      if (organFilter) params.set("organ_type", organFilter);
      if (urgencyFilter) params.set("urgency", urgencyFilter);
      return apiRequest(`/patients?${params.toString()}`);
    },
  });

  const createMutation = useMutation({
    mutationFn: (newPatient: any) =>
      apiRequest("/patients", {
        method: "POST",
        body: JSON.stringify(newPatient),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["patients"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard-analytics"] });
      setIsCreateOpen(false);
    },
  });

  const archiveMutation = useMutation({
    mutationFn: (patientId: string) =>
      apiRequest(`/patients/${patientId}`, { method: "DELETE" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["patients"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard-analytics"] });
    },
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({
      ...formData,
      meld_score: formData.meld_score ? parseFloat(formData.meld_score) : null,
      epts_score: formData.epts_score ? parseFloat(formData.epts_score) : null,
      las_score: formData.las_score ? parseFloat(formData.las_score) : null,
    });
  };

  const isClinicianOrAdmin =
    user?.role === "SYSTEM_ADMIN" ||
    user?.role === "TRANSPLANT_COORDINATOR" ||
    user?.role === "CLINICIAN";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-navy-700 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Users className="h-5 w-5 text-teal-400" />
            Patient Registry & Medical Indication
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Registered candidates, HLA crossmatch records, and approved clinical priorities.
          </p>
        </div>
        {isClinicianOrAdmin && (
          <button
            onClick={() => setIsCreateOpen(true)}
            className="flex items-center gap-2 rounded-lg bg-teal-600 px-3.5 py-2 text-xs font-semibold text-white shadow-md shadow-teal-500/20 hover:bg-teal-500 transition"
          >
            <Plus className="h-4 w-4" />
            Register New Candidate
          </button>
        )}
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Search by full name or patient code..."
            className="w-full rounded-lg border border-navy-700 bg-navy-900 py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:border-teal-500 focus:outline-none"
          />
        </div>

        <select
          value={organFilter}
          onChange={(e) => {
            setOrganFilter(e.target.value);
            setPage(1);
          }}
          className="rounded-lg border border-navy-700 bg-navy-900 py-2 px-3 text-xs text-white focus:border-teal-500 focus:outline-none"
        >
          <option value="">All Organs</option>
          <option value="HEART">Heart</option>
          <option value="KIDNEY">Kidney</option>
          <option value="LIVER">Liver</option>
          <option value="LUNGS">Lungs</option>
          <option value="CORNEAS">Corneas</option>
        </select>

        <select
          value={urgencyFilter}
          onChange={(e) => {
            setUrgencyFilter(e.target.value);
            setPage(1);
          }}
          className="rounded-lg border border-navy-700 bg-navy-900 py-2 px-3 text-xs text-white focus:border-teal-500 focus:outline-none"
        >
          <option value="">All Priorities</option>
          <option value="HIGH">High Priority</option>
          <option value="MEDIUM">Medium Priority</option>
          <option value="LOW">Low Priority</option>
        </select>
      </div>

      {/* Patients Data Table */}
      <div className="glass-card rounded-2xl border border-navy-700 overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-navy-700 text-[11px] font-semibold text-slate-400 bg-navy-950/70">
            <tr>
              <th className="py-3 px-4">Patient Code</th>
              <th className="py-3 px-4">Full Name</th>
              <th className="py-3 px-4">Blood Group</th>
              <th className="py-3 px-4">Required Organ</th>
              <th className="py-3 px-4">Urgency</th>
              <th className="py-3 px-4">Clinical Index</th>
              <th className="py-3 px-4">Waiting Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-navy-800 text-slate-300">
            {isLoading ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  Loading patient records from PostgreSQL...
                </td>
              </tr>
            ) : data?.items?.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  No patient records match the selected filters.
                </td>
              </tr>
            ) : (
              data?.items?.map((patient: any) => (
                <tr key={patient.id} className="hover:bg-navy-800/40 transition">
                  <td className="py-3 px-4 font-mono font-medium text-teal-300">{patient.patient_code}</td>
                  <td className="py-3 px-4 font-semibold text-white">{patient.full_name}</td>
                  <td className="py-3 px-4">
                    <span className="rounded bg-navy-800 px-2 py-0.5 text-[10px] font-bold text-cyan-300 border border-navy-700">
                      {patient.blood_group} ({patient.rh_factor})
                    </span>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-200">{patient.required_organ}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                        patient.urgency_category === "HIGH"
                          ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                          : patient.urgency_category === "MEDIUM"
                          ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                          : "bg-slate-500/20 text-slate-300 border border-slate-500/30"
                      }`}
                    >
                      {patient.urgency_category}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {patient.meld_score ? `MELD: ${patient.meld_score}` : patient.epts_score ? `EPTS: ${patient.epts_score}%` : patient.las_score ? `LAS: ${patient.las_score}` : "Standard"}
                  </td>
                  <td className="py-3 px-4">
                    <span className="rounded bg-emerald-500/20 px-2 py-0.5 text-[10px] font-semibold text-emerald-300">
                      {patient.waiting_list_status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right space-x-2">
                    <button
                      onClick={() => setSelectedPatient(patient)}
                      className="rounded p-1 text-slate-400 hover:text-white hover:bg-navy-800 transition"
                      title="View Clinical Details"
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                    {isClinicianOrAdmin && (
                      <button
                        onClick={() => archiveMutation.mutate(patient.id)}
                        className="rounded p-1 text-slate-400 hover:text-rose-400 hover:bg-navy-800 transition"
                        title="Archive Patient"
                      >
                        <Archive className="h-4 w-4" />
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Detail Modal */}
      {selectedPatient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl border border-navy-700 bg-navy-900 p-6 shadow-2xl">
            <button
              onClick={() => setSelectedPatient(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
            <h3 className="text-lg font-bold text-white mb-1 flex items-center gap-2">
              <Users className="h-5 w-5 text-teal-400" />
              {selectedPatient.full_name}
            </h3>
            <p className="text-xs text-slate-400 mb-4 font-mono">{selectedPatient.patient_code}</p>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="rounded-lg bg-navy-950 p-2.5 border border-navy-800">
                <span className="text-slate-400 block text-[10px]">Blood Group & Rh</span>
                <span className="font-bold text-white">{selectedPatient.blood_group} ({selectedPatient.rh_factor})</span>
              </div>
              <div className="rounded-lg bg-navy-950 p-2.5 border border-navy-800">
                <span className="text-slate-400 block text-[10px]">Required Organ</span>
                <span className="font-bold text-teal-300">{selectedPatient.required_organ}</span>
              </div>
              <div className="rounded-lg bg-navy-950 p-2.5 border border-navy-800">
                <span className="text-slate-400 block text-[10px]">Date of Birth / Gender</span>
                <span className="font-bold text-white">{selectedPatient.date_of_birth} ({selectedPatient.gender})</span>
              </div>
              <div className="rounded-lg bg-navy-950 p-2.5 border border-navy-800">
                <span className="text-slate-400 block text-[10px]">Urgency Classification</span>
                <span className="font-bold text-amber-300">{selectedPatient.urgency_category}</span>
              </div>
            </div>

            <div className="mt-4 rounded-lg bg-navy-950 p-3 border border-navy-800 text-xs">
              <span className="text-slate-400 block text-[10px] mb-1">Clinical Indication</span>
              <p className="text-slate-200">{selectedPatient.clinical_indication || "Standard transplant protocol"}</p>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setSelectedPatient(null)}
                className="rounded-lg bg-navy-800 px-4 py-2 text-xs font-semibold text-white hover:bg-navy-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Patient Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl border border-navy-700 bg-navy-900 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsCreateOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
            <h3 className="text-lg font-bold text-white mb-4">Register New Transplant Candidate</h3>

            <form onSubmit={handleCreate} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                  placeholder="Candidate name"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Date of Birth</label>
                  <input
                    type="date"
                    required
                    value={formData.date_of_birth}
                    onChange={(e) => setFormData({ ...formData, date_of_birth: e.target.value })}
                    className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Gender</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                    className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                  >
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Blood Group</label>
                  <select
                    value={formData.blood_group}
                    onChange={(e) => setFormData({ ...formData, blood_group: e.target.value })}
                    className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                  >
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Required Organ</label>
                  <select
                    value={formData.required_organ}
                    onChange={(e) => setFormData({ ...formData, required_organ: e.target.value })}
                    className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                  >
                    <option value="KIDNEY">Kidney</option>
                    <option value="HEART">Heart</option>
                    <option value="LIVER">Liver</option>
                    <option value="LUNGS">Lungs</option>
                    <option value="PANCREAS">Pancreas</option>
                    <option value="CORNEAS">Corneas / Eyes</option>
                    <option value="BONE_MARROW">Bone Marrow</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Urgency Classification</label>
                  <select
                    value={formData.urgency_category}
                    onChange={(e) => setFormData({ ...formData, urgency_category: e.target.value })}
                    className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                  >
                    <option value="HIGH">High Priority</option>
                    <option value="MEDIUM">Medium Priority</option>
                    <option value="LOW">Low Priority</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Clinical Severity Score (MELD / EPTS)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.meld_score}
                    onChange={(e) => setFormData({ ...formData, meld_score: e.target.value })}
                    className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                    placeholder="e.g. 28.5"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Clinical Indication</label>
                <textarea
                  rows={2}
                  value={formData.clinical_indication}
                  onChange={(e) => setFormData({ ...formData, clinical_indication: e.target.value })}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-white focus:border-teal-500 focus:outline-none"
                  placeholder="Primary diagnostic indication..."
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="rounded-lg bg-navy-800 px-4 py-2 text-white hover:bg-navy-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="rounded-lg bg-teal-600 px-4 py-2 font-semibold text-white hover:bg-teal-500"
                >
                  {createMutation.isPending ? "Saving..." : "Save Record"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
