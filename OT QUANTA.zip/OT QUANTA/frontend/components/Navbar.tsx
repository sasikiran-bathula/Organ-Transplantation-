"use client";

import React from "react";
import { Bell, Shield, User as UserIcon, LogOut, Activity, Atom } from "lucide-react";

interface NavbarProps {
  user: any;
  unreadCount: number;
  onOpenNotifications: () => void;
  onLogout: () => void;
  onOpenAuth: () => void;
}

export function Navbar({
  user,
  unreadCount,
  onOpenNotifications,
  onLogout,
  onOpenAuth,
}: NavbarProps) {
  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "SYSTEM_ADMIN":
        return "bg-rose-500/20 text-rose-300 border-rose-500/30";
      case "CLINICIAN":
        return "bg-teal-500/20 text-teal-300 border-teal-500/30";
      case "TRANSPLANT_COORDINATOR":
        return "bg-cyan-500/20 text-cyan-300 border-cyan-500/30";
      case "LAB_REVIEWER":
        return "bg-purple-500/20 text-purple-300 border-purple-500/30";
      case "AUDITOR":
        return "bg-amber-500/20 text-amber-300 border-amber-500/30";
      default:
        return "bg-slate-500/20 text-slate-300 border-slate-500/30";
    }
  };

  return (
    <header className="sticky top-0 z-40 flex h-16 w-full items-center justify-between border-b border-navy-700 bg-navy-900/90 px-6 backdrop-blur-md">
      {/* Brand & Healthcare Center */}
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-quantum-cyan shadow-lg shadow-teal-500/20">
          <Atom className="h-6 w-6 text-navy-950 animate-spin" style={{ animationDuration: "12s" }} />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold tracking-tight text-white">Quanta<span className="text-teal-400">Organ</span></span>
            <span className="rounded bg-teal-500/20 px-1.5 py-0.5 text-xs font-semibold text-teal-300 border border-teal-500/30">
              PLATFORM
            </span>
          </div>
          <p className="text-xs text-slate-400">Metropolitan Transplant Institute • Clinical Platform</p>
        </div>
      </div>

      {/* User Actions & Notification Badge */}
      <div className="flex items-center gap-4">
        {user ? (
          <>
            {/* Notification Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative rounded-lg p-2 text-slate-400 hover:bg-navy-800 hover:text-white transition"
              title="Notifications"
            >
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-sm shadow-rose-500/50">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </button>

            {/* User Profile Pill */}
            <div className="flex items-center gap-3 border-l border-navy-700 pl-4">
              <div className="flex flex-col text-right">
                <span className="text-xs font-medium text-white">{user.full_name || user.email}</span>
                <span
                  className={`mt-0.5 inline-block self-end rounded border px-1.5 py-0.2 text-[10px] font-semibold tracking-wide ${getRoleBadgeColor(
                    user.role
                  )}`}
                >
                  {user.role}
                </span>
              </div>
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-navy-800 border border-navy-700 text-teal-400">
                <UserIcon className="h-4 w-4" />
              </div>
              <button
                onClick={onLogout}
                className="rounded-lg p-2 text-slate-400 hover:bg-rose-500/20 hover:text-rose-300 transition"
                title="Sign Out"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </>
        ) : (
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-2 rounded-lg bg-teal-600 px-4 py-2 text-xs font-semibold text-white shadow-md shadow-teal-500/20 hover:bg-teal-500 transition"
          >
            <Shield className="h-4 w-4" />
            Sign In / Register
          </button>
        )}
      </div>
    </header>
  );
}
