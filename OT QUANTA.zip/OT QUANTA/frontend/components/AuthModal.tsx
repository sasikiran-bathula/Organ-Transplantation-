"use client";

import React, { useState } from "react";
import { Eye, EyeOff, Shield, X, Check, Lock, Mail, User, Phone } from "lucide-react";
import { apiRequest, setAuthToken, setStoredUser } from "@/lib/api";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: any) => void;
}

export function AuthModal({ isOpen, onClose, onSuccess }: AuthModalProps) {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [role, setRole] = useState("PATIENT");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (isRegister) {
        if (password !== confirmPassword) {
          throw new Error("Passwords do not match.");
        }
        await apiRequest("/auth/register", {
          method: "POST",
          body: JSON.stringify({
            email,
            password,
            full_name: fullName,
            phone_number: phoneNumber,
            role,
            terms_accepted: true,
          }),
        });
      }

      // Login
      const res = await apiRequest("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });

      setAuthToken(res.access_token);
      setStoredUser({
        id: res.user_id,
        email: res.email,
        role: res.role,
        full_name: res.full_name,
        hospital_id: res.hospital_id,
      });

      onSuccess({
        id: res.user_id,
        email: res.email,
        role: res.role,
        full_name: res.full_name,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || "Authentication failed");
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setIsRegister(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-2xl border border-navy-700 bg-navy-900 p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="text-center mb-6">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
            <Shield className="h-6 w-6" />
          </div>
          <h2 className="mt-3 text-lg font-bold text-white">
            {isRegister ? "Create Clinical Account" : "Access QuantaOrgan Portal"}
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Secure HIPAA-compliant role-based authorization
          </p>
        </div>

        {error && (
          <div className="mb-4 rounded-lg bg-rose-500/10 border border-rose-500/30 p-3 text-xs text-rose-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {isRegister && (
            <>
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:border-teal-500 focus:outline-none"
                    placeholder="Dr. Arthur Pendelton"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">Phone Number (Optional)</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                  <input
                    type="text"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:border-teal-500 focus:outline-none"
                    placeholder="+1-555-0199"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">Role / Account Pathway</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-xs text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="PATIENT">Registered Patient</option>
                  <option value="DONOR">Registered Donor</option>
                  <option value="TRANSPLANT_COORDINATOR">Transplant Coordinator</option>
                  <option value="CLINICIAN">Authorized Clinician / Surgeon</option>
                  <option value="LAB_REVIEWER">Laboratory Reviewer</option>
                </select>
              </div>
            </>
          )}

          <div>
            <label className="block text-[11px] font-semibold text-slate-300 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:border-teal-500 focus:outline-none"
                placeholder="name@hospital.org"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-300 mb-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
              <input
                type={showPassword ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 pl-9 pr-9 text-xs text-white placeholder-slate-500 focus:border-teal-500 focus:outline-none"
                placeholder="••••••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          {isRegister && (
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1">Confirm Password</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full rounded-lg border border-navy-700 bg-navy-950 py-2 px-3 text-xs text-white placeholder-slate-500 focus:border-teal-500 focus:outline-none"
                placeholder="••••••••••••"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-teal-600 py-2.5 text-xs font-semibold text-white shadow-md shadow-teal-500/20 hover:bg-teal-500 transition disabled:opacity-50"
          >
            {loading ? "Verifying..." : isRegister ? "Complete Registration" : "Sign In to Portal"}
          </button>
        </form>

        {/* Demo Fast Login Shortcuts */}
        <div className="mt-5 border-t border-navy-700 pt-4">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-2">
            Demo Environment Quick Switch
          </div>
          <div className="grid grid-cols-2 gap-1.5 text-[11px]">
            <button
              onClick={() => handleQuickLogin("admin@quantaorgan.demo", "AdminPass123!")}
              className="rounded border border-navy-700 bg-navy-950 px-2 py-1.5 text-left text-rose-300 hover:border-rose-500/50"
            >
              👑 Admin (System)
            </button>
            <button
              onClick={() => handleQuickLogin("clinician@quantaorgan.demo", "DoctorPass123!")}
              className="rounded border border-navy-700 bg-navy-950 px-2 py-1.5 text-left text-teal-300 hover:border-teal-500/50"
            >
              🩺 Clinician / Surgeon
            </button>
            <button
              onClick={() => handleQuickLogin("coordinator@quantaorgan.demo", "CoordPass123!")}
              className="rounded border border-navy-700 bg-navy-950 px-2 py-1.5 text-left text-cyan-300 hover:border-cyan-500/50"
            >
              📋 Coordinator
            </button>
            <button
              onClick={() => handleQuickLogin("patient@quantaorgan.demo", "PatientPass123!")}
              className="rounded border border-navy-700 bg-navy-950 px-2 py-1.5 text-left text-slate-300 hover:border-slate-500/50"
            >
              👤 Marcus (Patient)
            </button>
          </div>
        </div>

        <div className="mt-4 text-center">
          <button
            onClick={() => {
              setIsRegister(!isRegister);
              setError(null);
            }}
            className="text-xs text-teal-400 hover:underline"
          >
            {isRegister ? "Already registered? Sign In" : "New member? Create account"}
          </button>
        </div>
      </div>
    </div>
  );
}
