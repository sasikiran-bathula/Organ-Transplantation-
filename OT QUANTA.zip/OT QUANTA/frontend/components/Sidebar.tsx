"use client";

import React from "react";
import {
  LayoutDashboard,
  Users,
  HeartHandshake,
  FileText,
  Boxes,
  ClipboardList,
  GitCompare,
  ListOrdered,
  Atom,
  Bell,
  FileCheck2,
  BarChart3,
  Settings,
  ShieldAlert,
} from "lucide-react";

export type NavSection =
  | "dashboard"
  | "patients"
  | "donors"
  | "documents"
  | "inventory"
  | "requests"
  | "crossmatch"
  | "waiting-list"
  | "quantum"
  | "notifications"
  | "consent"
  | "analytics"
  | "settings"
  | "audit-logs";

interface SidebarProps {
  currentSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  userRole?: string;
  unreadCount?: number;
}

export function Sidebar({
  currentSection,
  onSelectSection,
  userRole,
  unreadCount = 0,
}: SidebarProps) {
  const isAuditorOrAdmin = userRole === "SYSTEM_ADMIN" || userRole === "AUDITOR";

  const navItems: { id: NavSection; label: string; icon: React.ReactNode; badge?: number; adminOnly?: boolean }[] = [
    { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-4 w-4" /> },
    { id: "patients", label: "Patient Registry", icon: <Users className="h-4 w-4" /> },
    { id: "donors", label: "Donor Registry", icon: <HeartHandshake className="h-4 w-4" /> },
    { id: "documents", label: "Medical History", icon: <FileText className="h-4 w-4" /> },
    { id: "inventory", label: "Organ Inventory", icon: <Boxes className="h-4 w-4" /> },
    { id: "requests", label: "Organ Requests", icon: <ClipboardList className="h-4 w-4" /> },
    { id: "crossmatch", label: "Crossmatch Reports", icon: <GitCompare className="h-4 w-4" /> },
    { id: "waiting-list", label: "Allocation & Waiting", icon: <ListOrdered className="h-4 w-4" /> },
    { id: "quantum", label: "Quantum Optimizer", icon: <Atom className="h-4 w-4 text-quantum-cyan" /> },
    { id: "notifications", label: "Notifications", icon: <Bell className="h-4 w-4" />, badge: unreadCount },
    { id: "consent", label: "Consent & Documents", icon: <FileCheck2 className="h-4 w-4" /> },
    { id: "analytics", label: "Reports & Analytics", icon: <BarChart3 className="h-4 w-4" /> },
    { id: "settings", label: "Settings", icon: <Settings className="h-4 w-4" /> },
    { id: "audit-logs", label: "Audit Logs", icon: <ShieldAlert className="h-4 w-4 text-rose-400" />, adminOnly: true },
  ];

  return (
    <aside className="w-64 border-r border-navy-700 bg-navy-900/60 p-4 flex flex-col justify-between h-[calc(100vh-4rem)]">
      <div className="space-y-1">
        <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Clinical Coordination
        </div>
        {navItems.map((item) => {
          if (item.adminOnly && !isAuditorOrAdmin) return null;
          const isActive = currentSection === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectSection(item.id)}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-xs font-medium transition ${
                isActive
                  ? "bg-teal-600/20 text-teal-300 border border-teal-500/40 shadow-sm"
                  : "text-slate-300 hover:bg-navy-800 hover:text-white"
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={isActive ? "text-teal-400" : "text-slate-400"}>{item.icon}</span>
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-bold text-white">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Security notice footer */}
      <div className="rounded-lg border border-navy-700/80 bg-navy-950/60 p-3 text-[11px] text-slate-400">
        <div className="flex items-center gap-1.5 font-semibold text-teal-400">
          <span className="h-2 w-2 rounded-full bg-teal-400 animate-pulse" />
          HIPAA & OPTN Compliant
        </div>
        <p className="mt-1 leading-tight text-[10px] text-slate-400">
          Patient records encrypted with immutable clinical audit logging.
        </p>
      </div>
    </aside>
  );
}
