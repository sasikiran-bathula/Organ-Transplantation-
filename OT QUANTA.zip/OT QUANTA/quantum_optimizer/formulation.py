import numpy as np
from typing import Dict, List, Tuple, Any

class AllocationProblemInstance:
    """Mathematical formulation of constrained organ allocation."""
    def __init__(self, num_organs: int, num_candidates: int, seed: int = 42):
        self.num_organs = num_organs
        self.num_candidates = num_candidates
        self.rng = np.random.default_rng(seed)
        
        # Binary compatibility matrix C[i, j] in {0, 1}
        # ~70% compatibility probability in benchmark instances
        self.compatibility = (self.rng.random((num_organs, num_candidates)) > 0.3).astype(int)
        
        # Urgency and clinical match utility weights W[i, j] in [10, 100]
        self.utility_weights = np.round(self.rng.uniform(10.0, 95.0, (num_organs, num_candidates)), 2)
        # Incompatible pairs have utility 0
        self.utility_weights = self.utility_weights * self.compatibility

    def to_qubo(self, penalty: float = 200.0) -> Tuple[np.ndarray, np.ndarray, float]:
        """Convert constrained matching problem to Quadratic Unconstrained Binary Optimization (QUBO).
        Variables: x_{i, j} mapped to 1D index k = i * num_candidates + j.
        Objective: Minimize -Sum(W_{ij} * x_{ij}) + Penalty * (Constraint Violations).
        """
        n_vars = self.num_organs * self.num_candidates
        Q = np.zeros((n_vars, n_vars))
        linear = np.zeros(n_vars)
        offset = 0.0

        # Linear term: maximize utility -> minimize -utility
        for i in range(self.num_organs):
            for j in range(self.num_candidates):
                k = i * self.num_candidates + j
                if self.compatibility[i, j] == 0:
                    linear[k] += penalty * 2.0  # Heavy penalty for incompatible assignment
                else:
                    linear[k] -= self.utility_weights[i, j]

        # Constraint 1: At most one candidate per organ (Sum_j x_{ij} <= 1)
        # Penalty for pairs (j1, j2) both assigned to organ i
        for i in range(self.num_organs):
            for j1 in range(self.num_candidates):
                for j2 in range(j1 + 1, self.num_candidates):
                    k1 = i * self.num_candidates + j1
                    k2 = i * self.num_candidates + j2
                    Q[k1, k2] += penalty

        # Constraint 2: At most one organ per candidate (Sum_i x_{ij} <= 1)
        for j in range(self.num_candidates):
            for i1 in range(self.num_organs):
                for i2 in range(i1 + 1, self.num_organs):
                    k1 = i1 * self.num_candidates + j
                    k2 = i2 * self.num_candidates + j
                    Q[k1, k2] += penalty

        return Q, linear, offset

    def validate_solution(self, assignment_matrix: np.ndarray) -> Tuple[bool, int, float]:
        """Verify constraints:
        1. An organ allocated to at most 1 recipient.
        2. A recipient allocated at most 1 organ.
        3. No incompatible assignments.
        Returns: (is_valid, violation_count, total_utility)
        """
        violations = 0
        
        # Check organ exclusivity
        organ_alloc_counts = np.sum(assignment_matrix, axis=1)
        violations += int(np.sum(np.maximum(0, organ_alloc_counts - 1)))
        
        # Check candidate exclusivity
        cand_alloc_counts = np.sum(assignment_matrix, axis=0)
        violations += int(np.sum(np.maximum(0, cand_alloc_counts - 1)))
        
        # Check compatibility
        incompatible_allocations = assignment_matrix * (1 - self.compatibility)
        violations += int(np.sum(incompatible_allocations))
        
        # Calculate utility
        total_utility = float(np.sum(assignment_matrix * self.utility_weights))
        
        return (violations == 0), violations, total_utility
