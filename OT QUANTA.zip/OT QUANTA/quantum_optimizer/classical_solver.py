import time
import numpy as np
from scipy.optimize import linear_sum_assignment
from typing import Dict, Any, List
from quantum_optimizer.formulation import AllocationProblemInstance

class ClassicalAllocationSolver:
    """Exact classical solver using Hungarian / Maximum Weight Bipartite Matching."""
    def __init__(self):
        self.name = "SciPy Maximum Weight Bipartite Matching (Classical Baseline)"

    def solve(self, instance: AllocationProblemInstance) -> Dict[str, Any]:
        start_time = time.perf_counter()

        # We want to maximize utility, linear_sum_assignment minimizes cost.
        # Cost = -utility for compatible pairs, high cost for incompatible pairs.
        cost_matrix = np.full((instance.num_organs, instance.num_candidates), 1e6)
        for i in range(instance.num_organs):
            for j in range(instance.num_candidates):
                if instance.compatibility[i, j] == 1:
                    cost_matrix[i, j] = -instance.utility_weights[i, j]

        row_ind, col_ind = linear_sum_assignment(cost_matrix)

        assignment = np.zeros((instance.num_organs, instance.num_candidates), dtype=int)
        allocations = []

        for r, c in zip(row_ind, col_ind):
            # Only allocate if actually compatible and has positive utility
            if instance.compatibility[r, c] == 1 and instance.utility_weights[r, c] > 0:
                assignment[r, c] = 1
                allocations.append({
                    "organ_index": int(r),
                    "candidate_index": int(c),
                    "utility": float(instance.utility_weights[r, c])
                })

        end_time = time.perf_counter()
        runtime_ms = round((end_time - start_time) * 1000.0, 3)

        is_valid, violations, total_utility = instance.validate_solution(assignment)

        return {
            "algorithm": self.name,
            "runtime_ms": runtime_ms,
            "is_valid": is_valid,
            "violations": violations,
            "total_utility": round(total_utility, 2),
            "allocations_count": len(allocations),
            "allocations": allocations
        }
