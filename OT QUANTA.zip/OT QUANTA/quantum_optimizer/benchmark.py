from typing import Dict, Any, List
from datetime import datetime, timezone
import numpy as np
from quantum_optimizer.formulation import AllocationProblemInstance
from quantum_optimizer.classical_solver import ClassicalAllocationSolver
from quantum_optimizer.quantum_solver import QuantumAllocationSolver

def run_allocation_benchmark(
    num_organs: int = 4,
    num_candidates: int = 8,
    num_trials: int = 3,
    penalty_weight: float = 150.0,
    backend_name: str = "qiskit_statevector_simulator"
) -> Dict[str, Any]:
    """Execute rigorous side-by-side benchmark of Classical vs. Quantum Solvers."""
    classical_solver = ClassicalAllocationSolver()
    quantum_solver = QuantumAllocationSolver(backend_name=backend_name)

    trials_data = []
    classical_times = []
    quantum_times = []
    feasible_count = 0

    last_classical_res = None
    last_quantum_res = None

    for t in range(num_trials):
        instance = AllocationProblemInstance(num_organs=num_organs, num_candidates=num_candidates, seed=100 + t)
        
        c_res = classical_solver.solve(instance)
        q_res = quantum_solver.solve(instance, penalty_weight=penalty_weight)

        classical_times.append(c_res["runtime_ms"])
        quantum_times.append(q_res["runtime_ms"])
        
        if q_res["is_valid"]:
            feasible_count += 1

        trials_data.append({
            "trial_index": t + 1,
            "classical_time_ms": c_res["runtime_ms"],
            "quantum_time_ms": q_res["runtime_ms"],
            "cost_value": q_res["total_utility"],
            "valid_solution": q_res["is_valid"]
        })

        last_classical_res = c_res
        last_quantum_res = q_res

    avg_classical_time = round(float(np.mean(classical_times)), 3)
    avg_quantum_time = round(float(np.mean(quantum_times)), 3)
    
    speedup_ratio = round(avg_classical_time / avg_quantum_time, 3) if avg_quantum_time > 0 else None
    feasibility_rate = round(feasible_count / num_trials, 3)

    return {
        "title": f"Constrained Matching Benchmark: {num_organs} Organs vs. {num_candidates} Candidates",
        "problem_size": num_organs * num_candidates,
        "num_organs": num_organs,
        "num_candidates": num_candidates,
        "classical_algorithm": classical_solver.name,
        "quantum_algorithm": quantum_solver.name,
        "backend_name": backend_name,
        "classical_runtime_ms": avg_classical_time,
        "quantum_runtime_ms": avg_quantum_time,
        "measured_speedup": speedup_ratio,
        "objective_score": last_quantum_res["total_utility"] if last_quantum_res else 0.0,
        "feasibility_rate": feasibility_rate,
        "constraint_violations": last_quantum_res["violations"] if last_quantum_res else 0,
        "trials": trials_data,
        "classical_allocations": last_classical_res["allocations"] if last_classical_res else [],
        "quantum_allocations": last_quantum_res["allocations"] if last_quantum_res else [],
        "limitations_notes": (
            "Research benchmark executed on statevector simulator. In NISQ devices, quantum decoherence, "
            "gate fidelity, and qubit topology require error mitigation. Quantum speedup claims are exploratory "
            "and do not supersede clinical triage protocols."
        ),
        "created_at": datetime.now(timezone.utc)
    }
